package mundo;

public class Acueducto {
	

public static final int NUM_CARROS =5;
	
	
	
	
	
	//metodo//
public String buscarCarroTanque(String pPlaca){
	
	return pPlaca;
}
		
				
				
}
