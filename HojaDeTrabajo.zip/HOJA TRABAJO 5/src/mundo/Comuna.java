package mundo;

public class Comuna {

	
	private int numero;
	private int CantidadBarrios;
	private int direccion;
	
	
	
	
	public void inicializar(int pNum,int cant, String dir){
		cant= CantidadBarrios;
	pNum =direccion;
	
	
	
	pNum =numero;
}
	public int darCantidadBarrios(){
		return CantidadBarrios;
			
	
	}
	

	public int darnumero(){
		return numero;
	}	
		public int dardireccion(){
			return direccion;
			
					
}
}
