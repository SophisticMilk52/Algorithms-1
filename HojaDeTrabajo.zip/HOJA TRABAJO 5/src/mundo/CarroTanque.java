package mundo;

public class CarroTanque {

	public final static char SI = 'S';

	public final static char NO = 'N';

	private int ComunaActual;
	private char despachado;

	private String placa;
	private double CapacidadMaxima;
	private double CapacidadMinima;

	// METODOS//
	public String darPlaca() {
		return placa;
	}

	public boolean lleno(double pUmbral) {
		boolean lleno;

		lleno = (CapacidadMaxima - CapacidadMinima) < pUmbral;

		return lleno;
	}

	public int darComuna() {

		return ComunaActual;
	}

	public double darCapacidadMaxima() {
		return CapacidadMaxima;

	}

	public double darCapacidadMinima() {
		return CapacidadMaxima;

	}

	public double ComunaActual() {
		return ComunaActual;
	}


	public String desplegarEstadoActual() {

		return "";

	}

}