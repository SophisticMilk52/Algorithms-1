package mundo;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Properties;

public class Poker {
	
    //ATRIBUTOS
	
	/**
	 * Descripcion: Atributo que contiene la cantidad de mesas que hay en el casino
	 */
	private int cantidadMesas;
		
	//RELACIONES	
	
	/**
	 * Descripcion: Arraylist de tipo Mesa que contiene las mesas del casino
	 */
	private ArrayList<Mesa> mesas;
	
	//CONSTRUCTOR
	
	/**
	 * Descripcion: Construye la clase poker e inicializa todos sus componentes
	 */
	public Poker(){		
		mesas = new ArrayList<Mesa>();
		
		cantidadMesas = 0;
		
	}
	
	/**
	 * Descripcion: Metodo que carga el archivo propertie
	 * @param archivo - El archivo por cargar
	 * @throws Exception - En caso de que no se pueda cargar el archivo
	 */
	public void cargarArchivo(File archivo) throws Exception{
		Properties datos = cargarInfoJuego(archivo);
		inicializarJuegoPoker(datos);
		
	}
	
	/**
	 * Descripcion: Metodo que carga la informacion del casino
	 * @param archivo - Archivo que contiene la informacion
	 * @return - Los datos del casino
	 * @throws Exception - En caso de que no se cargara bien la informacion
	 */
	public Properties cargarInfoJuego(File archivo) throws Exception{
		Properties datos = new Properties();
		try{
			FileInputStream in = new FileInputStream(archivo);
			datos.load(in);
		}catch(Exception e){
			throw new Exception("Archivo Inv�lido");
		}
	    return datos;
	}
	
	/**
	 * Descripcion: Metodo que inicializa los datos en el mundo del archivo propertie
	 * @param datos - Los datos que se inicializaran 
	 * @throws Exception - En caso de que no se puedan inicializar bien los datos
	 */
	public void inicializarJuegoPoker(Properties datos) throws Exception {
		
		try {
			cantidadMesas = Integer.parseInt(datos.getProperty("mesas"));
			 
			for (int i = 0; i < cantidadMesas; i++) {
				Mesa laMesa = null;

				int cantidadJugadores = Integer.parseInt(datos.getProperty("mesa" + i + ".cantidad"));
				int calle = Integer.parseInt(datos.getProperty("mesa" + i + ".calle"));
				double apuesta = Double.parseDouble(datos.getProperty("mesa" + i + ".apuesta"));
				
				String[] nombresJugadores = new String[cantidadJugadores];
				int[] partidasGanadas = new int[cantidadJugadores];
				double[] dineroGanado = new double[cantidadJugadores];
				String[][] cartasJugador = new String[cantidadJugadores][5];
				
				for (int j = 0; j < cartasJugador.length; j++) {
					for (int j2 = 0; j2 < cartasJugador[0].length; j2++) {
						cartasJugador[j][j2] = "sinCarta";
					}
				}
				
				for (int j = 0; j < cantidadJugadores; j++) {

					nombresJugadores[j] = datos.getProperty("mesa" + i + ".jugador" + j + ".nombre");
					partidasGanadas[j] = Integer.parseInt(datos.getProperty("mesa" + i + ".jugador" + j + ".ganadas"));
					dineroGanado[j] = Double.parseDouble(datos.getProperty("mesa"+ i + ".jugador" + j + ".dinero.ganado"));
				
					for (int k = 0; k < calle; k++) {
						
						cartasJugador[j][k] = datos.getProperty("mesa" + i + ".jugador" + j + ".carta" + k);
						
					}
				}
				laMesa = new Mesa(cantidadJugadores, calle, apuesta, nombresJugadores, partidasGanadas, dineroGanado, cartasJugador);
				mesas.add(laMesa);							
			}
		} catch (Exception e) {
			throw new Exception("ERROR");
		}
	}
	
	/**
	 * Descripcion: Retorna la cantidad de mesas del casino
	 * @return La cantidad de mesas
	 */
	public int darCantidadMesas(){
		return cantidadMesas;
	}
	
	/**
	 * Descripcion: Cambia la cantidad de mesas del casino
	 * @param cantidad - La nueva cantidad de mesas
	 */
	public void cambiarCantidadMesas(int cantidad){
		cantidadMesas = cantidad;
	}
		
	/**
	 * Descripcion: Retorna la Arraylist que contiene las mesas del casino
	 * @return La Arraylist con las mesas
	 */
	public ArrayList<Mesa> darMesas(){
		return mesas;
	}
	
	/**
	 * Descripcion: Cambia la Arraylist que contiene las mesas del casino
	 * @param lasMesas - La nueva Arraylist con las mesas del casino
	 */
	public void cambiarMesas(ArrayList<Mesa> lasMesas){
		mesas = lasMesas;
	}
	
	/**
	 * Descripcion: Metodo que reparte las cartas de los jugadores a una mesa
	 * @param mesa - La mesa donde se repartiran las cartas
	 */
	public void repartirCartasPorMesa(int mesa){
		mesas.get(mesa).repartirCartasMesa();
	}
	
	/**
	 * Descripcion: Metodo que inicia una nueva partida en una mesa
	 * @param mesa - La mesa donde se iniciara la nueva partida
	 */
	public void iniciarNuevaPartidaMesa(int mesa){
		mesas.get(mesa).iniciarNuevaPartida();
	}
	
	/**
	 * Descripcion: Metodo para saber quien es el ganador en una mesa
	 * @param mesa - La mesa donde se buscara al ganador
	 */
	public void conocerGanadorPorMesa(int mesa){
		mesas.get(mesa).saberGanador();
	}
}
