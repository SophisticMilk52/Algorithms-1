package mundo;

public class Jugador {
	
	//CONSTANTES
	
	/**
	 * Descripcion: Constante que determina el maximo de cartas que el jugador puede tener
	 */
	public final static int MAX_CARTAS_MANO = 5; 
	
	//ATRIBUTOS
	
	/**
	 * Descripcion: Atributo que contiene el nombre del jugador
	 */
    private String nombre;
    
    /**
     * Descripcion: Atributo que contiene las partidas  ganadas del jugador
     */
    private int partidasGanadas;
    
    /**
     * Descripcion: Atributo que contiene el dinero ganado del jugador
     */
    private double dineroGanado;
    
    /**
     * Descripcion: Arreglo que contiene las cartas del jugador
     */
    private String[] cartasJugador;
    
    /**
     * Descripcion: Atributo que contiene la mano del jugador
     */
    private String mano;
    
    /**
     * Descripcion: Atributo que contiene la carta que desempata al ganador
     */
    private String cartaDesempate;
    
    /**
     * Descripcion: Arreglo que contiene el orden de las cartas de la baraja
     */
    private char[] ordenDeCartas;
    
    //CONSTRUCTOR
    
    /**
     * Descripcion: Construye un jugador con los parametros dados
     * @param elNombre - Nombre del jugador
     * @param lasPartidasGanadas - Partidas ganadas del jugador
     * @param lasCartas - Cartas del jugador
     */
    public Jugador(String elNombre, int lasPartidasGanadas, String[] lasCartas){
    	
    	nombre = elNombre;
    	partidasGanadas = lasPartidasGanadas;
    	dineroGanado = 0;
    	mano = "";
    	
    	cartasJugador = new String[MAX_CARTAS_MANO];
    	ordenDeCartas = new char[13];
    	
    	cargarCartasJugador(lasCartas);
    	
    }
    
    /**
     * Descripcion: Metodo que carga las cartas del jugador 
     * @param arregloDeCartas - Las cartas dadas por parametro
     */
    public void cargarCartasJugador(String[] arregloDeCartas){
    	
    	switch (arregloDeCartas.length) {
		case 1: 
			cartasJugador[0] = arregloDeCartas[0];
			break;
		case 2: 
			cartasJugador[0] = arregloDeCartas[0];
			cartasJugador[1] = arregloDeCartas[1];
			break;
		case 3: 
			cartasJugador[0] = arregloDeCartas[0];
			cartasJugador[1] = arregloDeCartas[1];
			cartasJugador[2] = arregloDeCartas[2];
			break;
		case 4: 
			cartasJugador[0] = arregloDeCartas[0];
			cartasJugador[1] = arregloDeCartas[1];
			cartasJugador[2] = arregloDeCartas[2];
			cartasJugador[3] = arregloDeCartas[3];
			break;
		case 5: 
			cartasJugador[0] = arregloDeCartas[0];
			cartasJugador[1] = arregloDeCartas[1];
			cartasJugador[2] = arregloDeCartas[2];
			cartasJugador[3] = arregloDeCartas[3];
			cartasJugador[4] = arregloDeCartas[4];
			break;
		}
    }
    
    /**
     * Descripcion: Metodo que carga el orden de las cartas
     */
    public void cargarOrdenDeCartas(){
    	ordenDeCartas[0] = 'A'; ordenDeCartas[7] = '7';
    	ordenDeCartas[1] = 'K'; ordenDeCartas[8] = '6';
    	ordenDeCartas[2] = 'Q'; ordenDeCartas[9] = '5';
    	ordenDeCartas[3] = 'J'; ordenDeCartas[10] = '4';
    	ordenDeCartas[4] = '1'; ordenDeCartas[11] = '3';
    	ordenDeCartas[5] = '9'; ordenDeCartas[12] = '2';
    	ordenDeCartas[6] = '8'; 
    }

    /**
     * Descripcion: Retorna el nombre del jugador
     * @return El nombre del jugador
     */
	public String darNombre() {
		return nombre;
	}

	/**
	 * Descripcion: Cambia el nombre del jugador
	 * @param elNombre - El nuevo nombre del jugador
	 */
	public void cambiarNombre(String elNombre) {
		nombre = elNombre;
	}

	/**
	 * Descripcion: Retorna las partidas ganadas del jugador
	 * @return Las partidas ganadas del jugador
	 */
	public int darPartidasGanadas() {
		return partidasGanadas;
	}

	/**
	 * Descripcion: Cambia las partidas ganadas del jugador
	 * @param lasPartidasGanadas - La nueva cantidad de partidas ganadas del jugador
	 */
	public void cambiarPartidasGanadas(int lasPartidasGanadas) {
		partidasGanadas = lasPartidasGanadas;
	}
	
	/**
	 * Descripcion: Retorna el dinero del jugador
	 * @return El dinero del jugador
	 */
	public double darDineroGanado(){
		return dineroGanado;
	}
	
	/**
	 * Descripcion: Cambia el dinero del jugador
	 * @param elDineroGanado - La nueva cantidad de dinero del jugador
	 */
	public void cambiarDineroGanado(double elDineroGanado){
		dineroGanado = elDineroGanado;
	}
	
	/**
	 * Descripcion: Retorna el arreglo que contiene las cartas del jugador
	 * @return Las cartas del jugador
	 */
	public String[] darCartasJugador(){
		return cartasJugador;
	}
	
	/**
	 * Descripcion: Cambia el arreglo de las cartas del jugador
	 * @param nuevasCartas - Las nuevas cartasd del jugador
	 */
	public void cambiarCartasJugador(String[] nuevasCartas){
		cartasJugador = nuevasCartas;
	}
	
	/**
	 * Descripcion: Retorna la mano del jugador
	 * @return La mano del jugador
	 */
	public String darMano(){
		return mano;
	}
	
	/**
	 * Descripcion: Cambia la mano del jugador
	 * @param laMano - La nueva mano del jugador
	 */
	public void cambiarMano(String laMano){
		mano = laMano;
	}
	
	/**
	 * Descripcion: Retorna la carta con la que se hara el desempate si es necesario 
	 * @return La carta del desmpate
	 */
	public String darCartaDesempate(){
		return cartaDesempate;
	}
	
	/**
	 * Descripcion: Cambia la carta de desempate del jugador
	 * @param nuevaCarta - La nueva carta de desempate
	 */
	public void cambiarCartaDesmpate(String nuevaCarta){
		cartaDesempate = nuevaCarta;
	}
	
	/**
	 * Descripcion: Retorna un arreglo con el orden que deben tener las cartas
	 * @return Arreglo con el orden de las cartas
	 */
	public char[] darOrdenDeCartas(){
		return ordenDeCartas;
	}
	
	/**
	 * Descripcion: Cambia el arreglo que determina el orden de las cartas
	 * @param nuevoOrden - Nuevo arreglo con el orden de las cartas
	 */
	public void cambiarOrdenDeCartas(char[] nuevoOrden){
		ordenDeCartas = nuevoOrden;
	}
	
	/**
	 * Descripcion: Metodo que carga una carta en la posicion dada por parametro
	 * @param calle - Posicion donde se agregara la carta
	 * @param carta - La carta por agregar
	 */
	public void cargarCarta(int calle, String carta){
		
		cartasJugador[calle] = carta;
		
	}
	
	/**
	 * Descripcion: Metodo que busca la carta mas alta de un arreglo de cartas dado por parametro
	 * @param cartas - El arreglo en el que se buscara la carta mas alta
	 * @return - La carta mas alta del arreglo
	 */
	public String buscarCartaMasAlta(String[] cartas){
		String cartaMasAlta = "";
		boolean termino = false;
		
		for (int i = 0; i < ordenDeCartas.length && !termino; i++) {
			for (int j = 0; j < cartas.length; j++) {
				if(ordenDeCartas[i] == cartas[j].charAt(0)){
					cartaMasAlta = cartas[j];
					termino = true;
				}
			}
		}
		
		return cartaMasAlta;
	}
	
	/**
	 * Descripcion: Metodo que determina si la mano del jugador es Escalera Real De Color
	 * @param manoJugador - La mano del jugador
	 * @return - True si es Escalera Real De Color, Falso en caso contrario
	 */
	public boolean esEscaleraRealDeColor(String[] manoJugador){
		boolean loEs = false;
		
		//Determina la escalera por picas--------------------------
		for (int i = 0; i < manoJugador.length && !loEs; i++) {
			if(manoJugador[i].equals("AP")){
		    for (int j = 0; j < manoJugador.length && !loEs; j++) {
			if(manoJugador[j].equals("KP")){
		    for (int k = 0; k < manoJugador.length && !loEs; k++) {
			if(manoJugador[k].equals("QP")){
		    for (int q = 0; q < manoJugador.length && !loEs; q++) {
			if(manoJugador[q].equals("JP")){
	        for (int l = 0; l < manoJugador.length && !loEs; l++) {
			if(manoJugador[l].equals("10P")){
			loEs = true;
		}}}}}}}}}}
		//---------------------------------------------------------
		//Determina la escalera por corazones----------------------
		for (int i = 0; i < manoJugador.length && !loEs; i++) {
			if(manoJugador[i].equals("AC")){
		    for (int j = 0; j < manoJugador.length && !loEs; j++) {
			if(manoJugador[j].equals("KC")){
		    for (int k = 0; k < manoJugador.length && !loEs; k++) {
			if(manoJugador[k].equals("QC")){
		    for (int q = 0; q < manoJugador.length && !loEs; q++) {
			if(manoJugador[q].equals("JC")){
	        for (int l = 0; l < manoJugador.length && !loEs; l++) {
			if(manoJugador[l].equals("10C")){
			loEs = true;
		}}}}}}}}}}
		//---------------------------------------------------------
		//Determina la escalera por diamantes----------------------
		for (int i = 0; i < manoJugador.length && !loEs; i++) {
			if(manoJugador[i].equals("AD")){
		    for (int j = 0; j < manoJugador.length && !loEs; j++) {
			if(manoJugador[j].equals("KD")){
		    for (int k = 0; k < manoJugador.length && !loEs; k++) {
			if(manoJugador[k].equals("QD")){
		    for (int q = 0; q < manoJugador.length && !loEs; q++) {
		    if(manoJugador[q].equals("JD")){
			for (int l = 0; l < manoJugador.length && !loEs; l++) {
		    if(manoJugador[l].equals("10D")){
			loEs = true;
		}}}}}}}}}}
		//---------------------------------------------------------								
		//Determina la escalera por treboles----------------------
		for (int i = 0; i < manoJugador.length && !loEs; i++) {
		    if(manoJugador[i].equals("AT")){
		    for (int j = 0; j < manoJugador.length && !loEs; j++) {
			if(manoJugador[j].equals("KT")){
		    for (int k = 0; k < manoJugador.length && !loEs; k++) {
			if(manoJugador[k].equals("QT")){
		    for (int q = 0; q < manoJugador.length && !loEs; q++) {
		    if(manoJugador[q].equals("JT")){
			for (int l = 0; l < manoJugador.length && !loEs; l++) {
		    if(manoJugador[l].equals("10T")){
		    cartaDesempate = "EMPATE";
			loEs = true;
			}}}}}}}}}}
		//---------------------------------------------------------	
		
		return loEs;
	}
	
	/**
	 * Descripcion: Metodo que determina si la mano del jugador es Escalera De Color
	 * @param manoJugador - La mano del jugador
	 * @return - True si es Escalera De Color, Falso en caso contrario
	 */
	public boolean esEscaleraDeColor(String[] manoJugador){
		boolean loEs = false;
		
		//Determina la escalera por picas-------------------
		for (int i = 0; i < manoJugador.length && !loEs; i++) {
		    for (int j = 2; j <= 6 && !loEs; j++) {
		    if(manoJugador[i].equals(j+"P")){
		for (int i2 = 0; i2 < manoJugador.length && !loEs; i2++) {  	
			if(manoJugador[i2].equals((j+1)+"P")){
		for (int i3 = 0; i3 < manoJugador.length && !loEs; i3++) {
			if(manoJugador[i3].equals((j+2)+"P")){
		for (int i4 = 0; i4 < manoJugador.length && !loEs; i4++) {
			if(manoJugador[i4].equals((j+3)+"P")){
	    for (int i5 = 0; i5 < manoJugador.length && !loEs; i5++) {
			if(manoJugador[i5].equals((j+4)+"P")){
			loEs = true;				
			}}}}}}}}}
		}
	    }
		//-------------------------------------------------
		
		//Determina la escalera por corazones--------------
		for (int i = 0; i < manoJugador.length && !loEs; i++) {
		    for (int j = 2; j <= 6 && !loEs; j++) {
		    if(manoJugador[i].equals(j+"C")){
		for (int i2 = 0; i2 < manoJugador.length && !loEs; i2++) {  	
			if(manoJugador[i2].equals((j+1)+"C")){
		for (int i3 = 0; i3 < manoJugador.length && !loEs; i3++) {
			if(manoJugador[i3].equals((j+2)+"C")){
		for (int i4 = 0; i4 < manoJugador.length && !loEs; i4++) {
			if(manoJugador[i4].equals((j+3)+"C")){
	    for (int i5 = 0; i5 < manoJugador.length && !loEs; i5++) {
			if(manoJugador[i5].equals((j+4)+"C")){
			loEs = true;				
			}}}}}}}}}
		}
	    }
		//--------------------------------------------------
		
		//Determina la escalera por diamantes---------------
		for (int i = 0; i < manoJugador.length && !loEs; i++) {
		    for (int j = 2; j <= 6 && !loEs; j++) {
		    if(manoJugador[i].equals(j+"D")){
		for (int i2 = 0; i2 < manoJugador.length && !loEs; i2++) {  	
			if(manoJugador[i2].equals((j+1)+"D")){
		for (int i3 = 0; i3 < manoJugador.length && !loEs; i3++) {
			if(manoJugador[i3].equals((j+2)+"D")){
		for (int i4 = 0; i4 < manoJugador.length && !loEs; i4++) {
			if(manoJugador[i4].equals((j+3)+"D")){
	    for (int i5 = 0; i5 < manoJugador.length && !loEs; i5++) {
			if(manoJugador[i5].equals((j+4)+"D")){
			loEs = true;				
			}}}}}}}}}
		}
	    }
		//--------------------------------------------------
				
		//Determina la escalera por treboles----------------
		for (int i = 0; i < manoJugador.length && !loEs; i++) {
		    for (int j = 2; j <= 6 && !loEs; j++) {
		    if(manoJugador[i].equals(j+"T")){
		for (int i2 = 0; i2 < manoJugador.length && !loEs; i2++) {  	
			if(manoJugador[i2].equals((j+1)+"T")){
		for (int i3 = 0; i3 < manoJugador.length && !loEs; i3++) {
			if(manoJugador[i3].equals((j+2)+"T")){
		for (int i4 = 0; i4 < manoJugador.length && !loEs; i4++) {
			if(manoJugador[i4].equals((j+3)+"T")){
	    for (int i5 = 0; i5 < manoJugador.length && !loEs; i5++) {
			if(manoJugador[i5].equals((j+4)+"T")){
			loEs = true;				
			}}}}}}}}}
		}
	    }
		//--------------------------------------------------
		cartaDesempate = buscarCartaMasAlta(manoJugador);
		
		return loEs;
	}
	
	/**
	 * Descripcion: Metodo que determina si la mano del jugador es Poker
	 * @param manoJugador - La mano del jugador
	 * @return - True si es Poker, Falso en caso contrario
	 */
	public boolean esPoker(String[] manoJugador){
		boolean loEs = false;
		
		char cero = manoJugador[0].charAt(0);
		char uno = 'a';
		
		int contador1 = 0;
		int contador2 = 0;
		
		for (int i = 0; i < manoJugador.length; i++) {
			if(manoJugador[i].charAt(0) == cero){
				contador1++;
				if(contador1 == 4){
					cartaDesempate = manoJugador[i];
				}
			}else{
				uno = manoJugador[i].charAt(0);
			}
		}
		
		for (int i = 0; i < manoJugador.length; i++) {
			if(manoJugador[i].charAt(0) == uno){
				contador2++;
				if(contador2 == 4){
					cartaDesempate = manoJugador[i];
				}
			}
		}
		
		if((contador1 == 1 && contador2 == 4) || (contador2 == 1 && contador1 == 4)){
			loEs = true;
		}
		
		return loEs;
	}
	
	/**
	 * Descripcion: Metodo que determina si la mano del jugador es Full
	 * @param manoJugador - La mano del jugador
	 * @return - True si es Full, Falso en caso contrario
	 */
	public boolean esFull(String[] manoJugador){
		boolean loEs = false;
		
		int contador1 = 0;
		int contador2 = 0;
		
		char uno = manoJugador[0].charAt(0);
		char dos = 'a';
		
		for (int i = 0; i < manoJugador.length; i++) {
			if(manoJugador[i].charAt(0)==uno){
				contador1++;
				if(contador1 == 3){
					cartaDesempate = manoJugador[i];
				}
			}else{
				dos = manoJugador[i].charAt(0);
			}
		}
		
		
		for (int i = 1; i < manoJugador.length; i++) {
			if(manoJugador[i].charAt(0) == dos){
				contador2++;
				if(contador2 == 3){
					cartaDesempate = manoJugador[i];
				}
			}
		}
		
		if((contador1 == 2 && contador2 == 3) || (contador1 == 3 && contador2 == 2)){
			loEs = true;
		}
		
		
		return loEs;
	}
	
	/**
	 * Descripcion: Metodo que determina si la mano del jugador es Color 
	 * @param manoJugador - La mano del jugador
	 * @return - True si es Color, Falso en caso contrario
	 */
	public boolean esColor(String[] manoJugador){
		boolean loEs = false;
		
		char cero = manoJugador[0].charAt(manoJugador[0].length()-1);
		char uno = manoJugador[1].charAt(manoJugador[1].length()-1);
		char dos = manoJugador[2].charAt(manoJugador[2].length()-1);
		char tres = manoJugador[3].charAt(manoJugador[3].length()-1);
		char cuatro = manoJugador[4].charAt(manoJugador[4].length()-1);
		
		if(cero == uno && uno == dos && dos == tres && tres == cuatro){
			loEs = true;
		}
		
		cartaDesempate = buscarCartaMasAlta(manoJugador);
		
		return loEs;
	}
	
	/**
	 * Descripcion: Metodo que determina si la mano del jugador es Escalera
	 * @param manoJugador - La mano del jugador
	 * @return - True si es Escalera, Falso en caso contrario
	 */
	public boolean esEscalera(String[] manoJugador){
		boolean loEs = false;

		for (int i = 0; i < manoJugador.length && !loEs; i++) {
		    for (int j = 2; j <= 6 && !loEs; j++) {
		    String letra = "";
		    letra += j;
		    if(manoJugador[i].charAt(0) == letra.charAt(0)){
		for (int i2 = 0; i2 < manoJugador.length && !loEs; i2++) {  	
			String letra2 = "";
		    letra2 += (j+1);
			if(manoJugador[i2].charAt(0) == letra2.charAt(0)){
		for (int i3 = 0; i3 < manoJugador.length && !loEs; i3++) {
			String letra3 = "";
		    letra3 += (j+2);
			if(manoJugador[i3].charAt(0) == letra3.charAt(0)){
		for (int i4 = 0; i4 < manoJugador.length && !loEs; i4++) {
			String letra4 = "";
		    letra4 += (j+3);
			if(manoJugador[i4].charAt(0) == letra4.charAt(0)){
	    for (int i5 = 0; i5 < manoJugador.length && !loEs; i5++) {
	    	String letra5 = "";
		    letra5 += (j+4);
			if(manoJugador[i5].charAt(0) == letra5.charAt(0)){
	
			
				  loEs = true;
				  cartaDesempate = buscarCartaMasAlta(manoJugador);
			
			}}}}}}}}}}}
		
		return loEs;
	}
	
	/**
	 * Descripcion: Metodo que determina si la mano del jugador es Trio
	 * @param manoJugador - La mano del jugador
	 * @return - True si es Trio, Falso en caso contrario
	 */
	public boolean esTrio(String[] manoJugador){
		boolean loEs = false;
		
		int contador1 = 0;
		
		char uno = manoJugador[0].charAt(0);
		
		for (int i = 0; i < manoJugador.length; i++) {
			if(manoJugador[i].charAt(0)==uno){
				contador1++;
				if(contador1 == 3){
					cartaDesempate = manoJugador[i];
				}
			}
		}
		
		if(contador1 == 0 || contador1 == 1 || contador1 == 2){
			contador1 = 0;
			uno = manoJugador[1].charAt(0);
			for (int i = 0; i < manoJugador.length; i++) {
				if(manoJugador[i].charAt(0)==uno){
					contador1++;
					if(contador1 == 3){
						cartaDesempate = manoJugador[i];
					}
				}
			}
		}
		
		if(contador1 == 0 || contador1 == 1 || contador1 == 2){
			contador1 = 0;
			uno = manoJugador[2].charAt(0);
			for (int i = 0; i < manoJugador.length; i++) {
				if(manoJugador[i].charAt(0)==uno){
					contador1++;
					if(contador1 == 3){
						cartaDesempate = manoJugador[i];
					}
				}
			}
		}
		
		if(contador1 == 3){
			loEs = true;
		}
		
		return loEs;
	}
	
	/**
	 * Descripcion: Metodo que determina si la mano del jugador es Dobles Parejas
	 * @param manoJugador - La mano del jugador
	 * @return - True si es Dobles Parejas, Falso en caso contrario
	 */
	public boolean esDoblesParejas(String[] manoJugador){
		boolean loEs = false;
		
		char cero = manoJugador[0].charAt(0); int contador1 = 0;
		char uno = 'a';                 int contador2 = 0;
		char dos = 'a';                 int contador3 = 0;
		
		for (int i = 0; i < manoJugador.length; i++) {
			if(manoJugador[i].charAt(0) == cero){
				contador1 ++;
		}}
		
		boolean termino = false;
		for (int i = 0; i < manoJugador.length && !termino; i++) {
			if(manoJugador[i].charAt(0) != cero){
				boolean termino2 = false;
				uno = manoJugador[i].charAt(0);
				termino = true;
				for (int j = 0; j < manoJugador.length && !termino2; j++) {
					if(manoJugador[j].charAt(0) != cero && manoJugador[j].charAt(0) != uno){
						dos = manoJugador[j].charAt(0);
						termino2 = true;
		}}}}
		
		for (int i = 0; i < manoJugador.length; i++) {
			if(manoJugador[i].charAt(0) == uno){
				contador2 ++;
			}else if(manoJugador[i].charAt(0) == dos){
				contador3 ++;
		}}
		
		if(contador1 == 1 && contador2 == 2 && contador3 == 2 ||
	       contador1 == 2 && contador2 == 1 && contador3 == 2 ||
		   contador1 == 2 && contador2 == 2 && contador3 == 1){
			loEs = true;
		}
		
		cartaDesempate = buscarCartaMasAlta(manoJugador);
		
		return loEs;
	}
	
	/**
	 * Descripcion: Metodo que determina si la mano del jugador es Parejas
	 * @param manoJugador - La mano del jugador
	 * @return - True si es Parejas, Falso en caso contrario
	 */
	public boolean esParejas(String[] manoJugador){
		boolean loEs = false;
		
		int contador = 0;
		boolean termino = false;
		int posPareja = 0;
		
		for (int i = 0; i < manoJugador.length && !termino; i++) {
			for (int j = 0; j < manoJugador.length && !termino; j++) {
				if(manoJugador[i].charAt(0) == manoJugador[j].charAt(0)){
					contador++;
				}
			}if(contador == 2){
				cartaDesempate = manoJugador[i];
				posPareja = i;
				termino = true;
			}else{
				contador = 0;
			}
		}
		
		if(contador == 2){
		for (int i = 0; i < manoJugador.length; i++) {
			if(manoJugador[i].charAt(0) != manoJugador[posPareja].charAt(0)){
		for (int j = 0; j < manoJugador.length; j++) {
			if(manoJugador[j].charAt(0) != manoJugador[posPareja].charAt(0) &&
			   manoJugador[j].charAt(0) != manoJugador[i].charAt(0)){
		for (int k = 0; k < manoJugador.length; k++) {
			if(manoJugador[k].charAt(0) != manoJugador[posPareja].charAt(0) && 
			   manoJugador[k].charAt(0) != manoJugador[i].charAt(0) && 
			   manoJugador[k].charAt(0) != manoJugador[j].charAt(0)){
			loEs = true;
		}}}}}}}
		
		return loEs;
	}
	
	/**
	 * Descripcion: Metodo que determina si la mano del jugador es Carta Alta
	 * @param manoJugador - La mano del jugador
	 * @return - True si es Carta Alta, Falso en caso contrario
	 */
	public boolean esCartaAlta(String[] manoJugador){
		boolean loEs = false;
		
		if(esEscaleraRealDeColor(manoJugador)==false &&
		   esEscaleraDeColor(manoJugador)==false &&
		   esPoker(manoJugador)==false &&
		   esFull(manoJugador)==false &&
		   esColor(manoJugador)==false &&
		   esEscalera(manoJugador)==false &&
		   esPoker(manoJugador)==false &&
		   esTrio(manoJugador)==false &&
		   esDoblesParejas(manoJugador)==false &&
		   esParejas(manoJugador)==false){
			loEs = true;
		}
		
		cartaDesempate = buscarCartaMasAlta(manoJugador);
		
		return loEs;
	}
	
	/**
	 * Descripcion: Metodo que determina la mano del jugador
	 */
	public void saberManoJugador(){
		
		if(esEscaleraRealDeColor(cartasJugador)){
			mano = "ESCALERA REAL DE COLOR";
		}else if(esEscaleraDeColor(cartasJugador)){
			mano = "ESCALERA DE COLOR";
		}else if(esPoker(cartasJugador)){
			mano = "POKER";
		}else if(esFull(cartasJugador)){
			mano = "FULL";
		}else if(esColor(cartasJugador)){
			mano = "COLOR";
		}else if(esEscalera(cartasJugador)){
			mano = "ESCALERA";
		}else if(esTrio(cartasJugador)){
			mano = "TRIO";
		}else if(esDoblesParejas(cartasJugador)){
			mano = "DOBLES PAREJAS";
		}else if(esParejas(cartasJugador)){
			mano = "PAREJAS";
		}else if(esCartaAlta(cartasJugador)){
			mano = "CARTA ALTA";
		}
		
	}
	
}
