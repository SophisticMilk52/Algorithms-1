package mundo;

public class Mesa {
	
	//CONSTANTES 
	
	/**
	 * Descripcion: Constante que determina el total de cartas que hay en una baraja inglesa
	 */
	public final static int BARAJA_INGLESA = 52; 
	
	/**
	 * Descripcion: Constante que determina el maximo de jugadores por mesa
	 */
	public final static int MAX_JUGADORES = 10;
	
    //ATRIBUTOS
	
	/**
	 * Descripcion: Atributo que contiene la cantidad de jugadores que hay en la mesa
	 */
	private int cantidadJugadores;
	
	/**
	 * Descripcion: Atributo que contiene la calle actual de la mesa
	 */
	private int calle;
	
	/**
	 * Descripcion: Atributo que contiene la apuesta inicial de la mesa
	 */
	private double apuesta;
	
	/**
	 * Descripcion: Arreglo que contiene los nombres de los jugadores de la mesa
	 */
	private String[] nombresJugadores;
	
	/**
	 * Descripcion: Arreglo que contiene las partidas ganadas de los jugadores de la mesa
	 */
	private int[] partidasGanadasJugadores;
	
	/**
	 * Descripcion: Arreglo que contiene el dinero de los jugadores de la mesa
	 */
	private double[] dineroGanadoJugadores;
	
	/**
	 * Descripcion: Matriz que contiene las cartas de los jugadores de la mesa
	 */
	private String[][] cartasMesa;
	
	/**
	 * Descripcion: Arreglo que contiene los tipos de mano que puede tener el jugador
	 */
	private String[] tiposDeMano;
	
	/**
	 * Descripcion: Atributo que contiene el nombre del ganador
	 */
	private String ganador;
	
	/**
	 * Descripcion: Atributo que contiene la mano con la que el jugador gano
	 */
	private String manoGanadora;
	
	/**
	 * Descripcion: Arreglo que representa la baraja de cartas
	 */
	private String[] baraja;
	
	//RELACIONES
	
	/**
	 * Descripcion: Arreglo de tipo Jugaodr que contiene a los jugadores de la mesa
	 */
	private Jugador[] jugadores;
	
	//CONSTRUCTOR
	 
	/**
	 * Descripcion: Construye la mesa con los componentes dados por parametro
	 * @param cantJugadores - Es la cantidad de jugadores de la mesa
	 * @param laCalle - Es la calle de la mesa
	 * @param laApuesta - Es la apuesta inicial de la mesa
	 * @param losNombJug - Son los nombres de los jugadores de la mesa
	 * @param pGanJug - Son las partidas ganadas de los jugadores de la mesa
	 * @param dGanJug - Es el dinero de los jugadores de la mesa
	 * @param cartJug - Son las cartas de los jugadores
	 */
	public Mesa(int cantJugadores, int laCalle, double laApuesta, String[] losNombJug, int[] pGanJug, double[] dGanJug, String[][] cartJug){

		cantidadJugadores = cantJugadores;
		calle = laCalle;
		apuesta = laApuesta;
		nombresJugadores = losNombJug;
		partidasGanadasJugadores = pGanJug;
		dineroGanadoJugadores = dGanJug;
		cartasMesa = cartJug;
		ganador = "";
		manoGanadora = "";
		
		jugadores = new Jugador[cantJugadores];
		baraja = new String[BARAJA_INGLESA];
		tiposDeMano = new String[10];
		
		cargarTiposDeMano();
		cargarJugadores();
		cargarBaraja();

	}
	
	/**
	 * Descripcion: Metodo que carga la baraja de la mesa
	 */
    public void cargarBaraja(){
		
		baraja[0] = "AP"; baraja[4] = "JP"; baraja[8] = "QP"; baraja[12] = "KP";  
		baraja[1] = "AC"; baraja[5] = "JC"; baraja[9] = "QC"; baraja[13] = "KC"; 
		baraja[2] = "AT"; baraja[6] = "JT"; baraja[10] = "QT"; baraja[14] = "KT";  
		baraja[3] = "AD"; baraja[7] = "JD"; baraja[11] = "QD"; baraja[15] = "KD"; 
	
		for (int i = 16, j = 2; i < 25; i++, j++) {
			baraja[i] = j+"P";
		}
		
        for (int i = 25, j = 2; i < 34; i++, j++) {
        	baraja[i] = j+"C";
		}
        
        for (int i = 34, j = 2; i < 43; i++, j++) {
        	baraja[i] = j+"T";
		}
        
        for (int i = 43, j = 2; i < 52 ; i++, j++) {
        	baraja[i] = j+"D";
		}
			
	}
    
    /**
     * Descripcion: Metodo que carga los tipos de mano que puede tener un jugador
     */
    public void cargarTiposDeMano(){

		tiposDeMano[0] = "ESCALERA REAL DE COLOR"; tiposDeMano[5] = "ESCALERA"; 
		tiposDeMano[1] = "ESCALERA DE COLOR";      tiposDeMano[6] = "TRIO"; 
		tiposDeMano[2] = "POKER";                  tiposDeMano[7] = "DOBLES PAREJAS"; 
		tiposDeMano[3] = "FULL";                   tiposDeMano[8] = "PAREJAS"; 
		tiposDeMano[4] = "COLOR";                  tiposDeMano[9] = "CARTA ALTA"; 
		
    }
	
    /**
     * Descripcion: Retorna la cantidad de jugadores de la mesa
     * @return La cantidad de jugadores
     */
	public int darCantidadJugadores() {
		return cantidadJugadores;
	}
	
	/**
	 * Descripcion: Cambia la cantidad de jugadores de la mesa
	 * @param laCantidadJugadores - Es la nueva cantidad de jugadores
	 */
	public void cambiarCantidadJugadores(int laCantidadJugadores) {
		cantidadJugadores = laCantidadJugadores;
	}
	
	/**
	 * Descripcion: Retorna la calle actual de la mesa
	 * @return La calle de la mesa
	 */
	public int darCalle() {
		return calle;
	}

	/**
	 * Descripcion: Cambia la calle de la mesa
	 * @param laCalle - Es la nueva calle actual de la mesa
	 */
	public void cambiarCalle(int laCalle) {
		calle = laCalle;
	}
	
	/**
	 * Descripcion: Retorna la apuesta inicial de la mesa
	 * @return La apuesta inicial 
	 */
	public double darApuesta(){
		return apuesta;
	}
	
	/**
	 * Descripcion: Cambia la apuesta inicial de la mesa
	 * @param laApuesta - La nueva apuesta de la mesa
	 */
	public void cambiarApuesta(double laApuesta){
		apuesta = laApuesta;
	}
	
	/**
	 * Descripcion: Retorna un arreglo con los nombres de los jugadores de la mesa
	 * @return Arreglo con los nombres de los jugadores
	 */
	public String[] darNombresJugadores(){
		return nombresJugadores;
	}
	
	/**
	 * Descripcion: Cambia el arreglo que contiene los nombres de los jugaodres de la mesa
	 * @param losNombres - Nuevo arreglo con los nombres de los jugadores
	 */
	public void cambiarNombresJugadores(String[] losNombres){
		nombresJugadores = losNombres;
	}
	
	/**
	 * Descripcion: Retorna un arreglo con las partidas ganadas de los jugadores de la mesa
	 * @return Arreglo con las partidas ganadas de los jugadores
	 */
	public int[] darPartidasGanadasJugadores(){
		return partidasGanadasJugadores;
	}
	
	/**
	 * Descripcion: Cambia el arreglo que contiene las partidas ganadas de los jugadores
	 * @param lasPartidas - Nuevo arreglo con las partidas ganadas de los jugadores
	 */
	public void cambiarPartidasGanadasJugadores(int[] lasPartidas){
		partidasGanadasJugadores = lasPartidas;
	}
	
	/**
	 * Descripcion: Retorna un arreglo con el dinero de los jugadores de la mesa
	 * @return Arreglo que contiene el dinero de los jugadores
	 */
	public double[] darDineroGanadoJugadores(){
		return dineroGanadoJugadores;
	}
	
	/**
	 * Descripcion: Cambia el arreglo que contiene el dinero de los jugadores
	 * @param elDinero - Nuevo arreglo con el dinero de los jugadores
	 */
	public void cambiarDineroGanadoJugadores(double[] elDinero){
		dineroGanadoJugadores = elDinero;
	}
	
	/**
	 * Descripcion: Retorna una matriz con las cartas de los jugadores de la mesa
	 * @return Matriz con las cartas de los jugadores
	 */
	public String[][] darCartasMesa(){
		return cartasMesa;
	}
	
	/**
	 * Descripcion: Cambia la matriz que contiene las cartas de los jugadores de la mesa
	 * @param lasCartasMesa - Nueva matriz con las cartas de los jugadores
	 */
	public void cambiarCartasMesa(String[][] lasCartasMesa){
		cartasMesa = lasCartasMesa;
	}
	
	/**
	 * Descripcion: Retorna un arreglo de tipo Jugador que contiene a los jugadores de la mesa
	 * @return Arreglo con los jugadores
	 */
	public Jugador[] darJugadores(){
		return jugadores;
	}
	
	/**
	 * Descripcion: Cambia el arreglo que contiene a los jugadores de la mesa
	 * @param losJugadores - Arreglo con los nuevos jugadores de la mesa
	 */
	public void cambiarJugadores(Jugador[] losJugadores){
		jugadores = losJugadores;
	}
	
	/**
	 * Descripcion: Retorna el ganador de la partida
	 * @return El nombre del ganador
	 */
	public String darGanador(){
		return ganador;
	}
	
	/**
	 * Descripcion: Cambia el nombre del ganador de la partida
	 * @param nuevoGanador - El nuevo nombre del ganador
	 */
	public void cambiarGanador(String nuevoGanador){
		ganador = nuevoGanador;
	}
	
	/**
	 * Descripcion: Retorna la mano con la que el jugador gano la partida
	 * @return La mano con la que gano la partida
	 */
	public String darManoGanadora(){
		return manoGanadora;
	}
	
	/**
	 * Descripcion: Cambia la mano con la que el jugador gano la partida
	 * @param nuevaManoGanadora - La nueva mano 
	 */
	public void cambiarManoGanadora(String nuevaManoGanadora){
		manoGanadora = nuevaManoGanadora;
	}
	
	/**
	 * Descripcion: Metodo que genera un mensaje con el nombre del jugador que gano la partida
	 * y la mano con la que gano
	 * @return Mensaje del ganador de la mesa
	 */
	public String generarMensajeDelGanador(){
		
		saberGanador();
		
		String mensaje = "";
		String ganador = "Ganador: ";
		ganador += darGanador();
		String manoGandora = "\nMano: ";
		manoGandora +=darManoGanadora();
		
		mensaje = ganador + manoGandora;
		return mensaje;
	}
	
	/**
	 * Descripcion: Metodo que carga los jugadores al arreglo de jugadores
	 */
	public void cargarJugadores(){
		for(int i=0;i<cantidadJugadores;i++){
				
				jugadores[i] = new Jugador(nombresJugadores[i], partidasGanadasJugadores[i], repartirCartasPorJugador(i, cartasMesa));
		
		}
	}
	
	/**
	 * Descripcion: Metodo que reparte las cartas de los jugadores al arreglo donde estos se encuentran
	 * @param numeroJugador - Posicion del jugador
	 * @param matrizDeCartas - Cartas de la mesa
	 * @return Un arreglo con las cartas del jugador
	 */
	public String[] repartirCartasPorJugador(int numeroJugador, String[][] matrizDeCartas){
		
		String[] cartasDelJugador = new String[calle];
		
		for (int i = 0; i < cartasDelJugador.length; i++) {
			cartasDelJugador[i] = matrizDeCartas[numeroJugador][i];
		}
		
		return cartasDelJugador;
	}
	
	/**
	 * Descripcion: Metodo que reparte una carta (de manera aleatoria) de la baraja de la mesa 
	 * a la mano de cada jugador. Las cartas no se repiten
	 */
	public void repartirCartasMesa(){
		
		//Cartas usadas por propiedades--------------------------------------------
		
		for (int i = 0; i < cartasMesa.length; i++) {
			for (int j = 0; j < cartasMesa[0].length; j++) {
				for (int k = 0; k < baraja.length; k++) {
					
					if(cartasMesa[i][j].equals(baraja[k])){
						baraja[k] = "sinCarta";
					}
					
				}
			}
		}
		
		//------------------------------------------------------------------------
		
		if(calle < 5){ 
		for (int i = 0; i < cantidadJugadores; i++) {
			int numeroAleatorio = 0;
			
			do {
				numeroAleatorio = (int) (Math.random()*51+0);
		      }
		      while (baraja[numeroAleatorio].equals("sinCarta"));
			
			if(baraja[numeroAleatorio].equals("sinCarta")){
				
			}else{
				cartasMesa[i][calle] = baraja[numeroAleatorio];
				jugadores[i].darCartasJugador()[calle] = baraja[numeroAleatorio];
				baraja[numeroAleatorio] = "sinCarta";
			}
		}
		calle++;
		}
	}
	
	/**
	 * Descripcion: Metodo para iniciar una nueva partida en la mesa (Reinicia los valores)
	 */
	public void iniciarNuevaPartida(){
		
		for (int i = 0; i < cartasMesa.length; i++) {
			for (int j = 0; j < cartasMesa[0].length; j++) {
				cartasMesa[i][j] = "sinCarta";
			}
		}
		cargarBaraja();
		ganador = "";
		manoGanadora = "";
		calle = 0;
		
		for (int i = 0; i < cantidadJugadores; i++) {
			dineroGanadoJugadores[i] -= apuesta;
		}
	}
	
	/**
	 * Descripcion: Metodo para saber que jugador es el ganador de la partida
	 */
	public void saberGanador(){
		char caso1='a';
		char caso2='a';
		String elganador = "";
		String laManoGanadora = "";
		boolean termino = false;
		
		for (int i = 0; i < cantidadJugadores; i++) {
			jugadores[i].saberManoJugador();
		}
		
		for (int i = 0; i < tiposDeMano.length && !termino; i++) {
			for (int j = 0; j < cantidadJugadores && !termino; j++){
				if(tiposDeMano[i].equals(jugadores[j].darMano())){
				
			for (int k = j+1; k < cantidadJugadores && !termino; k++) {
				if(tiposDeMano[i].equals(jugadores[k].darMano()) && !(jugadores[k].equals(jugadores[j]))){
				//DESEMPATE
				for (int m = 0; m < jugadores[0].darOrdenDeCartas().length; m++) {
					//____
					System.out.println(jugadores[k].darCartaDesempate().length());
					if(jugadores[k].darCartaDesempate().charAt(0) == jugadores[k].darOrdenDeCartas()[m]){
						elganador = jugadores[k].darNombre();
						if((calle == 5) && (ganador == "")){
							partidasGanadasJugadores[j] ++;
							dineroGanadoJugadores[j] += apuesta;							
						}
						laManoGanadora = jugadores[k].darMano();
						termino = true;
					}
                    if(jugadores[j].darCartaDesempate().charAt(0) == jugadores[j].darOrdenDeCartas()[m] && !termino){
                    	elganador = jugadores[j].darNombre();
                    	if((calle == 5) && (ganador == "")){
							partidasGanadasJugadores[j] ++;
							dineroGanadoJugadores[j] += apuesta;							
						}
                    	laManoGanadora = jugadores[j].darMano();
                    	termino = true;
					}
				}
				}else{
					if((calle == 5) && (ganador == "")){
						partidasGanadasJugadores[j] ++;
						dineroGanadoJugadores[j] += apuesta;							
					}
				elganador = jugadores[j].darNombre();
				laManoGanadora = jugadores[j].darMano();
				termino = true;							
		}}}}}
		
		ganador = elganador;
		manoGanadora = laManoGanadora;
	}
}
