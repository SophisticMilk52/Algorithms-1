package interfaz;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.xml.ws.handler.MessageContext;

public class PanelMesas extends JPanel implements ActionListener{
	
	//CONSTANTES

	/**
	 * Descripcion: Constante que determina el maximo de columnas que tendra la mesa
	 */
	public final static int MAX_COLUMNAS = 8;
	
	/**
	 * Descripcion: Comando para repartir las cartas a la mesa
	 */
	public final static String REPARTIR_CARTAS = "REPARTIR_CARTAS";
	
	/**
	 * Descripcion: Comando para iniciar una nueva partida en la mesa
	 */
	public final static String INICIAR_NUEVA_PARTIDA = "INICIAR_NUEVA_PARTIDA";
	
	/**
	 * Descripcion: Comando para buscar el ganador de la mesa
	 */
	public final static String GANADOR = "GANADOR";
  	
	//ATRIBUTOS
	
	/**
	 * Descripcion: Matriz de JLabel donde iran las mesas 
	 */
	private JLabel[][] mesa;

	/**
	 * Descripcion: Atributo que contiene el numero de la mesa
	 */
	private int numeroDeMesa;
	
	/**
	 * Descripcion: Atributo que contiene la cantidad de jugadores de la mesa
	 */
	private int cantidadJugadores;
	
	/**
	 * Descripcion: Atributo que contiene la calle de la mesa
	 */
	private int calle;
	
	/**
	 * Descripcion: Atributo que contiene la apuesta inicial de la mesa
	 */
	private double apuesta;
	
	/**
	 * Descripcion: Arreglo que contiene los nombres de los jugadores de la mesa
	 */
	private String[] nombresJugadores;
	
	/**
	 * Descripcion: Arreglo que contiene las partidas ganadas de los jugadores de la mesa
	 */
	private int[] partidasGanadasJugadores;
	
	/**
	 * Descripcion: Arreglo que contiene el dinero ganado de los jugadores de la mesa
	 */
	private double[] dineroGanadoJugadores;
	
	/**
	 * Descripcion: Matriz que contiene las cartas de los jugadores de la mesa
	 */
	private String[][] cartasMesa;
	
	
	/**
	 * Descripcion: Scroll para poder visualizar las mesas
	 */
	private JScrollPane scroll;
	
	/**
	 * Descripcion: Etiqueta para el nombre del jugador
	 */
	private JLabel nombreJugador;
	
	/**
	 * Descripcion: Etiqueta para la calle 
	 */
	private JLabel lblCalle;
	
	/**
	 * Descripcion: Boton para repartir las cartas
	 */
	private JButton btnRepartirCartas;
	
	/**
	 * Descripcion: Boton para iniciar nueva partida
	 */
	private JButton btnIniciarNuevaPartida;
	
	/**
	 * Descripcion: Panel auxiliar donde se cargaran las mesas del casino
	 */
	private JPanel panelsito;
	
	/**
	 * Descripcion: Relacion con el Panel Juego
	 */
	private PanelJuego pJuego;
	
	//CONSTRUCTOR
	
	/**
	 * Descripcion: Construye el panel e inicializa sus componentes
	 */
	public PanelMesas(PanelJuego pJ,int numMesa, int cantJug, int laCalle, double laApuesta, String[] losNombres, int[] lasPartGan, double[] elDinGanJug, String[][] lasCartas){
		
		pJuego = pJ;
		
		numeroDeMesa = numMesa;
		cantidadJugadores = cantJug;
		calle = laCalle;
		apuesta = laApuesta;
		nombresJugadores = losNombres;
		partidasGanadasJugadores = lasPartGan;
		dineroGanadoJugadores = elDinGanJug;
		
		cartasMesa = lasCartas;
		
        Border marco = new LineBorder(Color.BLACK);
        mesa = new JLabel[cantidadJugadores][MAX_COLUMNAS];
        
        setLayout(new BorderLayout());
        setPreferredSize(new Dimension(470, 200));
      
        panelsito = new JPanel();
        panelsito.setLayout(new GridLayout(cantidadJugadores, MAX_COLUMNAS));
        scroll = new JScrollPane();
		
		for (int i = 0; i < cantidadJugadores; i++) {
			for (int j = 0; j < MAX_COLUMNAS; j++) {
				
			if(j == 0){
				
				mesa[i][j] = new JLabel();
				mesa[i][j].setLayout(new BorderLayout());
				mesa[i][j].add(new PanelImagen("./data/imagenes/usuario.jpg"), BorderLayout.CENTER);
				nombreJugador = new JLabel(nombresJugadores[i]);
				nombreJugador.setHorizontalAlignment(JLabel.CENTER);
				nombreJugador.setVerticalAlignment(JLabel.CENTER);
				mesa[i][j].add(nombreJugador, BorderLayout.SOUTH);
				mesa[i][j].setBorder(marco);
				panelsito.add(mesa[i][j]);
				
			}
			if(j == 1){
				
				mesa[i][j] = new JLabel();
				mesa[i][j].setText("<html><center><p>Partidas</p></center> "
						        + "<center><p>Ganadas:</p></center> <center><p>"
						       +partidasGanadasJugadores[i]+" </p></center></html>");
				mesa[i][j].setBorder(marco);
				mesa[i][j].setHorizontalAlignment(JLabel.CENTER);
				mesa[i][j].setVerticalAlignment(JLabel.CENTER);
				panelsito.add(mesa[i][j]);
				
		    }
            if(j == 2){
				
				mesa[i][j] = new JLabel();
				mesa[i][j].setText("<html><center><p>Dinero:</p></center> "
				              +dineroGanadoJugadores[i]+" </p></center></html>");
				if(dineroGanadoJugadores[i] < 0){
					mesa[i][j].setForeground(Color.RED);
				}else{
					mesa[i][j].setForeground(new Color(0, 204, 0));
				}
				mesa[i][j].setBorder(marco);
				mesa[i][j].setHorizontalAlignment(JLabel.CENTER);
				mesa[i][j].setVerticalAlignment(JLabel.CENTER);
				panelsito.add(mesa[i][j]);
		    }
			if(j>2){
	
			mesa[i][j] = new JLabel();
			if(darCartaJugador(i, j).equals("sinCarta")){
				mesa[i][j].setIcon(new ImageIcon("./data/cartas/"+darCartaJugador(i, j)+".png"));
				mesa[i][j].setHorizontalAlignment(JLabel.CENTER);
				mesa[i][j].setVerticalAlignment(JLabel.CENTER);
			
			}else{
				mesa[i][j].setIcon(new ImageIcon("./data/cartas/"+darCartaJugador(i, j)+".png"));
				mesa[i][j].setHorizontalAlignment(JLabel.CENTER);
				mesa[i][j].setVerticalAlignment(JLabel.CENTER);
				
			}
			mesa[i][j].setBorder(marco);
			panelsito.add(mesa[i][j]);
			
			
			
			}
		   }
		  }
		JPanel panelOpciones = new JPanel();
		panelOpciones.setLayout(new GridLayout(1, 3));
		lblCalle = new JLabel("Calle :"+calle+"    "+"Apuesta :"+" "+apuesta);
		
		//--------------------------------------------------------------------
		btnRepartirCartas = new JButton("Repartir Cartas");
		if(calle != 5){
			btnRepartirCartas.setActionCommand(REPARTIR_CARTAS);
			btnRepartirCartas.addActionListener(this);
		}else{
			btnRepartirCartas.setText("Ganador");
			btnRepartirCartas.setActionCommand(GANADOR);
			btnRepartirCartas.addActionListener(this);
		}
		
		//--------------------------------------------------------------------
		
		btnIniciarNuevaPartida = new JButton("Iniciar Nueva Partida");
		btnIniciarNuevaPartida.setActionCommand(INICIAR_NUEVA_PARTIDA);
		btnIniciarNuevaPartida.addActionListener(this);
		
		
		//--------------------------------------------------------------------
		
		panelOpciones.add(lblCalle);
		panelOpciones.add(btnRepartirCartas);
		btnRepartirCartas.setPreferredSize(new Dimension(200, 10));
		panelOpciones.add(btnIniciarNuevaPartida);
		scroll.setViewportView(panelsito);
		add(scroll, BorderLayout.CENTER);
		add(panelOpciones, BorderLayout.SOUTH);
		
    }
	
	/**
	 * Descripcion: Metodo auxliar para poder retornar la carta del jugador de la matriz mesa
	 * @param jugador - El jugador al que se le buscara la carta
	 * @param pos - Posicion de la carta
	 * @return La carta
	 */
	public String darCartaJugador(int jugador, int pos){
		String mensaje = "";
		switch (pos) {
		case 3:
			mensaje = cartasMesa[jugador][0];
			break;
		case 4:
			mensaje = cartasMesa[jugador][1];
			break;
		case 5:
			mensaje = cartasMesa[jugador][2];
			break;
		case 6:
			mensaje = cartasMesa[jugador][3];
			break;
		case 7:
			mensaje = cartasMesa[jugador][4];
			break;
		}
		return mensaje;
	}
	
	/**
	 * Descripcion: Metodo que le asigna una accion a cada boton
	 */
	public void actionPerformed(ActionEvent evento) {
		String comando = evento.getActionCommand();
		if(comando.equals(REPARTIR_CARTAS)){
			pJuego.cambiarMesaParaCambio(numeroDeMesa);
			pJuego.repartirCartas();
		}else if(comando.equals(INICIAR_NUEVA_PARTIDA)){
			pJuego.cambiarMesaParaCambio(numeroDeMesa);
			pJuego.iniciarNuevaPartida();
		}else if(comando.equals(GANADOR)){
			pJuego.cambiarMesaParaCambio(numeroDeMesa);
			pJuego.conocerGanador();
		}
		
	}
}
