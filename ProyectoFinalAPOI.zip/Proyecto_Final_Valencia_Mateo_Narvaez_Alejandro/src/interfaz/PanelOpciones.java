package interfaz;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;


public class PanelOpciones extends JPanel implements ActionListener{
	
	//CONSTANTES
	
	/**
	 * Descripcion: Comando para cargar un juego de la carpeta Properties
	 */
	public final static String CARGAR_JUEGO = "CARGAR_JUEGO";
	
	//Atributos
	
	/**
	 * Descripcion: Boton para cargar el juego
	 */
	private JButton btnCargarJuego;
	
	//RELACIONES
	
	/**
	 * Descripcion: Relacion con la clase principal de la interfaz 
	 */
	private InterfazPoker ventana;
	
	//CONSTRUCTOR
	
	/**
	 * Descripcion: Construye el panel e inicializa sus componentes
	 */
	public PanelOpciones(InterfazPoker v){
		
		ventana = v;
		
		TitledBorder titulo = BorderFactory.createTitledBorder("Cargar");
		titulo.setTitleColor(Color.BLACK);
		setBorder(titulo);
		
		setLayout(new GridLayout(1, 1));
		
		btnCargarJuego = new JButton("Cargar Juego");
		btnCargarJuego.addActionListener(this);
		btnCargarJuego.setActionCommand(CARGAR_JUEGO);
		
		add(btnCargarJuego);
	}

	/**
	 * Descripcion: Metodo que le asigna una accion a cada boton
	 */
	public void actionPerformed(ActionEvent evento) {
		String comando = evento.getActionCommand();
		if(comando.equals(CARGAR_JUEGO)){
			try {
				ventana.nuevoJuego();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
