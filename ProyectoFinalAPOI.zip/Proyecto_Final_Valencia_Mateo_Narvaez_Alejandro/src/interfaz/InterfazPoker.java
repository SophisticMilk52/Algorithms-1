package interfaz;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Event;
import java.awt.GridLayout;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;

import mundo.Poker;
import sun.audio.AudioPlayer;
import sun.audio.AudioStream;
import mundo.Mesa;

/**
 * Descripcion: Clase principal de la interfaz
 * @author Mateo Valencia Gaviria Y Alejandro Narvaez Carvajal
 *
 */
public class InterfazPoker extends JFrame{
	
	//ATRIBUTOS
   
	/**
	 * Descripcion: Panel que contiene el banner de la interfaz
	 */
	private PanelImagen banner;
	
	/**
	 * Descripcion: Panel que contiene las opciones de la interfaz
	 */
	private PanelOpciones opciones;
	
	/**
	 * Descripcion: Panel donde se mostraran las mesas de la interfaz
	 */
	private PanelJuego juego;
	
	/**
	 * Descripcion: Scroll para poder visualizar las mesas
	 */
	private JScrollPane scroll;
	
	/**
	 * Descripcion: Atributo para reconocer si la musica ya esta reproduciendo
	 */
	private static boolean reproductor;
	
	//RELACIONES
	
	/**
	 * Descripcion: Relacion con la clase principal del mundo
	 */
	private Poker poker;
	
	/**
	 * Descripcion: Constructor de la clase principal de la interfaz
	 */
	public InterfazPoker(){
		
		poker = new Poker();
		
        setTitle("Poker");
		setPreferredSize(new Dimension(955, 750));
		setResizable(false);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		setLayout(new BorderLayout());
		
		banner = new PanelImagen("./data/imagenes/banner.jpg");		
		opciones = new PanelOpciones(this);
		juego = new PanelJuego(this);
		
		scroll = new JScrollPane();
	
		scroll.setViewportView(juego);

		add(banner, BorderLayout.NORTH);
		add(scroll, BorderLayout.CENTER);
	    add(opciones, BorderLayout.SOUTH);
	    pack();
	   
	}
	
	/**
	 * Descripcion: Reinicia la interfaz
	 * @throws Exception 
	 */
	public void nuevoJuego() throws Exception{
		dispose();
		main(null);
	}
	
	/**
	 * Descripcion: Actualiza el panel Juego
	 */
	public void refrescarPanelJuego(){
		juego.removeAll();
		juego.establecerPanelJuego();
		juego.revalidate();
	}
	
	/**
	 * Descripcion: Inicializa los componentes para iniciar la interfaz
	 * @param poker - Objeto poker del mundo
	 */
	public void inicializarComponentes(Poker poker){
		setLayout(new GridLayout(2, poker.darCantidadMesas()));
	}
	
	/**
	 * Descripcion: Retorna la cantidad de Jugadores por una mesa dada por parametro
	 * @param mesa - Es la mesa que contiene los jugadores
	 * @return La cantidad de jugadores
	 */
	public int darCantidadJugadoresMesa(int mesa){
		return poker.darMesas().get(mesa).darCantidadJugadores();
	}
	
	
	/**
	 * Descripcion: Retorna la calle de la mesa dada por parametro
	 * @param mesa - Es la mesa que contiene la calle
	 * @return La calle de la mesa
	 */
    public int darCalleMesa(int mesa){
		return poker.darMesas().get(mesa).darCalle();
	}
    
    /**
     * Descripcion: Retorna la apuesta inicial de la mesa
     * @param mesa - Es la mesa que contiene la apuesta
     * @return La apuesta inicial de la mesa
     */
    public double darApuestaMesa(int mesa){
		return poker.darMesas().get(mesa).darApuesta();
	}
    
    /**
     * Descripcion: Retorna un arreglo con los nombres de los jugadores 
     * de la mesa dada por parametro
     * @param mesa - Es la mesa que contiene el arreglo con los nombres
     * @return Arreglo con los nombres de los jugadores
     */
    public String[] darNombresMesa(int mesa){
		return poker.darMesas().get(mesa).darNombresJugadores();
	}
    
    /**
     * Descripcion: Retorna un arreglo con las partidas ganadas de los jugadores 
     * de la mesa dada por parametro
     * @param mesa - Es la mesa que contien el arreglo de partidas ganadas
     * @return Arreglo con el numero de partidas ganadas de los jugadores
     */
    public int[] darPartidasGanadasMesa(int mesa){
    	return poker.darMesas().get(mesa).darPartidasGanadasJugadores();
    }
    
    /**
     * Descripcion: Retorna un arreglo con el dinero ganado de los jugadores 
     * de la mesa dada por parametro
     * @param mesa - Es la mesa que contiene el arreglo del dinero ganado
     * @return Arreglo con el dinero ganado de los jugadores
     */
    public double[] darDineroGanadoMesa(int mesa){
    	return poker.darMesas().get(mesa).darDineroGanadoJugadores();
    }
    
    /**
     * Descripcion: Retorna una matriz con las cartas de los jugadores de la mesa
     * dada por parametro
     * @param mesa - Es la mesa que contiene la matriz de cartas
     * @return Matriz con las cartas de los jugadores
     */
    public String[][] darCartasMesa(int mesa){
		return poker.darMesas().get(mesa).darCartasMesa();
	}

    /**
     * Descripcion: Carga el archivo properties
     */
	public void cargarArchivo(){
		boolean cargo = false;
		JFileChooser fc = new JFileChooser("./data/properties");
		fc.setDialogTitle("Abrir Casino");
		
		File archivoPoker = null;
		do{
			int resultado = fc.showOpenDialog(this);
			if(resultado == JFileChooser.APPROVE_OPTION){
				archivoPoker = fc.getSelectedFile();
			
				if(archivoPoker!=null){
					try{
						
						poker.cargarArchivo(archivoPoker);
						cargo = true;
					}catch(Exception e){
						JOptionPane.showMessageDialog(this, e.getMessage());
					}
				}
				juego.cambiarCantidadMesas(poker.darCantidadMesas());
				juego.establecerPanelJuego();
				reproductor = true;
				
			}
			
			if(!cargo){
				int respuesta = JOptionPane.showConfirmDialog(this, "Hubo un error al cargar el archivo.\n�Desea salir del programa?");
				if(respuesta==JOptionPane.YES_OPTION){
					System.exit(0);
				}
			}
		}while(!cargo);
		
	}
	
	/**
	 * Descripcion: Gestiona la opcion de repartir cartas a la mesa dada por parametro
	 * @param mesa - Es la mesa donde se repartiran las cartas
	 */
	public void gestionarRepartirCartasPorMesa(int mesa){
		poker.repartirCartasPorMesa(mesa);
		refrescarPanelJuego();
	}

	/**
	 * Descripcion: Gestiona la opcion de iniciar una nueva partida a la mesa dada por parametro
	 * @param mesa - Es la mesa donde se iniciara la nueva partida
	 */
	public void gestionarIniciarNuevaPartida(int mesa){
		poker.iniciarNuevaPartidaMesa(mesa);
		refrescarPanelJuego();
	}
	
	/**
	 * Descripcion: Gestiona la opcion de mostrar quien es el ganador de la mesa dada por parametro.
	 * Se mostrara un mensaje con el nombre del ganador y la mano con la que gano
	 * @param mesa - Es la mesa donde se determinara quien es el ganador de la partida
	 */
	public void gestionarBuscarGanadorMesa(int mesa){
		JOptionPane.showMessageDialog(this, poker.darMesas().get(mesa).generarMensajeDelGanador(), "Mesa: "+(mesa+1), 1);	
		refrescarPanelJuego();
	}
	
	/**
	 * Descripcion: Ejecuta la aplicaci�n
	 * @param args Son los par�metros de ejecuci�n de la aplicaci�n. No deben usarse.
	 * @throws Exception 
	 */
    public static void main(String[] args) throws Exception{
		InterfazPoker ventana = new InterfazPoker();
		if(reproductor == false){			
			musica();
		}
		ventana.cargarArchivo();
		ventana.setVisible(true);
	}
    public static void musica()  throws Exception        
    {
        
        String sonido = "./data/sonido/musica.wav";
        
        InputStream in = new FileInputStream(sonido);
        
        AudioStream audio = new AudioStream(in);
       
        AudioPlayer.player.start(audio);
    }

	
}
