package interfaz;

import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;

public class PanelImagen  extends JPanel{

	/**
	 * Descripcion: Es la etiqueta para las imagenes
	 */
    private JLabel imagen;
	
    
    /**
	 * Descripcion: Construye el panel e inicializa sus componentes
	 * @param ruta - Es la ruta para encontrar la imagen
	 */
	public PanelImagen(String ruta){
		
		setLayout(new BorderLayout());
	
		imagen = new JLabel( );
		ImageIcon icono = new ImageIcon(ruta);
        imagen.setIcon( icono );
		imagen.setVerticalAlignment(JLabel.CENTER);
		imagen.setHorizontalAlignment(JLabel.CENTER);
        
        add(imagen, BorderLayout.CENTER);
	}
}
