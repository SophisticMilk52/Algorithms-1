package interfaz;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.TitledBorder;

public class PanelJuego extends JPanel{
	
	//CONSTANTES

	/**
	 * Descripcion: Constante que determina el maximo de filas para ubicar las mesas
	 */
    private final static int MAX_FILAS = 2;
    
    //ATRIBUTOS
    
    /**
     * Descripcion: Atributo que determina a que mesa se le hara algun cambio requerido por el usuario
     */
    private int mesaParaCambio;
   
    /**
     * Descripcion: Atributo que contiene la cantidad de mesas que hay en el casino
     */
    private int cantidadMesas;
	
    /**
     * Descripcion: Scroll para poder visualizar las mesas en el Panel Juego
     */
    private JScrollPane scroll;
    
    //RELACIONES
	
    /**
     * Descripcion: Relacion con el panel que creara todas las mesas del casino
     */
  	private PanelMesas mesa;
  	
  	/**
  	 * Descripcion: Relacion con la clase principal de la interfaz
  	 */
  	private InterfazPoker interfaz;
  
  	//CONSTRUCTOR
  	
  	/**
	 * Descripcion: Construye el panel e inicializa sus componentes
	 */
  	public PanelJuego(InterfazPoker v){
  		
  		interfaz = v;
  		mesaParaCambio = 0;
  		
  	}
  
  	/**
  	 * Descripcion: Metodo para establecer/refrescar el Panel Juego
  	 */
  	public void establecerPanelJuego(){
  	
  		setLayout(new GridLayout(MAX_FILAS, cantidadMesas));
  		
            for (int i = 0; i < cantidadMesas; i++) {
			mesa = new PanelMesas(this, i,
					              interfaz.darCantidadJugadoresMesa(i), 
					              interfaz.darCalleMesa(i), 
					              interfaz.darApuestaMesa(i), 
					              interfaz.darNombresMesa(i), 
					              interfaz.darPartidasGanadasMesa(i),
					              interfaz.darDineroGanadoMesa(i),
					              interfaz.darCartasMesa(i));
			
			TitledBorder titulo = BorderFactory.createTitledBorder("Mesa "+(i+1));
			titulo.setTitleColor(Color.BLACK);
			mesa.setBorder(titulo);
						
			scroll = new JScrollPane();
		
			scroll.setViewportView(mesa);
			
			add(scroll);
			
		}	 
  	}
  	
  	/**
  	 * Descripcion: Retorna la cantidad de mesas que hay en el casino
  	 * @return La cantidad de mesas
  	 */
  	public int darCantidadMesas(){
  		return cantidadMesas;
  	}
  	
  	/**
  	 * Descripcion: Cambia la cantidad de mesas del casino
  	 * @param laCantidad - Nueva cantidad de mesas
  	 */
  	public void cambiarCantidadMesas(int laCantidad){
  		cantidadMesas = laCantidad;
  	}
  	
  	/**
  	 * Descripcion: Cambia la mesa que determinara donde se haran los cambios determinados por el usuario
  	 * @param mesa
  	 */
  	public void cambiarMesaParaCambio(int mesa){
  		mesaParaCambio = mesa;
  	}
  	
  	/**
  	 * Descripcion: Conexion con la clase principal para gestionar la opcion de repartir cartas
  	 */
  	public void repartirCartas(){
  		interfaz.gestionarRepartirCartasPorMesa(mesaParaCambio);
  	}
  	
  	/**
  	 * Descripcion: Conexion con la clase principal para gestionar la opcion de iniciar nueva partida
  	 */
  	public void iniciarNuevaPartida(){
  		interfaz.gestionarIniciarNuevaPartida(mesaParaCambio);
  	}
  	
  	/**
  	 * Descripcion: Conexion con la clase principal para gestionar la opcion de buscar el ganador
  	 */
  	public void conocerGanador(){
  		interfaz.gestionarBuscarGanadorMesa(mesaParaCambio);
  	}
  	

}
