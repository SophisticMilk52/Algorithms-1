package interfaz;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.util.ArrayList;

import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

import mundo.Bancada;
import mundo.Diputado;

@SuppressWarnings("serial")
public class PanelParlamento extends JPanel{
	private JPanel panelPlenaria;
	public PanelParlamento(){
	}
	
	public void organizarBancadas(Bancada[] bancadas){
		removeAll();
		setLayout(new BorderLayout());
		panelPlenaria = new JPanel();
		add(panelPlenaria, BorderLayout.CENTER);
		
		panelPlenaria.setBorder(new TitledBorder("Plenaria"));
		panelPlenaria.setLayout(new GridLayout(0,14,1,1));
		for(int i=0;i<bancadas.length;i++){
			if(bancadas[i]!=null){
				organizarDiputados(bancadas[i].darNombre(),bancadas[i].darDiputados());
			}
		}
		revalidate();
	}
	
	private void organizarDiputados(String nombrePartido, ArrayList<Diputado> diputados){
		for(int i=0;i<diputados.size();i++){
			panelPlenaria.add(new PanelDiputado(nombrePartido, diputados.get(i)));
		}
	}
}
