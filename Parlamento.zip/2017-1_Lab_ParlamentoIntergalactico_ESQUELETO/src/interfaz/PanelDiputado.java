package interfaz;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.text.DecimalFormat;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;

import mundo.Bancada;
import mundo.Diputado;

@SuppressWarnings("serial")
public class PanelDiputado extends JPanel{
	private JLabel labFoto;
	private JLabel labVotos;
	private JLabel labSalario;
	private JLabel labProyectosT;
	private JLabel labProyectosA;
	
	public PanelDiputado(String nombrePartido, Diputado dip){
		setLayout(new BorderLayout());
		
		DecimalFormat df = new DecimalFormat();
		df.applyPattern("###,###");
		
		labFoto       = new JLabel(new ImageIcon(dip.darArchivoFoto()));
		labVotos      = new JLabel(df.format(dip.darVotosEnElecciones())+" votos");
		labSalario    = new JLabel("$"+df.format(dip.darSalario()));
		labProyectosA = new JLabel(dip.darProyectosAprobados()+" aprobados");
		labProyectosT = new JLabel(dip.darProyectosTotales()+" totales");
		
		labVotos.setFont(new Font("Helvetica",Font.PLAIN,10));
		labSalario.setFont(new Font("Helvetica",Font.PLAIN,10));
		labProyectosA.setFont(new Font("Helvetica",Font.PLAIN,10));
		labProyectosT.setFont(new Font("Helvetica",Font.PLAIN,10));
		
		setBorder(darBordePartido(nombrePartido));
		
		JPanel panelInfo = new JPanel();
		panelInfo.setLayout(new GridLayout(0,1));
		panelInfo.add(labVotos);
		panelInfo.add(labSalario);
		panelInfo.add(labProyectosT);
		panelInfo.add(labProyectosA);
		
		add(labFoto,BorderLayout.CENTER);
		add(panelInfo,BorderLayout.SOUTH);
	}
	
	private Border darBordePartido(String np){
		Border b = new LineBorder(Color.BLACK);
		
		if(np.equals(Bancada.TRICOLOR)){
			Border x = new MatteBorder(2,2,2,2,Color.YELLOW);
			Border y = new MatteBorder(2,2,2,2,Color.BLUE);
			Border z = new MatteBorder(2,2,2,2,Color.RED);
			
			Border p = new CompoundBorder(x,y);
			b = new CompoundBorder(p,z);
		}else{
			Color lc = darColorPartido(np);
			b = new MatteBorder(6,6,6,6,lc);
		}
		
		return b;
	}
	
	private Color darColorPartido(String np){
		Color c = Color.WHITE;
		if(np.equals(Bancada.AMARILLO)){
			c = Color.YELLOW;
		}else if(np.equals(Bancada.AZUL)){
			c = Color.BLUE;
		}else if(np.equals(Bancada.ROJO)){
			c = Color.RED;
		}else if(np.equals(Bancada.NARANJA)){
			c = Color.ORANGE;
		}else if(np.equals(Bancada.VERDE)){
			c = Color.GREEN;
		}else if(np.equals(Bancada.ROSA)){
			c = Color.PINK;
		}else if(np.equals(Bancada.VIOLETA)){
			c = new Color(102,0,153);
		}else if(np.equals(Bancada.GRIS)){
			c = Color.GRAY;
		}else if(np.equals(Bancada.CAFE)){
			c = new Color(150,75,0);
		}
		return c;
	}
}
