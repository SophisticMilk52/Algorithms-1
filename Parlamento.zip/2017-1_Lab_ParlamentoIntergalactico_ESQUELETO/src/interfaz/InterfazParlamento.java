package interfaz;

import java.awt.BorderLayout;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import mundo.Bancada;
import mundo.Diputado;
import mundo.Parlamento;

@SuppressWarnings("serial")
public class InterfazParlamento extends JFrame {

	private String[][] personajes;
	private final static String[] partidos = { Bancada.AMARILLO, Bancada.AZUL,
			Bancada.ROJO, Bancada.NARANJA, Bancada.VERDE, Bancada.TRICOLOR,
			Bancada.ROSA, Bancada.VIOLETA, Bancada.GRIS, Bancada.CAFE };

	private PanelOpciones panelOpciones;
	private PanelParlamento panelParlamento;
	private Parlamento parlamento;

	public InterfazParlamento() {
		setLayout(new BorderLayout());
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setTitle("Parlamento Intergal�ctico");

		parlamento = new Parlamento();
		panelParlamento = new PanelParlamento();
		panelOpciones = new PanelOpciones(this);
		add(new JLabel(new ImageIcon("img/banner.png")), BorderLayout.NORTH);
		add(panelOpciones, BorderLayout.CENTER);
		add(panelParlamento, BorderLayout.SOUTH);

		generarParlamento();

		pack();
		// System.out.println(getWidth()+","+getHeight());
		setResizable(false);
	}

	public void generarParlamento() {
		parlamento.cambiarBancadas(generarBancadas());
		actualizarPlenaria();
	}

	private void actualizarPlenaria() {
		panelParlamento.organizarBancadas(parlamento.darBancadas());
	}

	private Bancada[] generarBancadas() {
		Bancada[] bancs = new Bancada[Parlamento.MAX_BANCADAS];
		inicializarPersonajes();

		int maximo = personajes.length / 2;
		int totalDiputados = generarAleatorio((maximo * 5) / 8, maximo);

		int[] dipsXBanc = generarCantidadDipsXBancada(
				(Parlamento.MAX_BANCADAS * 6) / 10, totalDiputados);

		ArrayList<Integer> parts = new ArrayList<Integer>();
		for (int i = 0; i < partidos.length; i++) {
			parts.add(i);
		}

		ArrayList<Integer> pers = new ArrayList<Integer>();
		for (int i = 0; i < personajes.length; i++) {
			pers.add(i);
		}

		for (int i = 0; i < dipsXBanc.length; i++) {
			int numPar = generarAleatorio(0, parts.size() - 1);
			String partido = partidos[parts.get(numPar)];
			parts.remove(numPar);

			ArrayList<Diputado> dips = new ArrayList<Diputado>();
			// System.out.println("\n"+partido);
			for (int j = 0; j < dipsXBanc[i]; j++) {
				int numPerso = generarAleatorio(0, pers.size() - 1);
				int posPerso = pers.get(numPerso);
				pers.remove(numPerso);

				String nombre = personajes[posPerso][1];
				// System.out.println("  "+nombre);
				String rutaFoto = "img/" + personajes[posPerso][0] + ".png";
				int vee = generarAleatorio(1500000, 8500000);
				double sal = generarAleatorio(10000000, 30000000);
				int proTot = generarAleatorio(1, 10);
				int proApro = generarAleatorio(0, proTot);
				dips.add(new Diputado(nombre, rutaFoto, vee, sal, proTot,
						proApro));
			}
			bancs[i] = new Bancada(partido, dips);
		}

		return bancs;
	}

	private int[] generarCantidadDipsXBancada(int numBancs, int totalDiputados) {
		// System.out.println(numBancs);
		int[] diputadosXBancada = new int[numBancs];

		for (int i = 0; i < diputadosXBancada.length; i++) {
			diputadosXBancada[i] = 1;
			totalDiputados--;
		}

		for (int i = 0; i < diputadosXBancada.length - 1; i++) {
			int equitativo = totalDiputados / (diputadosXBancada.length - i);
			int masDips = generarAleatorio(equitativo / 3, (equitativo * 3) / 2);
			diputadosXBancada[i] += masDips;
			totalDiputados = totalDiputados - masDips;
		}

		diputadosXBancada[diputadosXBancada.length - 1] += totalDiputados;

		/*
		 * for (int i = 0; i < diputadosXBancada.length; i++) {
		 * System.out.print(diputadosXBancada[i]+" "); } System.out.println("");
		 */

		return diputadosXBancada;
	}

	private int generarAleatorio(int min, int max) {
		return (int) (Math.random() * (max - min + 1)) + min;
	}

	private void inicializarPersonajes() {
		String[][] pers = { { "01", "Roy" }, { "02", "Alan" },
				{ "03", "Lance" }, { "04", "Marcus" }, { "05", "Bors" },
				{ "06", "Wolt" }, { "07", "Dieck" }, { "08", "Lot" },
				{ "09", "Wade" }, { "10", "Thany" }, { "11", "Elen" },
				{ "12", "Merlinus" }, { "13", "Chad" }, { "14", "Lugh" },
				{ "15", "Clarine" }, { "16", "Rutger" }, { "17", "Dorothy" },
				{ "18", "Saul" }, { "19", "Sue" }, { "20", "Treck" },
				{ "21", "Zealot" }, { "22", "Noah" }, { "23", "Lilina" },
				{ "24", "Astohl" }, { "25", "Oujay" }, { "26", "Wendy" },
				{ "27", "Barth" }, { "28", "Fir" }, { "29", "Shin" },
				{ "30", "Geese" }, { "31", "Gonzales" }, { "32", "Lalum" },
				{ "33", "Klein" }, { "34", "Tate" }, { "35", "Elfin" },
				{ "36", "Ekidona" }, { "37", "Bartre" }, { "38", "Rei" },
				{ "39", "Cass" }, { "40", "Milady" }, { "41", "Percival" },
				{ "42", "Cecilia" }, { "43", "Sophia" }, { "44", "Igrene" },
				{ "45", "Garet" }, { "46", "Fa" }, { "47", "Hugh" },
				{ "48", "Zies" }, { "49", "Douglas" }, { "50", "Yunno" },
				{ "51", "Dayan" }, { "52", "Niime" }, { "53", "Yoder" },
				{ "54", "Karel" }, };
		personajes = pers;
	}

	public void gestionarOpcion1() {
		String nombre = JOptionPane
				.showInputDialog("Por favor digite el nombre del diputado a eliminar:");
		boolean eliminado = parlamento.eliminarCorrupto(nombre);
		if (eliminado) {
			actualizarPlenaria();
			JOptionPane.showMessageDialog(this, "El diputado con el nombre "
					+ nombre + " fue eliminado exitosamente!");
		} else {
			JOptionPane.showMessageDialog(this, "El diputado con el nombre "
					+ nombre + " no pudo ser eliminado.");
		}
	}

	public void gestionarOpcion2() {
		try {
			double valorVoto = Double.parseDouble(JOptionPane
					.showInputDialog("Por favor digite el valor del voto:"));
			parlamento.actualizarSalariosDiputados(valorVoto);
			actualizarPlenaria();
			JOptionPane.showMessageDialog(this,
					"Los salarios de todos los diputados fueron actualizados.");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void gestionarOpcion3() {
		// TODO Auto-generated method stub
		int eliminados = parlamento.eliminarDiputadosConMenosVotosPorBancada();
		actualizarPlenaria();
		JOptionPane.showMessageDialog(this, "Se eliminaron " + eliminados
				+ " diputados.");
	}

	public void gestionarOpcion4() {
		// TODO Auto-generated method stub
		try {
			int ban1 = Integer
					.parseInt(JOptionPane
							.showInputDialog("Por favor digite la posici�n de la bancada 1 a unir:"));
			int ban2 = Integer
					.parseInt(JOptionPane
							.showInputDialog("Por favor digite la posici�n de la bancada 2 a unir:"));
			int total = parlamento.unirBancadas(ban1, ban2);
			actualizarPlenaria();
			if (total > 0) {
				JOptionPane
						.showMessageDialog(this,
								"La bancada unida tiene ahora " + total
										+ " diputados.");
			} else {
				JOptionPane.showMessageDialog(this,
						"No se realiz� la union de bancadas.");
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void gestionarOpcion5() {
		try {
			Diputado dip = parlamento.encontrarDiputadoMasProyectosTotales();
			JOptionPane.showMessageDialog(
					this,
					"El diputado con mas proyectos totales es:\n" + "Nombre:"
							+ dip.darNombre() + "\n" + "Proyectos Totales:"
							+ dip.darProyectosTotales() + "\n"
							+ "Proyectos Aprobados:"
							+ dip.darProyectosAprobados() + "\n" + "Votos:"
							+ dip.darVotosEnElecciones() + "\n" + "Salario:"
							+ dip.darSalario());
		} catch (NullPointerException ex) {
			JOptionPane
					.showMessageDialog(this,
							"No se encontr� a ning�n diputado!\nEl m�todo est� retornando null :(");
		}
	}

	public void gestionarOpcion6() {
		// TODO Auto-generated method stub
		try {
			Bancada ban = parlamento.encontrarBancadaMejorPromedioProyectos();
			JOptionPane.showMessageDialog(this,
					"La bancada con el mejor promedio de proyectos presentados es:\n"
							+ "Nombre:" + ban.darNombre() + "\n"
							+ "Total Diputados:" + ban.darDiputados().size());
		} catch (NullPointerException ex) {
			JOptionPane
					.showMessageDialog(this,
							"No se encontr� a ninguna bancada!\nEl m�todo est� retornando null :(");
		}
	}

	public static void main(String[] args) {
		InterfazParlamento ventana = new InterfazParlamento();
		ventana.setVisible(true);
	}

}
