package interfaz;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

@SuppressWarnings("serial")
public class PanelOpciones extends JPanel implements ActionListener {
	private JButton butGenerar;
	private JButton butOpcion1;
	private JButton butOpcion2;
	private JButton butOpcion3;
	private JButton butOpcion4;
	private JButton butOpcion5;
	private JButton butOpcion6;

	private final static String GENERAR = "GENERAR";
	private final static String OPCION1 = "OPCION1";
	private final static String OPCION2 = "OPCION2";
	private final static String OPCION3 = "OPCION3";
	private final static String OPCION4 = "OPCION4";
	private final static String OPCION5 = "OPCION5";
	private final static String OPCION6 = "OPCION6";

	private InterfazParlamento principal;

	public PanelOpciones(InterfazParlamento ventana) {
		principal = ventana;

		setLayout(new FlowLayout());
		setBorder(new TitledBorder("Opciones"));

		butGenerar = new JButton("Generar Nuevo Parlamento");
		butOpcion1 = new JButton("Opci�n 1");
		butOpcion2 = new JButton("Opci�n 2");
		butOpcion3 = new JButton("Opci�n 3");
		butOpcion4 = new JButton("Opci�n 4");
		butOpcion5 = new JButton("Opci�n 5");
		butOpcion6 = new JButton("Opci�n 6");

		add(butGenerar);
		add(butOpcion1);
		add(butOpcion2);
		add(butOpcion3);
		add(butOpcion4);
		add(butOpcion5);
		add(butOpcion6);

		butGenerar.setActionCommand(GENERAR);
		butOpcion1.setActionCommand(OPCION1);
		butOpcion2.setActionCommand(OPCION2);
		butOpcion3.setActionCommand(OPCION3);
		butOpcion4.setActionCommand(OPCION4);
		butOpcion5.setActionCommand(OPCION5);
		butOpcion6.setActionCommand(OPCION6);

		butGenerar.addActionListener(this);
		butOpcion1.addActionListener(this);
		butOpcion2.addActionListener(this);
		butOpcion3.addActionListener(this);
		butOpcion4.addActionListener(this);
		butOpcion5.addActionListener(this);
		butOpcion6.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent evt) {
		String comando = evt.getActionCommand();
		if (comando.equals(GENERAR)) {
			principal.generarParlamento();
		} else if (comando.equals(OPCION1)) {
			principal.gestionarOpcion1();
		} else if (comando.equals(OPCION2)) {
			principal.gestionarOpcion2();
		} else if (comando.equals(OPCION3)) {
			principal.gestionarOpcion3();
		} else if (comando.equals(OPCION4)) {
			principal.gestionarOpcion4();
		} else if (comando.equals(OPCION5)) {
			principal.gestionarOpcion5();
		}else if (comando.equals(OPCION6)) {
			principal.gestionarOpcion6();
		}
	}
}
