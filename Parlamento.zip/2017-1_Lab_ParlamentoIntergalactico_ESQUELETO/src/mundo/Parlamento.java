package mundo;

import java.util.ArrayList;

/**
 * La clase Parlamento modela las caracter�sticas y comportamientos de la
 * entidad que representa al parlamento intergal�ctico
 * 
 * @author Juan Manuel Reyes G. <juan.reyes3@correo.icesi.edu.co>
 */
public class Parlamento {
	/***********************************************************
	 * * CONSTANTES * *
	 ***********************************************************/

	/**
	 * Constante para modelar la cantidad m�xima de bancadas que puede tener el
	 * parlamento intergal�ctico
	 */
	public final static int MAX_BANCADAS = 10;

	/***********************************************************
	 * * ATRIBUTOS * *
	 ***********************************************************/

	/**
	 * La contenedora de tama�o fijo que alamacena a las bancadas presentes en
	 * el parlamento
	 */
	private Bancada[] bancadas;

	/***********************************************************
	 * * M�TODOS * *
	 ***********************************************************/

	/**
	 * Crea un nuevo parlamento intergal�ctico
	 */
	public Parlamento() {
	}

	/**
	 * Cambia la contenedora de bancadas del parlamento actual por la pasada por
	 * par�metro
	 * 
	 * @param bancs
	 *            es la nueva contenedora de bancadas que reemplazar� a la
	 *            existente en el parlamento actual
	 */
	public void cambiarBancadas(Bancada[] bancs) {
		bancadas = bancs;
	}

	/**
	 * Retorna la contendora de bancadas del parlamento actual
	 * 
	 * @return bancadas
	 */
	public Bancada[] darBancadas() {
		return bancadas;
	}

	// +eliminarCorrupto(nom:String):boolean
	/**
	 * Busca entre todos los diputados de todas las bancadas al diputado con el
	 * nombre pasado por par�metro y lo elimina de su bancada.<br/>
	 * <br/>
	 * 
	 * <b>pre:</b>bancadas!=null<br/>
	 * <b>pre:</b>bancadas[i].darDiputados()!=null para 0<=i<bancadas.length
	 * solo si bancadas[i] es diferente de null<br/>
	 * <b>pre:</b>bancadas[i].darDiputados().get(j)!=null para
	 * 0<=i<bancadas[i].length y 0<=j<bancadas[i].darDiputados().size() solo si
	 * bancadas[i] es diferente de null <br/>
	 * <br/>
	 * 
	 * <b>post:</b>En los diputados del parlamento no existe un diputado con el
	 * nombre nom<br/>
	 * <br/>
	 * 
	 * @param nom
	 *            es el nombre del diputado a eliminar
	 * @return true si el diputado exist�a y fue eliminado, false de lo
	 *         contrario
	 */
	public boolean eliminarCorrupto(String nom) {
		boolean corrupto = false;

		for (int i = 0; i < bancadas.length && !corrupto; i++) {
			Bancada bancada = bancadas[i];
			if(bancada !=null){
			for (int j = 0; j < bancadas[i].darDiputados().size() && !corrupto; j++) {
				if (bancada.darDiputados().get(j).darNombre().equals(nom)) {
					bancada.darDiputados().remove(j);
					corrupto = true;
				
				}
			   }
				
			}

		}

		return corrupto;
	}

	// +actualizarSalariosDiputados(valorVoto:double):void
	/**
	 * Actualiza el salario de todos los diputados del parlamento (todos los
	 * diputados de todas las bancadas), asign�ndoles un salario directamente
	 * relacionado con los votos obtenidos en su elecci�n, de esta manera: su
	 * salario ser� la cantidad de votos obtenidos multiplicado por un valor
	 * dado al voto (valor que es pasado por par�metro).<br/>
	 * <br/>
	 * 
	 * <b>pre:</b>bancadas!=null<br/>
	 * <b>pre:</b>bancadas[i].darDiputados()!=null para 0<=i<bancadas.length
	 * solo si bancadas[i] es diferente de null<br/>
	 * <b>pre:</b>bancadas[i].darDiputados().get(j)!=null para
	 * 0<=i<bancadas.length y 0<=j<bancadas[i].darDiputados().size() solo si
	 * bancadas[i] es diferente de null <br/>
	 * <br/>
	 * 
	 * <b>post:</b>Los salarios de todos los diputados han cambiado por el nuevo
	 * salario calculado con base en los votos y su valor<br/>
	 * <br/>
	 * 
	 * @param valorVoto
	 *            es el valor que representa cada voto para calcular el salario
	 *            del diputado
	 */
	public void actualizarSalariosDiputados(double valorVoto) {
		if (bancadas != null) {
			
			for (int i = 0; i < bancadas.length; i++) {
				Bancada bancada = bancadas[i];
if(bancada !=null && bancadas[i].darDiputados() != null ){
				for (int j = 0; j < bancadas[i].darDiputados().size(); j++) {
					if(bancadas[i].darDiputados().get(j) != null){
					bancada.darDiputados().get(j)
							.cambiarSalario(valorVoto * bancada.darDiputados().get(j).darVotosEnElecciones());
				}
			}
		}
	}}}
	

	/**
	 * Elimina un diputado de cada una de las bancadas a menos que la bancada
	 * tenga solo un diputado (en cuyo caso no elimina diputados de esa
	 * bancada). El diputado que se va a eliminar de cada bancada es aquel que
	 * menos votos haya obtenido de su bancada en las elecciones.<br/>
	 * <br/>
	 * 
	 * <b>pre:</b>bancadas!=null<br/>
	 * <b>pre:</b>bancadas[i].darDiputados()!=null para 0<=i<bancadas.length
	 * solo si bancadas[i] es diferente de null<br/>
	 * <b>pre:</b>bancadas[i].darDiputados().get(j)!=null para
	 * 0<=i<bancadas[i].length y 0<=j<bancadas[i].darDiputados().size() solo si
	 * bancadas[i] es diferente de null <br/>
	 * <br/>
	 * 
	 * <b>post:</b>Todas las bancadas tienen un diputado menos del que ten�an
	 * antes de la ejecuci�n de este m�todo a menos que la bancada tenga un solo
	 * diputado<br/>
	 * <br/>
	
	 * 
	 * 
	 * @return una cantidad entera que indica la cantidad total de diputados
	 *         eliminados en el parlamento
	 */
	public int eliminarDiputadosConMenosVotosPorBancada() {
		int eliminados= 0;
		for(int i = 0; i < bancadas.length; i++) {
			Bancada bancada = bancadas[i];
			if(bancadas[i]!= null && bancadas[i].darDiputados().size()>1){
				int control=bancadas[i].darDiputados().get(0).darVotosEnElecciones();
				int k=0;
				eliminados++;
			for (int j = 0; j < bancadas[i].darDiputados().size(); j++) {
				if(bancada.darDiputados().get(j).darVotosEnElecciones()<control){
				control=bancada.darDiputados().get(j).darVotosEnElecciones();
				k=j;
				}
				}
	
                 bancada.darDiputados().remove(k);
			
			}
		}
		return eliminados;
			}

	/**
	 * Une dos bancadas en una sola que tienen a los diputados de las dos
	 * bancadas que se unen.<br/>
	 * Se recibe por par�metro las posiciones que las dos (2) bancadas que se
	 * van a unir ocupan en la contenedora de bancadas.<br/>
	 * Una vez se han unido las dos bancadas en una sola, la bancada unida tiene
	 * todos los diputados de las dos bancadas originales y ocupa la posici�n
	 * (en la contenedora de bancadas) de la primera bancada.<br/>
	 * El nombre de la bancada unida es el nombre de la bancada que tiene mas
	 * diputados.<br/>
	 * Si alguna de las bancadas es null entonces no se realiza la uni�n.<br/>
	 * <br/>
	 * 
	 * <b>pre:</b>bancadas!=null<br/>
	 * <b>pre:</b>bancadas[i].darDiputados()!=null para 0<=i<bancadas.length
	 * solo si bancadas[i] es diferente de null<br/>
	 * <b>pre:</b>bancadas[i].darDiputados().get(j)!=null para
	 * 0<=i<bancadas.length y 0<=j<bancadas[i].darDiputados().size() solo si
	 * bancadas[i] es diferente de null <br/>
	 * <br/>
	 * 
	 * <b>post:</b>Si se pudo realizar la uni�n entonces bancadas[posBan2]==null
	 * y la longitud de la contenedora de diputados de la bancada unida es igual
	 * a la longitud de las dos (2) contenedoras de diputados de las dos (2)
	 * bancadas originales<br/>
	 * <br/>
	 * 
	 * @param posBan1
	 *            es la posici�n, en la contenedora de bancadas, de la primera
	 *            bancada a unir.
	 * @param posBan2
	 *            es la posici�n, en la contenedora de bancadas, de la segunda
	 *            bancada a unir.
	 * @return la cantidad total de diputados de la bancada resultante de unir
	 *         las dos bancadas o cero si no hubo uni�n de bancadas.
	 */
	public int unirBancadas(int posBan1, int posBan2) {
		int total = 0;
		int i = 0;
		int j = 0;
		if (bancadas != null) {
			Bancada ban1 = bancadas[posBan1];
			Bancada ban2 = bancadas[posBan2];
			if (bancadas[i].darDiputados().get(j) != null) {
				for (i = 0; i < bancadas.length; i++) {
					
					if (bancadas[posBan1] !=null && bancadas[posBan2] !=null) {

						if (ban1.darDiputados().size() < ban2.darDiputados().size()) {
							Diputado control;
							for (j = 0; j < ban1.darDiputados().size(); j++) {
								control = ban1.darDiputados().get(j);
								ban2.darDiputados().add(control);
								total = ban2.darDiputados().size();
								bancadas[posBan1] = null;
							}
						} else if (ban1.darDiputados().size() > ban2.darDiputados().size())
							for (j = 0; j < ban2.darDiputados().size(); j++) {
								Diputado control2;
								control2 = ban2.darDiputados().get(j);
								ban1.darDiputados().add(control2);
								total = ban1.darDiputados().size();
								bancadas[posBan2] = null;
							}
					}
				}
			}
		}

		return total;
	}

	/**
	 * Busca entre todos los diputados de todas las bancadas a aquel que haya
	 * presentado mas proyectos y lo retorna.<br/>
	 * <br/>
	 * 
	 * <b>pre:</b>bancadas!=null<br/>
	 * <b>pre:</b>bancadas[i].darDiputados()!=null para 0<=i<bancadas.length
	 * solo si bancadas[i] es diferente de null<br/>
	 * <b>pre:</b>bancadas[i].darDiputados().get(j)!=null para
	 * 0<=i<bancadas[i].length y 0<=j<bancadas[i].darDiputados().size() solo si
	 * bancadas[i] es diferente de null <br/>
	 * <br/>
	 * 
	 * @return el diputado con la mayor cantidad de proyectos presentados en
	 *         todo el parlamento
	 */
	public Diputado encontrarDiputadoMasProyectosTotales() {
		Diputado mayor = null;
		int coso = 0;
	
		for (int i = 0; i < bancadas.length; i++) {
	
			if (bancadas[i] != null) {
				for (int j = 0; j < bancadas[i].darDiputados().size(); j++) {

					if (bancadas[i].darDiputados().get(j).darProyectosTotales() > coso) {
						coso = bancadas[i].darDiputados().get(j).darProyectosTotales();
						mayor = bancadas[i].darDiputados().get(j);
					
						}
					}
				}
			}
		
	
		return mayor;
			}

	

	
	/**
	 * Calcula el promedio de proyectos presentados por diputado para cada
	 * bancada y retorna aquella bancada que tiene el mejor promedio.<br/>
	 * <br/>
	 * 
	 * <b>pre:</b>bancadas!=null<br/>
	 * <b>pre:</b>bancadas[i].darDiputados()!=null para 0<=i<bancadas.length
	 * solo si bancadas[i] es diferente de null<br/>
	 * <b>pre:</b>bancadas[i].darDiputados().get(j)!=null para
	 * 0<=i<bancadas[i].length y 0<=j<bancadas[i].darDiputados().size() solo si
	 * bancadas[i] es diferente de null <br/>
	 * <br/>
	 * 
	 * @return la bancada del parlamento que tiene el mejor promedio de
	 *         proyectos presentados por diputado
	 */
	public Bancada encontrarBancadaMejorPromedioProyectos() {
		// TODO
		Bancada promedio = null;
		double coso = 0;
	
			for (int i = 0; i < bancadas.length; i++) {
				if (bancadas[i] != null) {
				for (int j = 0; j < bancadas[i].darDiputados().size(); j++) {
					if (bancadas[i].darPromedioBancada() > coso) {
						coso = bancadas[i].darPromedioBancada();
						promedio = bancadas[i];

					}
				}
			}
		}

		return promedio;
	}
}
