package mundo;

import java.util.ArrayList;

/**
 * La clase Bancada modela las caracter�sticas y comportamientos de la entidad que
 * representa una bancada en el parlamento intergal�ctico.
 * 
 * @author Juan Manuel Reyes G. <juan.reyes3@correo.icesi.edu.co>
 */
public class Bancada {
	/***********************************************************
	 *                                                         *
	 *                        CONSTANTES                       *
	 *                                                         *
	 ***********************************************************/
	
	/**
	 * Constante para modelar la bancada AMARILLO
	 */
	public final static String AMARILLO = "PARTIDO AMARILLO";
	
	/**
	 * Constante para modelar la bancada AZUL
	 */
	public final static String AZUL     = "PARTIDO AZUL";
	
	/**
	 * Constante para modelar la bancada ROJO
	 */
	public final static String ROJO     = "PARTIDO ROJO";
	
	/**
	 * Constante para modelar la bancada NARANJA
	 */
	public final static String NARANJA  = "PARTIDO NARANJA";
	
	/**
	 * Constante para modelar la bancada VERDE
	 */
	public final static String VERDE    = "PARTIDO VERDE";
	
	/**
	 * Constante para modelar la bancada TRICOLOR
	 */
	public final static String TRICOLOR = "PARTIDO TRICOLOR";
	
	/**
	 * Constante para modelar la bancada ROSA
	 */
	public final static String ROSA     = "PARTIDO ROSA";
	
	/**
	 * Constante para modelar la bancada VIOLETA
	 */
	public final static String VIOLETA  = "PARTIDO VIOLETA";
	
	/**
	 * Constante para modelar la bancada GRIS
	 */
	public final static String GRIS     = "PARTIDO GRIS";
	
	/**
	 * Constante para modelar la bancada CAFE
	 */
	public final static String CAFE     = "PARTIDO CAF�";
	
	/***********************************************************
	 *                                                         *
	 *                        ATRIBUTOS                        *
	 *                                                         *
	 ***********************************************************/
	
	/**
	 * Esta caracter�stica representa el nombre de la bancada actual
	 */
	private String nombre;
	
	/**
	 * La contenedora de tama�o variable que contiene a todos los diputados de esta bancada
	 */
	private ArrayList<Diputado> diputados;
	
	/***********************************************************
	 *                                                         *
	 *                        M�TODOS                          *
	 *                                                         *
	 ***********************************************************/
	
	/**
	 * Crea una nueva bancada con el nombre y los diputados pasados por par�metro.<br/>
	 * 
	 * @param nom es el nombre de la nueva bancada y se corresponde con una de las consantes definidas en esta clase
	 * @param dips es la contenedora de tama�o variable que contiene a los diputados de esta bancada
	 */
	public Bancada(String nom, ArrayList<Diputado> dips) {
		nombre       = nom;
		diputados    = dips;
	}

	/**
	 * Retorna el nombre de la bancada actual
	 * @return nombre
	 */
	public String darNombre() {
		
		return nombre;
	}
	/**
	 * Retorna la contenedora con todos los diputados de la bancada actual
	 * @return diputados
	 */
	public ArrayList<Diputado> darDiputados() {
		return diputados;
	}
		/**
		 * Retorna el promedio de cada bancada
		 * @return promedio
		 */
	public double darPromedioBancada() {

		double promedio = 0;
		for (int j = 0; j < this.darDiputados().size(); j++) {
			if (this.darDiputados().get(j).darProyectosTotales() > promedio) {
				promedio += this.darDiputados().get(j).darProyectosTotales();
			}
			promedio = promedio / this.darDiputados().size();
		}
		promedio = promedio / this.darDiputados().size();

		return promedio;

	}
}
