package mundo;

/**
 * La clase Diputado modela las caracter�sticas y comportamientos de la entidad que
 * representa un diputado del parlamento intergal�ctico
 * 
 * @author Juan Manuel Reyes G. <juan.reyes3@correo.icesi.edu.co>
 */
public class Diputado {
	/***********************************************************
	 *                                                         *
	 *                        ATRIBUTOS                        *
	 *                                                         *
	 ***********************************************************/
	
	/**
	 * Esta caracter�stica representa el nombre del diputado.
	 */
	private String nombre;
	
	/**
	 * Esta caracter�stica representa la ruta del archivo que contiene la foto del diputado.
	 */
	private String archivoFoto;
	
	/**
	 * Esta caracter�stica representa la cantidad de votos obtenidos en las elecciones por este diputado.
	 */
	private int votosEnElecciones;
	
	/**
	 * Esta caracter�stica representa el salario que se gana el diputado.
	 */
	private double salario;
	
	/**
	 * Esta caracter�stica representa la cantidad total de proyectos presentados por el diputado ante el parlamento.
	 */
	private int proyectosTotales;
	
	/**
	 * Esta caracter�stica representa la cantidad de proyectos del diputado que han sido aprobados por el parlamento.
	 */
	private int proyectosAprobados;
	
	/***********************************************************
	 *                                                         *
	 *                        M�TODOS                          *
	 *                                                         *
	 ***********************************************************/
	
	/**
	 * Crea un nuevo diputado con su informaci�n b�sica.<br/>
	 * 
	 * @param nom es el nombre del nuevo diputado
	 * @param aFoto es la ruta de la imagen del nuevo diputado
	 * @param vee es la cantidad de votos obtenidos en elecciones
	 * @param sal es el salario del nuevo diputado
	 * @param proTot es la cantidad total de proyectos del nuevo diputado
	 * @param proApro es la cantidad de proyectos que le han aprobado al nuevo diputado 
	 */
	public Diputado(String nom, String aFoto, int vee, double sal, int proTot, int proApro) {
		nombre             = nom;
		archivoFoto        = aFoto;
		votosEnElecciones  = vee;
		salario            = sal;
		proyectosTotales   = proTot;
		proyectosAprobados = proApro;
	}

	/**
	 * Retorna el nombre del diputado
	 * @return nombre
	 */
	public String darNombre() {
		return nombre;
	}

	/**
	 * Retorna la ruta del archivo donde se encuentra la foto del diputado 
	 * @return archivoFoto
	 */
	public String darArchivoFoto() {
		return archivoFoto;
	}

	/**
	 * Retorna la cantidad de votos  del diputado obtenidos en elecciones
	 * @return votosEnElecciones
	 */
	public int darVotosEnElecciones() {
		return votosEnElecciones;
	}

	/**
	 * Retorna el salario actual del diputado
	 * @return salario
	 */
	public double darSalario() {
		return salario;
	}

	/**
	 * Retorna la cantidad total de proyectos presentados por el diputado ante el parlamento
	 * @return proyectosTotales
	 */
	public int darProyectosTotales() {
		return proyectosTotales;
	}

	/**
	 * Retorna la cantidad de proyectos aprobados al diputado en el parlamento
	 * @return proyectosAprobados
	 */
	public int darProyectosAprobados() {
		return proyectosAprobados;
	}

	/**
	 * Cambia el salario del diputado por el valor pasado por par�metro
	 * @param sal el nuevo salario del diputado
	 */
	public void cambiarSalario(double sal) {
		salario = sal;
	}
}
