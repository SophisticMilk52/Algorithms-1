package mundo;

/**
 * Entidad que modela a un competidor de maratones de programaci�n
 * 
 * @author Juan Manuel Reyes <jmreyes@icesi.edu.co>
 * @since 2016-03-03
 */
public class Competidor {
	/**
	 * Constante de dominio que representa el sexo masculino
	 */
	public final static char MASCULINO = 'M'; 
	
	/**
	 * Constante de dominio que representa el sexo femenino
	 */
	public final static char FEMENINO = 'F'; 
	
	/**
	 * Los nombres del competidor
	 */
	private String nombres;
	
	/**
	 * Los apellidos del competidor
	 */
	private String apellidos;
	
	/**
	 * La ruta del archivo con la imagen del avatar de este competidor
	 */
	private String rutaImagen;
	
	/**
	 * La edad del competidor en a�os
	 */
	private int edad;
	
	/**
	 * El sexo del competidor cuyo valor puede ser:<br/>
	 * - MASCULINO<br/>
	 * - FEMENINO
	 */
	private char sexo;
	
	/**
	 * Nombre del equipo al cual pertenece este competidor
	 */
	private String nombreEquipo;
	
	/**
	 * Construye un objeto Competidor
	 * @param nom es el nombre del nuevo competidor
	 * @param ape es el apellido del nuevo competidor
	 * @param ruIm es la ruta del archivo de la imagen del nuevo competidor
	 * @param ed es la edad del nuevo competidor
	 * @param s es el sexo del nuevo competidor
	 * @param nomEq es el nombre del equipo del nuevo competidor
	 */
	public Competidor(String nom, String ape, String ruIm, int ed, char s, String nomEq) {
		nombres = nom;
		apellidos = ape;
		rutaImagen = ruIm;
		edad = ed;
		sexo = s;
		nombreEquipo = nomEq;
	}
	
	/**
	 * Permite consultar el nombre del equipo
	 * @return una cadena con el nombre del equipo
	 */
	public String darNombreEquipo() {
		return nombreEquipo;
	}
	
	/**
	 * Permite consultar los nombres del competidor
	 * @return una cadena con los nombres
	 */
	public String darNombres() {
		return nombres;
	}
	
	/**
	 * Permite consultar los apellidos del competidor
	 * @return una cadena con los apellidos
	 */
	public String darApellidos() {
		return apellidos;
	}
	
	/**
	 * Permie consultar la ruta del archivo con la imagen del avatar del competidor 
	 * @return una cadena con la ruta
	 */
	public String darRutaImagen() {
		return rutaImagen;
	}
	
	/**
	 * Permite consultar la edad del competidor
	 * @return un entero con la edad
	 */
	public int darEdad() {
		return edad;
	}
	
	/**
	 * Permite consultar el sexo del competidor
	 * @return un char con el sexo
	 */
	public char darSexo() {
		return sexo;
	}	
}
