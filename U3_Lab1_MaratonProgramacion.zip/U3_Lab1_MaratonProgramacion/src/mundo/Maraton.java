package mundo;

/**
 * Entidad que modela una marat�n de programaci�n
 * 
 * @author Juan Manuel Reyes <jmreyes@icesi.edu.co>
 * @since 2016-03-03
 */
public class Maraton {
	/**
	 * Constante que representa la cantidad m�xima de equipos registrados en
	 * esta marat�n
	 */
	public static final int MAX_EQUIPOS = 90;

	/**
	 * Constante que representa la cantidad de problemas del problemset de la
	 * marat�n
	 */
	public static final int TAMANO_PROBLEMSET = 10;

	/**
	 * Arreglo de equipos que participan en la marat�n
	 */
	private Equipo[] equipos;

	/**
	 * Construye una nueva marat�n de programaci�n
	 */
	public Maraton() {
		equipos = new Equipo[MAX_EQUIPOS];
	}

	/**
	 * Asigna un equipo pasado por par�metro a la posici�n del arreglo indicada
	 * 
	 * @param nuevoEq
	 *            el objeto del equipo a asignar
	 * @param pos
	 *            un entero con la posici�n donde se asignar� el equipo
	 */
	public void asignarEquipo(Equipo nuevoEq, int pos) {
		equipos[pos] = nuevoEq;
	}

	/**
	 * Permite consultar todos los equipos actuales
	 * 
	 * @return el arreglo con todos los equipos que el mundo tiene en este
	 *         momento
	 */
	public Equipo[] darEquipos() {
		return equipos;
	}

	public Competidor[] obtenerTodosLosCompetidores() {
		int i = 0;
		int j = 0;
		Competidor[] competidores = new Competidor[MAX_EQUIPOS*3];

		for (i = 0; i < equipos.length; i++) {
			if (equipos[i] != null) {
				Equipo eq = equipos[i];
				if (eq.darIntegranteUno() != null) {
					
					competidores[j] = eq.darIntegranteUno();
					j += 1;
				}
				if (eq.darIntegranteDos() != null) {
					competidores[j] = eq.darIntegranteDos();
					j += 1;
				}
				if (eq.darIntegranteTres() != null) {
					competidores[j] = eq.darIntegranteTres();
					j += 1;
				}
			}
	}
	
		return competidores;
	}

	public Equipo[] consultarMejoresEquipos() {
		int i = 0;
		int minimo = TAMANO_PROBLEMSET / 2;
		int j = 0;
	int k=0;
		Equipo[] Mejor = new Equipo[MAX_EQUIPOS];

		for (i = 0; i < equipos.length; i++) {
			if(equipos[i] !=null){
			Equipo eq = equipos[i];
			int resueltos = 0;
		
			for (j = 0; j < eq.darTiempoProblemas().length; j++) {
				if (eq.darTiempoProblemas()[j] != 0) {
					resueltos += 1;
				}
			}
			if (resueltos >= minimo) {
				Mejor[k] = eq;
			k++;
			}	
			}
			
		
	}
		return Mejor;

	}


	public Competidor[] consultarCompetidoresEspeciales() {

		int i = 0;
		int j = 0;
		Competidor[] mujeres = new Competidor[MAX_EQUIPOS*3];
		for (i = 0; i < equipos.length; i++) {

			if (equipos[i] != null) {
				Equipo mu = equipos[i];
				if(mu.darIntegranteUno()!=null){
				if (Competidor.FEMENINO == mu.darIntegranteUno().darSexo() && mu.darIntegranteUno().darEdad() >= 20 && mu.darIntegranteUno().darEdad() <= 25) {
					mujeres[j] = mu.darIntegranteUno();
					j++;}
				}
				if (mu.darIntegranteDos() != null) {
					if (Competidor.FEMENINO == mu.darIntegranteDos().darSexo() && mu.darIntegranteDos().darEdad() >= 20 && mu.darIntegranteDos().darEdad() <= 25) {
						mujeres[j] = mu.darIntegranteDos();
						j++;
					}
				}
				if (mu.darIntegranteTres() != null) {
					if (Competidor.FEMENINO == mu.darIntegranteTres().darSexo()	&& mu.darIntegranteTres().darEdad() >= 20 && mu.darIntegranteTres().darEdad() <= 25) {
						mujeres[j] = mu.darIntegranteTres();
						j++;
					}
				}
			}
		}
		return mujeres;
	}

	public void cancelarMasEquipos() {
		int i = 0;

		for (i = 0; i < equipos.length; i++) {
			if (equipos[i] != null) {
				Equipo lol = equipos[i];
				if (lol.calcularCantidadCompetidores() == 1 && i % 2 == 0) {
					equipos[i] = null;

				}
			}
		}
	}
}
