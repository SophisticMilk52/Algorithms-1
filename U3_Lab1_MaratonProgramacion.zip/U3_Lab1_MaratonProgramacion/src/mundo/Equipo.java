package mundo;

/**
 * Entidad que modela un equipo de competidores en una marat�n de programaci�n
 * @author Juan Manuel Reyes <jmreyes@icesi.edu.co>
 * @since 2016-03-03
 */
public class Equipo {
	/**
	 * El nombre del equipo
	 */
	private String nombre;
	
	/**
	 * La relaci�n hacia el primer integrante del equipo. Siempre es diferente de null, es decir, esta relaci�n es obligatoria.
	 */
	private Competidor integranteUno;
	
	/**
	 * La relaci�n hacia el segundo integrante del equipo. Esta relaci�n es opcional.
	 */
	private Competidor integranteDos;
	
	/**
	 * La relaci�n hacia el tercer integrante del equipo. Esta relaci�n es opcional.
	 */
	private Competidor integranteTres;
	
	/**
	 * La secuencia de tiempos en los que han sido resueltos cada uno de los problemas de la marat�n. Los problemas que no han sido resueltos tienen un tiempo de 0.
	 */
	private double[] tiempoProblemas;
	
	/**
	 * Crea un equipo de maratones de programaci�n
	 * @param nom es el nombre del equipo
	 * @param intUno es el objeto con el primer integrante del equipo
	 * @param tp es la secuencia de tiempos que ha tardado el equipo en resolver cada ejercicio
	 */
	public Equipo(String nom, Competidor intUno, double[] tp){
		nombre = nom;
		integranteUno = intUno;
		tiempoProblemas = tp;
	}
	
	/**
	 * Permite asignar al segundo integrante cuando el equipo tiene a mas de un integrante
	 * @param intDos es el objeto con el segundo integrante
	 */
	public void cambiarIntegranteDos(Competidor intDos){
		integranteDos = intDos;
	}
	
	/**
	 * Permite asignar al tercer integrante cuando el equipo tiene a mas de dos integrantes
	 * @param intTres es el objeto con el tercer integrante
	 */
	public void cambiarIntegranteTres(Competidor intTres){
		integranteTres = intTres;
	}
	
	/**
	 * Permite consultar el nombre de este equipo
	 * @return una cadena con el nombre
	 */
	public String darNombre(){
		return nombre;
	}
	
	/**
	 * Permite consultar al primer integrante
	 * @return un objeto de la clase Competidor con el primer integrante
	 */
	public Competidor darIntegranteUno(){
		return integranteUno;
	}
	
	/**
	 * Permite consultar al segundo integrante
	 * @return un objeto de la clase Competidor con el segundo integrante
	 */
	public Competidor darIntegranteDos(){
		return integranteDos;
	}
	
	/**
	 * Permite consultar al tercer integrante
	 * @return un objeto de la clase Competidor con el tercer integrante
	 */
	public Competidor darIntegranteTres(){
		return integranteTres;
	}
	
	/**
	 * Permite consultar los tiempos en que han sido resueltos los problemas de esa marat�n 
	 * @return un arreglo de double con los tiempos de cada problema
	 */
	public double[] darTiempoProblemas(){
		return tiempoProblemas;
	}

	public int calcularCantidadCompetidores(){
		int Competidores= 0;
		
    if(integranteUno !=null){
	   Competidores+=1;}
	if(integranteDos !=null){
	   Competidores+=1;
	} 
	if (integranteTres !=null){
		Competidores+=1;
		}
	
	
		return Competidores;
	}
}
