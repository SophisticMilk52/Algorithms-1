package interfaz;

import java.awt.BorderLayout;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTabbedPane;

import mundo.Competidor;
import mundo.Equipo;
import mundo.Maraton;

@SuppressWarnings("serial")
public class InterfazMaraton extends JFrame{
	private PanelNavegaEquipos panelNE;
	private PanelOpciones panelOpciones;
	private PanelListadoEquipos panelLE;
	private PanelListadoCompetidores panelLC;
	private Maraton maraton;
	public InterfazMaraton() throws IOException{
		maraton = new Maraton();
		cargarEquipos();
		
		setLayout(new BorderLayout());
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setTitle("Icesi :: Maratones de Programaci�n");
		
		add(new JLabel(new ImageIcon("data/imgs/bannerMaratones.png")),BorderLayout.NORTH);
		
		panelNE = new PanelNavegaEquipos(maraton.darEquipos());
		add(panelNE,BorderLayout.CENTER);
		
		panelOpciones = new PanelOpciones(this);
		add(panelOpciones,BorderLayout.EAST);
		
		panelLE = new PanelListadoEquipos();
		panelLC = new PanelListadoCompetidores();
		
		JTabbedPane panelTab = new JTabbedPane();
		panelTab.add("Equipos", panelLE);
		panelTab.add("Competidores", panelLC);
		
		add(panelTab,BorderLayout.SOUTH);
		
		//cargarTodosEquiposEnLista();
		
		pack();
		//System.out.println("width: "+getWidth());
	}
	
	public void cargarTodosEquiposEnLista(){
		panelLE.refrescarTablaConEquipos(maraton.darEquipos());		
	}
	
	public void cargarTodosCompetidoresEnLista(){
		panelLC.refrescarTablaConCompetidores(maraton.obtenerTodosLosCompetidores());		
	}
	
	public void consultarMejoresEquipos(){
		Equipo[] eqs = maraton.consultarMejoresEquipos();
		panelLE.refrescarTablaConEquipos(eqs);
	}
	
	public void consultarCompetidoresEspeciales(){
		Competidor[] comps = maraton.consultarCompetidoresEspeciales();
		panelLC.refrescarTablaConCompetidores(comps);
	}
	
	public void cancelarMasEquipos(){
		maraton.cancelarMasEquipos();
		panelLE.refrescarTablaConEquipos(maraton.darEquipos());
	}
	
	private void cargarEquipos() throws IOException{
		BufferedReader br = new BufferedReader(new FileReader("data/txt/teams"));
		
		String line;
		int i = 0;
		while((line = br.readLine())!=null){
			if(!line.trim().equals("")){
				String[] partes = line.split("\t");
				String nom = partes[0];
				String[] tiemposStr = partes[1].split("[|]");
				double[] tiempos = new double[tiemposStr.length];
				for (int j = 0; j < tiemposStr.length; j++) {
					String ts = tiemposStr[j];
					if(!ts.trim().equals("")){
						//System.out.println("i:"+i+", j:"+j+", ts:"+ts);
						tiempos[j] = Double.parseDouble(ts);
					}
				}
				
				String[] p1s = partes[2].split("[|]");
				Competidor p1 = new Competidor(p1s[0],p1s[1],p1s[2],Integer.parseInt(p1s[3]),p1s[4].charAt(0),nom);				
				Equipo eq = new Equipo(nom,p1,tiempos);
				
				if(partes.length>3){
					String[] p2s = partes[3].split("[|]");
					Competidor p2 = new Competidor(p2s[0],p2s[1],p2s[2],Integer.parseInt(p2s[3]),p2s[4].charAt(0),nom);				
					eq.cambiarIntegranteDos(p2);
				}
				
				if(partes.length>4){
					String[] p3s = partes[4].split("[|]");
					Competidor p3 = new Competidor(p3s[0],p3s[1],p3s[2],Integer.parseInt(p3s[3]),p3s[4].charAt(0),nom);				
					eq.cambiarIntegranteTres(p3);
				}
				maraton.asignarEquipo(eq, i);
			}
			i++;
		}
		
		br.close();
	}
	
	public static void main(String[] args) throws IOException{
		InterfazMaraton ventana = new InterfazMaraton();
		ventana.setVisible(true);
	}
}
