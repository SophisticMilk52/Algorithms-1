package interfaz;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.text.DecimalFormat;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import mundo.Equipo;
import mundo.Maraton;

@SuppressWarnings("serial")
public class PanelListadoEquipos extends JPanel{
	public PanelListadoEquipos(){
		setLayout(new BorderLayout());
		setPreferredSize(new Dimension(0,300));
		//setBorder(new TitledBorder("Equipos"));
	}
	
	public void refrescarTablaConEquipos(Equipo[] equipos){
		removeAll();

		JTable laTabla;
		String[] names = new String[Maraton.TAMANO_PROBLEMSET+3];
		names[0] = "#";
		names[1] = "Nombre";
		names[2] = "Competidores";
		for (int i = 3; i < names.length; i++) {
			names[i] = "P"+(i-2);
		}
		laTabla = new JTable(new DefaultTableModel(names,0));
		DefaultTableModel modelo = (DefaultTableModel)laTabla.getModel();
		
		removeAll();
		
		add(new JScrollPane(laTabla), BorderLayout.CENTER);
		
		DecimalFormat df = new DecimalFormat("0.000");
		
		for (int i = 0; i < equipos.length; i++) {
			String[] values = new String[Maraton.TAMANO_PROBLEMSET+3];
			values[0] = (i+1)+"";
			if(equipos[i]!=null){
				double[] t = equipos[i].darTiempoProblemas();
				
				values[1] = equipos[i].darNombre();
				values[2] = equipos[i].calcularCantidadCompetidores()+"";
				
				for (int j = 0; j < t.length; j++) {
					values[j+3] = df.format(t[j]);
				}
			}else{
				values[1] = "VAC�O";
			}
			modelo.addRow(values);
		}
		revalidate();
	}
}
