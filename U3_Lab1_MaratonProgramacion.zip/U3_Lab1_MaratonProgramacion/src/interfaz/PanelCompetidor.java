package interfaz;

import java.awt.BorderLayout;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import mundo.Competidor;

@SuppressWarnings("serial")
public class PanelCompetidor extends JPanel{
	private JLabel labImagen;
	private JLabel labNombres;
	//private JLabel labApellidos;
	//private JLabel labEdad;
	
	public PanelCompetidor(Competidor comp){
		setLayout(new BorderLayout());
		//System.out.println(comp.darRutaImagen());
		labImagen    = new JLabel(new ImageIcon(comp.darRutaImagen()));
		labNombres   = new JLabel(comp.darNombres()+" "+comp.darApellidos()+" "+comp.darEdad()+" a�os "+comp.darSexo(),SwingConstants.CENTER);
		//labApellidos = new JLabel(comp.darApellidos());
		//labEdad = new JLabel(comp.darEdad()+" a�os");
		
		//JPanel panelAux = new JPanel();
		//panelAux.setLayout(new GridLayout());
		add(labImagen,BorderLayout.CENTER);
		add(labNombres,BorderLayout.SOUTH);
	}
}
