package interfaz;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import mundo.Equipo;

@SuppressWarnings("serial")
public class PanelNavegaEquipos extends JPanel implements ActionListener{
	private JButton butAtras;
	private JButton butAdelante;
	private JLabel labInfoNavegacion;
	private JPanel panelActual;
	private int actual;
	
	private final static String ATRAS = "ATRAS";
	private final static String ADELANTE = "ADELANTE";
	
	private Equipo[] equipos;
	
	public PanelNavegaEquipos(Equipo[] eqs){
		equipos = eqs;
		setLayout(new BorderLayout());
		actual = 0;
		
		labInfoNavegacion = new JLabel("Equipo "+(actual+1)+" de "+equipos.length,SwingConstants.CENTER);
		butAtras = new JButton("<<");
		butAdelante = new JButton(">>");
		
		butAtras.setActionCommand(ATRAS);
		butAdelante.setActionCommand(ADELANTE);
		butAtras.addActionListener(this);
		butAdelante.addActionListener(this);
		
		panelActual = new PanelEquipo(equipos[actual]); 
		add(panelActual,BorderLayout.CENTER);
		
		JPanel panelAux = new JPanel();
		panelAux.setLayout(new BorderLayout());
		panelAux.add(butAtras,BorderLayout.WEST);
		panelAux.add(labInfoNavegacion,BorderLayout.CENTER);
		panelAux.add(butAdelante,BorderLayout.EAST);
		add(panelAux,BorderLayout.SOUTH);
	}
	
	@Override
	public void actionPerformed(ActionEvent evt) {
		String comando = evt.getActionCommand();
		if(comando.equals(ATRAS)){
			actual = actual-1;
			if(actual<0) actual = equipos.length-1;
		}else if(comando.equals(ADELANTE)){
			actual = (actual+1)%equipos.length;
		} 
		labInfoNavegacion.setText("Equipo "+(actual+1)+" de "+equipos.length);
		remove(panelActual);
		panelActual = new PanelEquipo(equipos[actual]); 
		add(panelActual,BorderLayout.CENTER);
	}

}
