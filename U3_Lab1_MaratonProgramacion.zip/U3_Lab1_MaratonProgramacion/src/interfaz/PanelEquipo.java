package interfaz;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.text.DecimalFormat;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.TitledBorder;

import mundo.Competidor;
import mundo.Equipo;

@SuppressWarnings("serial")
public class PanelEquipo extends JPanel{
	public PanelEquipo(Equipo eq){
		setLayout(new BorderLayout());
		
		if(eq==null){
			add(new JLabel(new ImageIcon("data/imgs/cancelled.png")),BorderLayout.CENTER);
		}else{
			setBorder(new TitledBorder("Nombre de Equipo: "+eq.darNombre()));
			JPanel panelAux1 = new JPanel();
			panelAux1.setLayout(new GridLayout(1,3));
			panelAux1.add(new PanelCompetidor(eq.darIntegranteUno()));
			Competidor c2 = eq.darIntegranteDos();
			Competidor c3 = eq.darIntegranteTres();
			JPanel p2 = new JPanel();
			JPanel p3 = new JPanel();
			if(c2!=null){
				p2 = new PanelCompetidor(c2);
			}
			if(c3!=null){
				p3 = new PanelCompetidor(c3);
			}
			panelAux1.add(p2);
			panelAux1.add(p3);
			add(panelAux1,BorderLayout.CENTER);
			
			JPanel panelAux2 = new JPanel();
			double[] tp = eq.darTiempoProblemas();
			panelAux2.setLayout(new GridLayout(1,tp.length));
			DecimalFormat df = new DecimalFormat("0.0");
			for (int i = 0; i < tp.length; i++) {
				panelAux2.add(new JLabel(df.format(tp[i]),SwingConstants.CENTER));
			}
			add(panelAux2,BorderLayout.SOUTH);
		}
	}
}
