package interfaz;
import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import mundo.Competidor;

@SuppressWarnings("serial")
public class PanelListadoCompetidores extends JPanel{
	public PanelListadoCompetidores(){
		setLayout(new BorderLayout());
		setPreferredSize(new Dimension(0,300));
		//setBorder(new TitledBorder("Competidores"));
	}
	
	public void refrescarTablaConCompetidores(Competidor[] competidores){
		removeAll();

		JTable laTabla;
		String[] names = new String[]{"#", "Equipo", "Nombre", "Apellidos", "Edad", "Sexo"};
		laTabla = new JTable(new DefaultTableModel(names,0));
		DefaultTableModel modelo = (DefaultTableModel)laTabla.getModel();
		
		removeAll();
		
		add(new JScrollPane(laTabla), BorderLayout.CENTER);
		
		for (int i = 0; i < competidores.length; i++) {
			Competidor c = competidores[i];
			if(c!=null){
				modelo.addRow(new String[]{""+(i+1),c.darNombreEquipo(),c.darNombres(),c.darApellidos(),c.darEdad()+"",c.darSexo()+""});
			}else{
				modelo.addRow(new String[]{""+(i+1),"VAC�O","","","",""});
			}
		}
		revalidate();
	}
}
