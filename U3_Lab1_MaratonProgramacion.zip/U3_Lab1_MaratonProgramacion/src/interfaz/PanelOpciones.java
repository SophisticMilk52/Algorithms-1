package interfaz;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

@SuppressWarnings("serial")
public class PanelOpciones extends JPanel implements ActionListener{
	private JButton butCargarTodosEquipos;
	private static final String CARGAR_TODOS_EQUIPOS = "CARGAR_TODOS_EQUIPOS";
	private JButton butCargarTodosCompetidores;
	private static final String CARGAR_TODOS_COMPETIDORES = "CARGAR_TODOS_COMPETIDORES";
	private JButton butCancelarParesConUnCompetidor;
	private static final String CANCELAR_PARES_UN_COMPETIDOR = "CANCELAR_PARES_UN_COMPETIDOR";
	private JButton butConsultarEquiposConMasMitadProblemas;
	private static final String CONSULTAR_EQUIPOS_MAS_MITAD_PROBLEMAS = "CONSULTAR_EQUIPOS_MAS_MITAD_PROBLEMAS";
	private JButton butConsultarCompetidoresEdad20y25Mujer;
	private static final String CONSULTAR_COMPETIDORES_20_25_MUJER = "CONSULTAR_COMPETIDORES_20_25_MUJER";
	
	private InterfazMaraton principal;
	
	public PanelOpciones(InterfazMaraton ventana){
		principal = ventana;
		
		setBorder(new TitledBorder("Opciones"));
		setLayout(new GridLayout(0,1));
		butCargarTodosEquipos = new JButton("Cargar Equipos Actuales");
		butCargarTodosCompetidores = new JButton("Cargar Competidores Actuales");
		butCancelarParesConUnCompetidor = new JButton("Cancelar Mas Equipos");
		butConsultarEquiposConMasMitadProblemas = new JButton("Consultar Mejores Equipos");
		butConsultarCompetidoresEdad20y25Mujer = new JButton("Consultar Competidores Especiales");
		
		butCargarTodosEquipos.setActionCommand(CARGAR_TODOS_EQUIPOS);
		butCargarTodosCompetidores.setActionCommand(CARGAR_TODOS_COMPETIDORES);
		butCancelarParesConUnCompetidor.setActionCommand(CANCELAR_PARES_UN_COMPETIDOR);
		butConsultarEquiposConMasMitadProblemas.setActionCommand(CONSULTAR_EQUIPOS_MAS_MITAD_PROBLEMAS);
		butConsultarCompetidoresEdad20y25Mujer.setActionCommand(CONSULTAR_COMPETIDORES_20_25_MUJER);
		
		butCargarTodosEquipos.addActionListener(this);
		butCargarTodosCompetidores.addActionListener(this);
		butCancelarParesConUnCompetidor.addActionListener(this);
		butConsultarEquiposConMasMitadProblemas.addActionListener(this);
		butConsultarCompetidoresEdad20y25Mujer.addActionListener(this);
		
		//10 rows!!
		add(butCargarTodosEquipos);
		add(butCargarTodosCompetidores);
		add(butConsultarEquiposConMasMitadProblemas);
		add(butConsultarCompetidoresEdad20y25Mujer);
		add(butCancelarParesConUnCompetidor);
		add(new JLabel());
		add(new JLabel());
		add(new JLabel());
		add(new JLabel());
		add(new JLabel());
	}

	@Override
	public void actionPerformed(ActionEvent evt) {
		String comando = evt.getActionCommand();
		if(comando.equals(CANCELAR_PARES_UN_COMPETIDOR)){
			principal.cancelarMasEquipos();
		}else if(comando.equals(CONSULTAR_EQUIPOS_MAS_MITAD_PROBLEMAS)){
			principal.consultarMejoresEquipos();
		}else if(comando.equals(CONSULTAR_COMPETIDORES_20_25_MUJER)){
			principal.consultarCompetidoresEspeciales();
		}else if(comando.equals(CARGAR_TODOS_COMPETIDORES)){
			principal.cargarTodosCompetidoresEnLista();
		}else if(comando.equals(CARGAR_TODOS_EQUIPOS)){
			principal.cargarTodosEquiposEnLista();
		}
	}
}
