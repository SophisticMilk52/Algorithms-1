package interfaz;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Clase encargada de generar archivos de lectura de equipos de maratones con participantes.
 * @author Juan Manuel Reyes <jmreyes@icesi.edu.co>
 *
 */
public class MainG {
	public static final int MAX_TEAMS = 90;
	public static final int MAX_PROBLEMS = 10;
	
	public static String makeAPerson(ArrayList<String> ln, ArrayList<String> wfn, ArrayList<String> mfn, ArrayList<String> reps){
		char[] sexs = new char[]{'F','M'};
		int sex = (int)(Math.random()*2);
		String firstName;
		String pathImage = "data/imgs/avatars/";
		if(sex==0){
			int fn = (int)(Math.random()*wfn.size());
			firstName = wfn.get(fn);
			pathImage += "girl";
		}else{
			int fn = (int)(Math.random()*mfn.size());
			firstName = mfn.get(fn);			
			pathImage += "guy";
		}
		//System.out.println("ln.size()="+ln.size());
		int nl = (int)(Math.random()*ln.size());
		String lastName = ln.get(nl);
		do{
			int ni = (int)(Math.random()*11);
			pathImage += ni+".png";
		}while(reps.contains(pathImage));
		reps.add(pathImage);
		
		int age = 16+(int)(Math.random()*14);
		
		return firstName+"|"+lastName+"|"+pathImage+"|"+age+"|"+sexs[sex];
	}
	
	public static void main(String[] args) throws IOException{
		BufferedWriter bw = new BufferedWriter(new FileWriter("data/txt/teams"));
		String line;
		
		/*Team Names Reading*/
		BufferedReader brt = new BufferedReader(new FileReader("data/txt/teamNames"));		
		ArrayList<String> tn = new ArrayList<>();
		while((line=brt.readLine())!=null){
			tn.add(line);
		}		
		brt.close();
		
		/*Woman First Names Reading*/
		BufferedReader brw = new BufferedReader(new FileReader("data/txt/womanFirstNames"));		
		ArrayList<String> wfn = new ArrayList<>();
		while((line=brw.readLine())!=null){
			wfn.add(line.toUpperCase());
		}		
		brw.close();
		
		/*Man First Names Reading*/
		BufferedReader brm = new BufferedReader(new FileReader("data/txt/manFirstNames"));		
		ArrayList<String> mfn = new ArrayList<>();
		while((line=brm.readLine())!=null){
			mfn.add(line);
		}
		brm.close();
		
		/*Last Names Reading*/
		BufferedReader brl = new BufferedReader(new FileReader("data/txt/lastNames"));		
		ArrayList<String> ln = new ArrayList<>();
		while((line=brl.readLine())!=null){
			ln.add(line);
		}
		brl.close();
		for (int i = 0; i < MAX_TEAMS; i++) {
			int next = (int)(Math.random()*4);
			//System.out.println(i);
			if(next!=0){
				int nt = (int)(Math.random()*tn.size());
				String nameTeam = tn.remove(nt);
				
				String times = "";
				String sep = "";
				int totalProblems = MAX_PROBLEMS;
				while(totalProblems>0){
					int resuelto = (int)(Math.random()*3);
					if(resuelto==0){
						times += sep+(Math.random()*300);
					}else{
						times += sep+"0.0";						
					}
					sep = "|";
					totalProblems--;
				}
				//System.out.println("tp:"+times);
				ArrayList<String> reps = new ArrayList<>();
				String p3="",p2="",p1 = makeAPerson(ln, wfn, mfn, reps);
				next = (int)(Math.random()*2);
				if(next==1){
					p2 = makeAPerson(ln, wfn, mfn, reps);
					next = (int)(Math.random()*2);
					if(next==1){
						p3 = makeAPerson(ln, wfn, mfn, reps);
					}
				}
				bw.write(nameTeam+"\t"+times+"\t"+p1+"\t"+p2+"\t"+p3+"\n");
			}else{
				bw.write("\n");
			}
		}
		
		bw.close();
	}
}
