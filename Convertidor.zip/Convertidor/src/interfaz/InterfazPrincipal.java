package interfaz;

import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import mundo.convertidor;

public class InterfazPrincipal extends JFrame{
	/**
	 * Relacion de JPanelEntrada a la clase principal
	 */
	private JPanelEntrada entrada;
	/**
	 * Relacion de JPanelResultados a la clase principal
	 */
	private JPanelResultados resultado;
	/**
	 * Constructor de la clase InterfazPrincipal
	 */
	private convertidor mundo;

	public InterfazPrincipal() {
mundo=new convertidor();
		setLayout(new BorderLayout());
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		entrada = new JPanelEntrada(this);
		add(entrada, BorderLayout.NORTH);
		resultado = new JPanelResultados(this);
		add(resultado, BorderLayout.CENTER);
		setResizable(false);
		pack();
	}
	
	/**
	 * Convierte los metodos double del mundo a String
	 * 
	 * @param no
	 */
	public void conversor(String no) {
		double grados = 0.0;
		double f = 0.0;
		double k = 0.0;
		try {
		
			grados = Double.parseDouble(no);
			k = mundo.ConvertirKelvin(grados);
		
			f = mundo.ConvertirFaren(grados);
	
		
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "no se pudo convetir");
		}
		resultado.Modificar(k, f);
	}
	
	/**
	 * El main se encarga de mostrar el JFrame
	 * @param args
	 */
	public static void main(String args[]) {
		InterfazPrincipal ventana = new InterfazPrincipal();
		ventana.setVisible(true);

	}
}
