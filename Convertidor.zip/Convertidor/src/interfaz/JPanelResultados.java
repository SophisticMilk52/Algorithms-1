package interfaz;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

public class JPanelResultados extends JPanel {
	/**
	 * Etiqueta que contiene la palabra Farenheit
	 */
private JLabel far;
/**
 * Etiqueta que cntiene la palabra kelvin
 */
private JLabel kel;
/**
 * cuadro de texto que contiene los grados farenheit
 */
private JTextField fare;
/**
 * cuadro de texto que contiene los grados kelvin
 */
private JTextField kelv;
	
	
	/**
	 * Constructor de la clase JPanelResultados
	 */
private InterfazPrincipal fi;
	public JPanelResultados(InterfazPrincipal o){
fi=o;
		JPanel aux = new JPanel();
		TitledBorder border = new TitledBorder("Resultados");
		setBorder(border);
	aux.setLayout(new GridLayout(2,1));
	far= new JLabel("Fahrenheit:");
	aux.add(far);
	
	kel= new JLabel("Kelvin:");
	aux.add(kel);
	JPanel aux2 = new JPanel();

	aux2.setLayout(new GridLayout(2,1));
	fare= new JTextField(10);
	fare.setBackground(Color.WHITE);
	fare.setEditable(false);
	aux2.add(fare);
	
	kelv= new JTextField(10);
	kelv.setEditable(false);
	kelv.setBackground(Color.WHITE);
	aux2.add(kelv);
	
setLayout(new BorderLayout());
	

	add(aux,BorderLayout.WEST);
	add(aux2, BorderLayout.EAST);
}
	/**
	 * modifica los txtfield del panelresultados
	 * @param k valor que se le pasa por parametro
	 * @param f valor que se le pasa por parametro
	 */
public void Modificar(double k, double f){
	fare.setText(f+"");
	kelv.setText(k+"");
}
		
	
}