package interfaz;

import java.awt.BorderLayout;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

public class JPanelEntrada extends JPanel implements ActionListener{
	public final static String BOTON="boton";
	/**
	 * Etiqueta que contiene los grados celcius
	 */
private JLabel grados;
/**
 * Boton que convierte los grados celcius
 */
private JButton convertir;
/**
 * texto donde se inscribiran los grados a converitr
 */
private JTextField coso;

String actionCommand;
/**
 * Relacion del panel InterfazPrincipal al panel JPanelEntrada
 */
private InterfazPrincipal fi;
/**
 * constructor de la clase JPanelEntrada
 * @param o 
 */
	public JPanelEntrada(InterfazPrincipal o){
	setLayout(new BorderLayout());
	fi=o;
	TitledBorder border = new TitledBorder("Entrada");
	setBorder(border);
	grados= new JLabel ("�C:");
	add(grados,BorderLayout.WEST);
	coso= new JTextField(10);
	add(coso, BorderLayout.CENTER);
	convertir= new JButton("convertir");
	convertir.addActionListener(this);

	convertir.setActionCommand(BOTON);
    add(convertir, BorderLayout.EAST);
	

	}
	/**
	 * Hace que el boton funciono y se conecte con el mundo
	 */
	public void actionPerformed(ActionEvent e) {

		if(e.getActionCommand().equals(BOTON)){
			if(coso.equals("")){
				JOptionPane.showMessageDialog(fi, "ingrese algo");
			}else{
				fi.conversor(coso.getText().trim());
		
	}
}}}