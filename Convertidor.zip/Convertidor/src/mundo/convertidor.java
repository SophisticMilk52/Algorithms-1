package mundo;

public class convertidor {


/**
 * Descripcion: convierte una los grados centigrados a farenheit
 * @param c son los celcius que se pasan por parametro
 * @return faren son los grados convertidos
 */
public double ConvertirFaren(double c){
	double faren= c*9;
	faren=faren/5;
	faren+=32;
	return faren;
	
	
}
/**
 * Descripcion: convierte una los grados centigrados a kelvin
 * @param c son los celcius que se pasan por parametro
 * @return kelvin son los grados transformados a kelvin
 */
public double ConvertirKelvin(double c){
	double kelvin= c+273.15;
	return kelvin;
}
}
