package interfaz;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import mundo.Sitio;
import mundo.Zona;

@SuppressWarnings("serial")
public class PanelSitio extends JPanel implements ActionListener{
	
	private JButton btnEliminar;
	
	private final static String ELIMINAR="ELIMINAR";
	
	private JTextField txtNombre;
	private JTextField txtAnho;
	private JTextField txtDireccion;
	
	private Sitio sitio;
	private Zona zona;
	private InterfazTurismo principal;
	
	private static int comercial  = 1;
	private static int cultural   = 1;
	private static int escenarios = 1;
	private static int interes    = 1;
	
	public PanelSitio(InterfazTurismo ventana, Sitio s, Zona z){
		principal = ventana;
		sitio = s;
		zona  = z;
		setLayout(new BorderLayout());
		
		txtNombre    = new JTextField(sitio.darNombre());
		txtAnho      = new JTextField("Construido en "+sitio.darAnhoConstruccion());
		txtDireccion = new JTextField(sitio.darDireccion());
		
		txtNombre.setEditable(false);
		txtAnho.setEditable(false);
		txtDireccion.setEditable(false);
		
		btnEliminar = new JButton(new ImageIcon("data/img/delete.png"));
		btnEliminar.setMargin(new Insets(0, 0, 0, 0));
		btnEliminar.addActionListener(this);
		btnEliminar.setActionCommand(ELIMINAR);
		btnEliminar.setEnabled(true);		
		btnEliminar.setToolTipText("Eliminar este Sitio");
		
		JPanel panelEdicion = new JPanel();
		panelEdicion.setLayout(new GridLayout(1,2));
		
		JPanel panelArriba = new JPanel();
		panelArriba.setLayout(new BorderLayout());
		panelArriba.add(txtNombre,BorderLayout.CENTER);
		panelArriba.add(panelEdicion,BorderLayout.EAST);

		JPanel panelMedio = new JPanel();
		panelMedio.setLayout(new BorderLayout());
		panelMedio.add(new JLabel(sitio.darTipoSitio()),BorderLayout.CENTER);
		panelMedio.add(btnEliminar,BorderLayout.EAST);
		
		add(panelArriba,BorderLayout.NORTH);
		add(new JLabel(new ImageIcon("data/img/sitios/"+sitio.darNombreImagen())),BorderLayout.CENTER);
				
		JPanel panelInfo = new JPanel();
		panelInfo.setLayout(new BorderLayout());
		panelInfo.add(panelMedio,BorderLayout.NORTH);
		
		JPanel restoCampos = new JPanel();
		restoCampos.setLayout(new GridLayout(2,1));
		panelInfo.add(restoCampos,BorderLayout.CENTER);

		
		restoCampos.add(txtAnho);
		restoCampos.add(txtDireccion);
		
		add(panelInfo,BorderLayout.SOUTH);
	}
	
	public String obtenerNombreImagen(String tipoSitio){
		if(tipoSitio.equals(Sitio.COMERCIAL)){
			return (comercial++)+"";
		}else if(tipoSitio.equals(Sitio.CULTURAL)){
			return (cultural++)+"";
		}else if(tipoSitio.equals(Sitio.ESCENARIOS)){
			return (escenarios++)+"";
		}else if(tipoSitio.equals(Sitio.INTERES)){
			return (interes++)+"";
		}else{
			return 0+"";
		}
	}
	
	public String darNombre(){
		return txtNombre.getText();
	}

	public String darAnho(){
		return txtAnho.getText();
	}

	public String darDireccion(){
		return txtDireccion.getText();
	}

	@Override
	public void actionPerformed(ActionEvent ev) {
		String comando = ev.getActionCommand();
		if(comando.equals(ELIMINAR)){
			principal.eliminarSitio(this,sitio,zona);
		}
	}
}
