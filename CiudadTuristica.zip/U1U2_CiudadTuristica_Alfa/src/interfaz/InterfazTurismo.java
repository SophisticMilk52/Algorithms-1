package interfaz;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JTabbedPane;

import mundo.Ciudad;
import mundo.Sitio;
import mundo.Zona;

@SuppressWarnings("serial")
public class InterfazTurismo extends JFrame{
	private PanelZona pvzNorte;
	private PanelZona pvzCentro;
	private PanelZona pvzSur;
	
	private PanelSitios pvsNorte;
	private PanelSitios pvsCentro;
	private PanelSitios pvsSur;
	private Ciudad ciudad;
	
	public final static String PREFIJO_ZONA = "Zona ";
	
	public InterfazTurismo(){
		ciudad    = new Ciudad();
		
		pvsNorte  = new PanelSitios(this,ciudad.darzonaNorte());
		pvsCentro = new PanelSitios(this,ciudad.darzonaCentro());
		pvsSur    = new PanelSitios(this,ciudad.darzonaSur());
		
		pvzNorte  = new PanelZona(this,ciudad.darzonaNorte(),pvsNorte);
		pvzCentro = new PanelZona(this,ciudad.darzonaCentro(),pvsCentro);
		pvzSur    = new PanelZona(this,ciudad.darzonaSur(),pvsSur);
		
		setTitle("Ciudad Tur�stica");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLayout(new BorderLayout());
		
		JTabbedPane pestanas = new JTabbedPane();
		add(pestanas,BorderLayout.CENTER);
		pestanas.addTab(PREFIJO_ZONA+ciudad.darzonaNorte().obtenerNombreUbicacion(),pvzNorte);
		pestanas.addTab(PREFIJO_ZONA+ciudad.darzonaCentro().obtenerNombreUbicacion(),pvzCentro);
		pestanas.addTab(PREFIJO_ZONA+ciudad.darzonaSur().obtenerNombreUbicacion(),pvzSur);
		
		configurarMenu();
		
		setSize(1100,410);
		setResizable(false);
	}
	
	private void configurarMenu(){
		JMenuBar menuBar = new JMenuBar();
		
		JMenu estadisticas = new JMenu("Estad�sticas");
		JMenu generales    = new JMenu("Toda la Ciudad");

		JMenuItem estadistica4G = new JMenuItem("Zona Con Mas Centros de Salud");
		estadistica4G.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent ev) {mostrarZonaMasCentrosSalud();}});
		
		generales.add(estadistica4G);

		JMenuItem salir = new JMenuItem("Salir");
		salir.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent ev) {System.exit(0);}});
		
		estadisticas.add(generales);
		estadisticas.addSeparator();
		estadisticas.add(salir);
		
		JMenu ayuda = new JMenu("Ayuda");
		JMenuItem creditos = new JMenuItem("Cr�ditos");
		creditos.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent ev) {JOptionPane.showMessageDialog(null, "Material desarrollado para el curso de:\nAlgoritmos y Programaci�n 1\nUniversidad ICESI\nCali-Colombia");}});
		ayuda.add(creditos);

		menuBar.add(estadisticas);
		menuBar.add(ayuda);
		
		setJMenuBar(menuBar);		
	}
	
	private void mostrarZonaMasCentrosSalud(){
		Zona z = ciudad.encontrarZonaMasCentrosSalud();
		if(z!=null){
			JOptionPane.showMessageDialog(this, "La mayor cantidad de centros de salud est� en la zona "
				+z.obtenerNombreUbicacion()+" "+ "donde hay "+z.darCantidadCentrosSalud());
		}else{
			JOptionPane.showMessageDialog(this, "No se encontr� ninguna zona en el mundo!\n"
					+ "El m�todo debe estar muy mal porque las relaciones hacia las zonas son obligatorias.");
		}
	}
	
	public void eliminarSitio(PanelSitio ps, Sitio s, Zona z){
		int confirmacion = JOptionPane.showConfirmDialog(this, "�Realmente desea eliminar el sitio indicado?");
		if(confirmacion == JOptionPane.YES_OPTION){
			if(ciudad.eliminarSitioDeZona(z.darUbicacion(), s.darNombre())){//if(z.eliminarSitio(s.darNombre())){
				if(z==ciudad.darzonaNorte()){
					pvsNorte.eliminarPanelSitio(ps);
				}else if(z==ciudad.darzonaCentro()){
					pvsCentro.eliminarPanelSitio(ps);
				}else if(z==ciudad.darzonaSur()){
					pvsSur.eliminarPanelSitio(ps);
				}
			
				JOptionPane.showMessageDialog(this, "El sitio fue eliminado satisfactoriamente!");
			}else{
				JOptionPane.showMessageDialog(this, "El sitio NO pudo ser eliminado");				
			}
		}
	}
	
	public void abrirVentanaNuevoSitio(Zona zona){
		new VentanaNuevoSitio(this,zona).setVisible(true);
	}
	
	public boolean guardarNuevoSitio(VentanaNuevoSitio vns, Zona zona){
		try{
			
			String nombre = vns.darNombre(); 
			int anho      = Integer.parseInt(vns.darAnho()); 
			String direcc = vns.darDireccion(); 
			String tipo   = vns.darTipo();
			String imagen = vns.darImagen();
			
			boolean guardo = ciudad.agregarSitioAZona(zona.darUbicacion(), nombre, imagen, tipo, anho, direcc);
			
			if(guardo){
				JOptionPane.showMessageDialog(this, "El nuevo sitio fue guardado exitosamente!");
				switch(zona.darUbicacion()){
					case Zona.NORTE:
						pvsNorte.actualizarSitios();
					break;
					case Zona.CENTRO:
						pvsCentro.actualizarSitios();
					break;
					case Zona.SUR:
						pvsSur.actualizarSitios();
					break;
				}
			}else{
				JOptionPane.showMessageDialog(this, "El nuevo sitio no pudo ser guardado\n" +
													"Es probable que ya exista un sitio con el nombre indicado\n" +
													"o que se haya alcanzado el n�mero m�ximo de\n" +
													"sitios permitidos para una zona (m�ximo sitios: 5)");				
			}
			
			return guardo;
		}catch(Exception e){
			JOptionPane.showMessageDialog(this, "El nuevo sitio no pudo ser guardado\n" +
												"Debe llenar los campos con datos v�lidos y debe tener\n" +
												"en cuenta que el a�o es un valor num�rico entero");
			return false;			
		}		
	}
	
	public int darNumeroSitio(Zona z, Sitio s){
		if(z.darSitioUno()==s)    return 1;
		if(z.darSitioDos()==s)    return 2;
		if(z.darSitioTres()==s)   return 3;
		if(z.darSitioCuatro()==s) return 4;
		if(z.darSitioCinco()==s)  return 5;
		
		return 0;
	}
	
	public Ciudad darCiudad(){
		return ciudad;
	}
	
	public static void main(String[] args){
		new InterfazTurismo().setVisible(true);
	}
}
