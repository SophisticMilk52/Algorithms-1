package mundo;

/**
 * Entidad que modela una zona geogr�fica con sitios tur�sticas de una ciudad
 * @author Juan Manuel Reyes G., Universidad Icesi, Cali-Colombia
 */
public class Zona {

	//-----------------------------------------------------------------
    // Constantes
    //-----------------------------------------------------------------
	/**
	 * Constante para modelar la caracter�stica de ubicaci�n NORTE
	 */
	public final static int NORTE  = 1; 
	
	/**
	 * Constante para modelar la caracter�stica de ubicaci�n CENTRO
	 */
	public final static int CENTRO = 2; 
	
	/**
	 * Constante para modelar la caracter�stica de ubicaci�n SUR
	 */
	public final static int SUR    = 3; 
	
    //-----------------------------------------------------------------
    // Atributos
    //-----------------------------------------------------------------
	/**
	 * La ubicaci�n de la zona (puede ser NORTE, CENTRO, etc)
	 */
	private int ubicacion;
	
	/**
	 * La proporci�n del �rea de la zona con respecto al �rea de la ciudad (en porcentaje)
	 */
	private double areaProporcional;
	
	/**
	 * La cantidad de centros educativos presentes en la zona
	 */
	private int cantidadCentrosEducativos;
	
	/**
	 * La cantidad de centros de salud presentes en la zona
	 */
	private int cantidadCentrosSalud;
	
	/**
	 * El sitio tur�stico uno (1)
	 */
	private Sitio sitioUno;
	
	/**
	 * El sitio tur�stico dos (2)
	 */
	private Sitio sitioDos;
	
	/**
	 * El sitio tur�stico tres (3)
	 */
	private Sitio sitioTres;
	
	/**
	 * El sitio tur�stico cuatro (4)
	 */
	private Sitio sitioCuatro;
	
	/**
	 * El sitio tur�stico cinco (5)
	 */
	private Sitio sitioCinco;
	
    //-----------------------------------------------------------------
    // Constructores
    //-----------------------------------------------------------------

	/**
	 * Crea una nueva zona con la informaci�n pasada como par�metro.
	 * 
	 * @param laUbicacion La ubicaci�n de la nueva zona
	 * @param elAreaProporcional La proporci�n del �rea de la nueva zona con respecto a la ciudad (en porcentaje)
	 * @param laCantidadCentrosEducativos La cantidad de centros educativos de la nueva zona
	 * @param laCantidadCentrosSalud La cantidad de centros de salud de la nueva zona
	 */
	public Zona(int laUbicacion, double elAreaProporcional, int laCantidadCentrosEducativos, int laCantidadCentrosSalud) {
		ubicacion = laUbicacion;
		areaProporcional = elAreaProporcional;
		cantidadCentrosEducativos = laCantidadCentrosEducativos;
		cantidadCentrosSalud = laCantidadCentrosSalud;
		
		sitioUno    = null;
		sitioDos    = null;
		sitioTres   = null;
		sitioCuatro = null;
		sitioCinco  = null;
	}
	
    //-----------------------------------------------------------------
    // M�todos
    //-----------------------------------------------------------------

	/**
	 * Agrega un nuevo sitio a la zona actual.
	 * 
	 * @param elNombre el nombre del sitio que se va a agregar
	 * @param elNombreImagen el nombre del archivo de la imagen del sitio que va a agregar
	 * @param elTipoSitio el tipo de sitio del sitio que se va a agregar
	 * @param elAnhoConstruccion el a�o en que fue construido el sitio que se va a agregar
	 * @param laDireccion la direcci�n del sitio que se va a agregar
	 * @return true si se pudo agregar el nuevo sitio, false de lo contrario
	 */
	public boolean agregarSitio(String elNombre, String elNombreImagen, String elTipoSitio, int elAnhoConstruccion, String laDireccion){
		return false;
	}
	
	/**
	 * Busca en la zona actual el sitio cuyo nombre es el pasado como par�metro
	 * y retorna el sitio encontrado. Si no se encontr� un sitio que coincidiera
	 * con ese nombre entonces retorna null.
	 * 
	 * @param nombreSitio Es el nombre del sitio que se est� buscando
	 * @return el objeto de tipo sitio cuyo nombre es igual al pasado por par�metro � null si no se encuentra
	 */
	public Sitio buscarSitio(String nombreSitio){
		Sitio sitioBuscado = null;
		
		if(sitioUno!=null && nombreSitio.equals(sitioUno.darNombre())){
			sitioBuscado = sitioUno;
		}else if(sitioDos!=null && nombreSitio.equals(sitioDos.darNombre())){
			sitioBuscado = sitioDos;
		}else if(sitioTres!=null && nombreSitio.equals(sitioTres.darNombre())){
			sitioBuscado = sitioTres;
		}else if(sitioCuatro!=null && nombreSitio.equals(sitioCuatro.darNombre())){
			sitioBuscado = sitioCuatro;
		}else if(sitioCinco!=null && nombreSitio.equals(sitioCinco.darNombre())){
			sitioBuscado = sitioCinco;
		}
		
		return sitioBuscado;
	}
	
	/**
	 * Elimina el sitio cuyo nombre ha sido pasado por par�metro
	 * y retorna null si el sitio pudo ser eliminado. El caso en
	 * que no puede ser eliminado es cuando el sitio con ese nombre
	 * no existe.
	 * 
	 * @param nombreSitio Es el nombre del sitio a eliminar
	 * @return true si se pudo eliminar el sitio, false de lo contrario
	 */
	public boolean eliminarSitio(String nombreSitio){
		return false;
	}
	
	/**
	 * Retorna el nombre de la ubicaci�n dependiendo del
	 * valor que tenga el atributo ubicaci�n:<br/><br/>
	 * 
	 * Si es igual a la constante NORTE, entonces se retorna Norte.<br/> 
	 * Si es igual a la constante CENTRO, entonces se retorna Centro.<br/>
	 * Si es igual a la constante SUR, entonces se retorna Sur.<br/>
	 * 
	 * @return el nombre de la ubicaci�n tal como se especifica en la descripci�n
	 */
	public String obtenerNombreUbicacion(){
		String nombreUbicacion = "";
		switch(ubicacion){
			case NORTE:
				nombreUbicacion = "Norte";
			break;
			case CENTRO:
				nombreUbicacion = "Centro";
			break;
			case SUR:
				nombreUbicacion = "Sur";
			break;
		}
		return nombreUbicacion;
	}
	
	/**
	 * Retorna la ubicaci�n del sitio
	 * @return ubicacion
	 */
	public int darUbicacion() {
		return ubicacion;
	}
	
	/**
	 * Retorna la proporci�n del �rea de la zona actual al �rea de la ciudad (en porcentaje)
	 * @return areaProporcional
	 */
	public double darAreaProporcional() {
		return areaProporcional;
	}
	
	/**
	 * Retorna la cantidad de centros educativos de la zona actual
	 * @return cantidadCentrosEducativos
	 */
	public int darCantidadCentrosEducativos() {
		return cantidadCentrosEducativos;
	}
	
	/**
	 * Retorna la cantidad de centros de salud de la zona actual
	 * @return cantidadCentrosSalud
	 */
	public int darCantidadCentrosSalud() {
		return cantidadCentrosSalud;
	}
	
	/**
	 * Modifica la ubicaci�n por la indicada en el par�metro
	 * @param laUbicacion es la nueva ubicaci�n de la zona
	 */
	public void cambiarUbicacion(int laUbicacion) {
		ubicacion = laUbicacion;
	}
	
	/**
	 * Modifica la proporci�n del �rea de la zona actual con respecto al �rea de la ciudad (en porcentaje)
	 * @param elAreaProporcional es la nueva proporci�n que se asignar� a la zona
	 */
	public void cambiarAreaProporcional(double elAreaProporcional) {
		areaProporcional = elAreaProporcional;
	}
	
	/**
	 * Modifica la cantidad de centros educativos de la zona actual
	 * @param laCantidadCentrosEducativos es la nueva cantidad de centros educativos 
	 */
	public void cambiarCantidadCentrosEducativos(int laCantidadCentrosEducativos) {
		cantidadCentrosEducativos = laCantidadCentrosEducativos;
	}
	
	/**
	 * Modifica la cantidad de centros de salud de la zona actual
	 * @param laCantidadCentrosSalud es la nueva cantidad de centros educativos
	 */
	public void cambiarCantidadCentrosSalud(int laCantidadCentrosSalud) {
		cantidadCentrosSalud = laCantidadCentrosSalud;
	}

	/**
	 * Retorna el primer sitio
	 * @return sitioUno
	 */
	public Sitio darSitioUno() {
		return sitioUno;
	}

	/**
	 * Retorna el segundo sitio
	 * @return sitioDos
	 */
	public Sitio darSitioDos() {
		return sitioDos;
	}

	/**
	 * Retorna el tercer sitio
	 * @return sitioTres
	 */
	public Sitio darSitioTres() {
		return sitioTres;
	}

	/**
	 * Retorna el cuarto sitio
	 * @return sitioCuatro
	 */
	public Sitio darSitioCuatro() {
		return sitioCuatro;
	}

	/**
	 * Retorna el quinto sitio
	 * @return sitioCinco
	 */
	public Sitio darSitioCinco() {
		return sitioCinco;
	}
}
