package mundo;

/**
 * Entidad que modela una ciudad con proyecci�n tur�stica
 * @author Juan Manuel Reyes G., Universidad Icesi, Cali-Colombia
 */
public class Ciudad {

    //-----------------------------------------------------------------
    // Atributos
    //-----------------------------------------------------------------
	/**
	 * El nombre de la ciudad
	 */
	private String nombre;
	
	/**
	 * El porcentaje de desempleo de la ciudad
	 */
	private double desempleo;
	
	/**
	 * El n�mero de habitantes seg�n el �ltimo censo realizado
	 */
	private int cantidadHabitantes;
	
	/**
	 * La relaci�n con la zona geogr�fica que se ubica en el norte de la ciudad
	 */
	private Zona zonaNorte;
	
	/**
	 * La relaci�n con la zona geogr�fica que se ubica en el centro de la ciudad
	 */
	private Zona zonaCentro;
	
	/**
	 * La relaci�n con la zona geogr�fica que se ubica en el sur de la ciudad
	 */
	private Zona zonaSur;
	
    //-----------------------------------------------------------------
    // Constructores
    //-----------------------------------------------------------------

	/**
	 * Crea una nueva ciudad con un escenario muy espec�fico
	 * que es planteado al interior del m�todo 
	 */
	public Ciudad() {
		nombre             = "Springfield";
		desempleo          = 10.3;
		cantidadHabitantes = 2319684;
		
		zonaNorte  = new Zona(Zona.NORTE,  21.7, 32, 7);
		zonaCentro = new Zona(Zona.CENTRO, 9.4,  5,  2);
		zonaSur    = new Zona(Zona.SUR,    35.1, 48, 13);
		
		agregarSitioAZona(zonaNorte.darUbicacion(),"Restaurante La Trufa Dorada","TrufaDorada.jpg", Sitio.COMERCIAL, 1973, "Calle A con Avenida B");
		agregarSitioAZona(zonaNorte.darUbicacion(),"Museo de Arte Moderno", "Museo.jpg", Sitio.CULTURAL, 1965, "Carrera C con Calle D");
		agregarSitioAZona(zonaNorte.darUbicacion(),"Estadio de Hockey", "EstadioDeHockey.jpg", Sitio.ESCENARIOS, 1987, "Calle E con Carrera F");
		agregarSitioAZona(zonaCentro.darUbicacion(),"Coliseo", "Coliseo.jpg", Sitio.ESCENARIOS, 1981, "Avenida G con Calle H");
		agregarSitioAZona(zonaCentro.darUbicacion(),"Estatua del Fundador", "EstatuaFundador.jpg", Sitio.INTERES, 1854, "Calle I con Carrera J");
		agregarSitioAZona(zonaCentro.darUbicacion(),"Tienda de Comics", "TiendaDeComics.jpg", Sitio.COMERCIAL, 1991, "Calle K con Avenida M");
		agregarSitioAZona(zonaCentro.darUbicacion(),"Primera Iglesia Cristiana", "PrimeraIglesiaCristiana.jpg", Sitio.INTERES, 1978, "Carrera N con Calle O");
		agregarSitioAZona(zonaCentro.darUbicacion(),"Restaurante de Comidas R�pidas", "ComidasRapidas.jpg", Sitio.COMERCIAL, 1995, "Calle P con Carrera Q");
		agregarSitioAZona(zonaSur.darUbicacion(),"Teatro de la �pera", "TeatroDeOpera.jpg", Sitio.CULTURAL, 2008, "Avenida R con Calle S");
		agregarSitioAZona(zonaSur.darUbicacion(),"Museo de Cera", "MuseoDeCera.jpg", Sitio.CULTURAL, 1998, "Diagonal T con Transversal U");
		agregarSitioAZona(zonaSur.darUbicacion(),"Tienda de Zurdos", "TiendaDeZurdos.jpg", Sitio.COMERCIAL, 1996, "Calle V con Diagonal W");
		agregarSitioAZona(zonaSur.darUbicacion(),"Museo Smithsonian", "MuseoSmithsonian.jpg", Sitio.CULTURAL, 2003, "Transversal X con Avenida Y");
	}
	
    //-----------------------------------------------------------------
    // M�todos
    //-----------------------------------------------------------------

	/**
	 * Retorna la zona ubicada en el norte de la ciudad
	 * @return zonaNorte
	 */
	public Zona darzonaNorte(){
		return zonaNorte;
	}
	
	/**
	 * Retorna la zona ubicada en el centro de la ciudad
	 * @return zonaCentro
	 */
	public Zona darzonaCentro(){
		return zonaCentro;
	}
	
	/**
	 * Retorna la zona ubicada en el sur de la ciudad
	 * @return zonaSur
	 */
	public Zona darzonaSur(){
		return zonaSur;
	}
	
	/**
	 * Agrega un nuevo sitio a la zona indicada en el par�metro ubicacionZona.<br/><br/>
	 * 
	 * Los dem�s par�metros son los valores de los atributos del nuevo objeto sitio
	 * agregado a la zona.<br/><br/>
	 * 
	 * Se retorna true si el sitio pudo ser agregado y false en caso de no poderse agregar.
	 * Esto �ltimo puede ocurrir debido a que no haya mas espacio en la zona (es decir,
	 * las cinco (5) relaciones ya tienen un objeto) � a que ya exista un sitio en la zona
	 * cuyo nombre sea igual al par�metro elNombre.
	 * 
	 * @param ubicacionZona La ubicaci�n de la zona donde se va a agregar el nuevo sitio.
	 * @param elNombre El nombre del nuevo sitio.
	 * @param elNombreImagen El nombre del archivo de la imagen del nuevo sitio.
	 * @param elTipoSitio El tipo de sitio del nuevo sitio.
	 * @param elAnhoConstruccion El a�o de construcci�n del nuevo sitio.
	 * @param laDireccion La direcci�n del nuevo sitio.
	 * @return true si se pudo agregar el nuevo objeto, false en caso contrario.
	 */
	public boolean agregarSitioAZona(int ubicacionZona,String elNombre, String elNombreImagen, String elTipoSitio, int elAnhoConstruccion, String laDireccion){
		return false;
	}
	
	/**
	 * Elimina el sitio cuyo nombre es igual al par�metro elNombre, de la zona
	 * indicada por el par�metro ubicacionZona.
	 * 
	 * @param ubicacionZona La ubicacion de la zona donde se va a eliminar el sitio.
	 * @param elNombre El nombre del sitio que va a eliminar.
	 * @return true si se pudo eliminar el sitio, false de lo contrario.
	 */
	public boolean eliminarSitioDeZona(int ubicacionZona,String elNombre){
		return false;
	}
	
	/**
	 * Busca la zona con mas cantidad de centros de salud.
	 * 
	 * @return La zona que tiene mas centros de salud.
	 */
	public Zona encontrarZonaMasCentrosSalud(){
		return null;
	}
	
	/** 
	 * Retorna el nombre de la ciudad.
	 * @return nombre
	 */
	public String darNombre() {
		return nombre;
	}
	
	/**
	 * Retorna el �ndice de desempleo de la ciudad
	 * @return desempleo
	 */
	public double darDesempleo() {
		return desempleo;
	}
	
	/**
	 * Retorna la cantidad de habitantes de la ciudad
	 * @return cantidadHabitantes
	 */
	public int darCantidadHabitantes() {
		return cantidadHabitantes;
	}
	
	/**
	 * Modifica el nombre de la ciudad por el valor pasado como par�metro.
	 * @param elNombre Es el nuevo nombre
	 */
	public void cambiarNombre(String elNombre) {
		nombre = elNombre;
	}
	
	/**
	 * Modifica el �ndice de desempleo de la ciudad por el valor pasado como par�metro.
	 * @param elDesempleo El nuevo porcentaje de desempleo.
	 */
	public void cambiarDesempleo(double elDesempleo) {
		desempleo = elDesempleo;
	}
	
	/**
	 * Modifica la cantidad de habitantes de la ciudad por el valor pasado como par�metro.
	 * @param laCantidadHabitantes La nueva cantidad de habitantes
	 */
	public void cambiarCantidadHabitantes(int laCantidadHabitantes) {
		cantidadHabitantes = laCantidadHabitantes;
	}
}
