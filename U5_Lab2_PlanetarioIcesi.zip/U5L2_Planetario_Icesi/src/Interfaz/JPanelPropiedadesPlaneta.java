package Interfaz;

import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;

import mundo.Planeta;

public class JPanelPropiedadesPlaneta extends JPanel{
	/**
	 * Esta es la declaracion de la etiqueta nombre
	 */
	private JLabel nombre;
	/**
	 * Esta es la declaracion de la etiqueta distancia
	 */
	private JLabel distancia;
	/**
	 * Esta es la declaracion de la etiqueta excentricidad
	 */
	private JLabel excentricidad;
	/**
	 * Esta es la declaracion de la etiqueta periodo
	 */
	private JLabel periodo;
	/**
	 * Esta es la declaracion de la etiqueta velocidad
	 */
	private JLabel velocidad;
	/**
	 * Esta es la declaracion de la etiqueta inclinacion
	 */
	private JLabel inclinacion;
	/**
	 * Esta es la declaracion del campo de texto pnombre, pdistancia, pexcentricidad, pperiodo, pvelocidad, pinclinacion
	 */
	private JTextField pnombre, pdistancia, pexcentricidad, pperiodo, pvelocidad, pinclinacion;
	/**
	 * Constructor del panel JPanelPropiedadesPlaneta
	 */
public JPanelPropiedadesPlaneta(){
	setLayout(new GridLayout(6,2));

	TitledBorder border = new TitledBorder("Propiedades del planeta");
setBorder(new TitledBorder("Propiedades del planeta"));
	nombre = new JLabel("Nombre:    ");
	add(nombre);
	
	pnombre = new JTextField("Mercurio");
	pnombre.setEditable(false);
	pnombre.setBorder(null);
	add(pnombre);
	
    distancia= new JLabel("Distancia media al sol:    ");
	add(distancia);
	
	pdistancia= new JTextField(0.466+" UA");
	pdistancia.setEditable(false);
	pdistancia.setBorder(null);
	add(pdistancia);
	
	excentricidad = new JLabel("Excetricidad:");
	add(excentricidad);
	
	pexcentricidad = new JTextField (0.205+"");
	pexcentricidad.setEditable(false);
	pexcentricidad.setBorder(null);
	add(pexcentricidad);
	
	periodo = new JLabel("Periodo Orbital:");
	add(periodo);
	
	pperiodo = new JTextField(115.88+ " Dias");
	pperiodo.setEditable(false);
	pperiodo.setBorder(null);
	add(pperiodo);
	
	velocidad = new JLabel("Velocidad Orbital: ");
	add(velocidad);
	
	pvelocidad = new JTextField(478.725 +" km/s");
	pvelocidad.setEditable(false);
	pvelocidad.setBorder(null);
	add(pvelocidad);
	
	inclinacion = new JLabel("Inclinacion:");
	add(inclinacion);
	
	pinclinacion = new JTextField(7.004+" �");
	pinclinacion.setEditable(false);
	pinclinacion.setBorder(null);
	add(pinclinacion);
	
	
	}
/**
 * metodo que se encarga de asignar los resultados a los textfield
 * @param nom parametro donde se le da el nombre
 * @param dis parametro donde se le da la distancia
 * @param excen parametro donde se le da la excentricidad
 * @param pro parametro donde se le da el periodo
 * @param vel parametro donde se le da la velocidad
 * @param incli parametro donde se le da la inclinacion
 */
	public void resultado(String nom, double dis, double excen, double pro, double vel, double incli) {
		pnombre.setText(nom);
		pdistancia.setText(dis + " UA");
		pexcentricidad.setText(excen + "");
		pperiodo.setText(pro + " Dias");
		pvelocidad.setText(vel + " km/s");
		pinclinacion.setText(incli + " �");

	}
}
