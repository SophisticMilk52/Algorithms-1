package Interfaz;

import java.awt.GridLayout;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

import mundo.Planeta;

public class JPanelimagen  extends JPanel{
	/**
	 * Esta es la etiqueta que contendra la imagen titulo
	 */
	private JLabel imagen;

/**
 * Este es el constructor del panel imagen
 * @param ruta es el parametro del constructor
 */
	public JPanelimagen(String ruta){
		setLayout(new GridLayout(1,1));
		imagen = new JLabel();
		ImageIcon icono = new ImageIcon(ruta);
		imagen.setIcon(icono);
		add(imagen);
	
}

}
