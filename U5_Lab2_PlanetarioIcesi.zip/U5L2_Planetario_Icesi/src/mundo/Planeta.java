package mundo;

import java.util.ArrayList;

/**
 * Clase que representa un planeta del sistema solar.
 *  @author Camilo Barrios
 */
public class Planeta
{
    // -----------------------------------------------------------------
    // Atributos
    // -----------------------------------------------------------------

    /**
     * Nombre del planeta.
     */
    private String nombre;

    /**
     * Distancia media al sol. Dada en UA.
     */
    private double distanciaMediaSol;

    /**
     * Excentricidad del planeta.
     */
    private double excentricidad;

    /**
     * Periodo de orbital del planeta. Dado en a�os.
     */
    private double periodoOrbitalSinodico;

    /**
     * Velocidad media del planeta. Dada en km/s.
     */
    private double velocidadOrbitalMedia;

    /**
     * Inclinaci�n del planeta. Dada en grados.
     */
    private double inclinacion;
 
    /**
     * Ruta de la imagen para mostar en la interfaz
     */
    private String rutaImagen;



    // -----------------------------------------------------------------
    // Constructores
    // -----------------------------------------------------------------
/**
 *  metodo se encarga de dar el nombre
 * @return nombre
 */
    public String getNombre() {
		return nombre;
	}



    /**
     *  metodo se encarga de dar el distancia
     * @return distancia
     */

	public double getDistanciaMediaSol() {
		return distanciaMediaSol;
	}



	/**
	 *  metodo se encarga de dar el excentricidad
	 * @return excentricidad
	 */


	public double getExcentricidad() {
		return excentricidad;
	}






	/**
	 *  metodo se encarga de dar el periodoOrbitalSinodico
	 * @return periodoOrbitalSinodico
	 */
	public double getPeriodoOrbitalSinodico() {
		return periodoOrbitalSinodico;
	}





	/**
	 *  metodo se encarga de dar el velocidadOrbitalMedia
	 * @return velocidadOrbitalMedia
	 */
	public double getVelocidadOrbitalMedia() {
		return velocidadOrbitalMedia;
	}





	/**
	 *  metodo se encarga de dar el inclinacion
	 * @return inclinacion
	 */

	public double getInclinacion() {
		return inclinacion;
	}






	/**
	 *  metodo se encarga de dar el rutaImagen
	 * @return rutaImagen
	 */

	public String getRutaImagen() {
		return rutaImagen;
	}







	/**
     * Construye un planeta con los datos suministrados por par�metro.
     * @param pNombre Nombre del planeta. pNombre != null && pNombre != ""
     * @param pDistanciaMediaSol Distancia media al sol. pDistanciaMediaSol > 0
     * @param pExcentricidad Excentricidad de la �rbita.
     * @param pPeriodoOrbitalSinodico Periodo orbital sin�dico.
     * @param pVelocidadOrbitalMedia Velocidad media del planeta.
     * @param pInclinacion Inclinaci�n del planeta con respecto a su eje.
     * @param laRuta Ruta de la imagen para mostar en la interfaz.
     * 
     */
    public Planeta( String pNombre, double pDistanciaMediaSol, double pExcentricidad, double pPeriodoOrbitalSinodico, double pVelocidadOrbitalMedia, double pInclinacion, String laRuta)
    {
        nombre = pNombre;
        distanciaMediaSol = pDistanciaMediaSol;
        excentricidad = pExcentricidad;
        periodoOrbitalSinodico = pPeriodoOrbitalSinodico;
        velocidadOrbitalMedia = pVelocidadOrbitalMedia;
        inclinacion = pInclinacion;
        rutaImagen = laRuta;

    }

}
