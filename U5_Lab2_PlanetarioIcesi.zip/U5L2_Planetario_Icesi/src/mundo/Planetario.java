
package mundo;

import java.util.ArrayList;


/**
 * Clase que representa el observatorio.
 * @author Camilo Barrios
 */
public class Planetario
{
    // -----------------------------------------------------------------
    // Constantes
    // -----------------------------------------------------------------

    /**
     * Constante que determina la cantidad de elementos que tiene el arreglo de planetas.
     */
    public static final int CANTIDAD_PLANETAS = 8;

    /**
     * Constante que determina el nombre del planeta Mercurio.
     */
    public static final String NOMBRE_MERCURIO = "Mercurio";

    /**
     * Constante que determina el nombre del planeta Venus.
     */
    public static final String NOMBRE_VENUS = "Venus";

    /**
     * Constante que determina el nombre del planeta Tierra.
     */
    public static final String NOMBRE_TIERRA = "Tierra";

    /**
     * Constante que determina el nombre del planeta Marte.
     */
    public static final String NOMBRE_MARTE = "Marte";
    
    /**
     * Constante que determina el nombre del planeta J�piter.
     */
    public static final String NOMBRE_JUPITER = "J�piter";

    /**
     * Constante que determina el nombre del planeta Saturno.
     */
    public static final String NOMBRE_SATURNO = "Saturno";

    /**
     * Constante que determina el nombre del planeta Urano.
     */
    public static final String NOMBRE_URANO = "Urano";

    /**
     * Constante que determina el nombre del planeta Neptuno.
     */
    public static final String NOMBRE_NEPTUNO = "Neptuno";


    // -----------------------------------------------------------------
    // Atributos
    // -----------------------------------------------------------------

    /**
     * Arreglo que contiene los planetas del sistema solar.
     */
    private Planeta[] planetas;

    // -----------------------------------------------------------------
    // Constructores
    // -----------------------------------------------------------------

    /**
     * Construye el observatorio con los siguientes planetas: <br>
     * planetas[0] - nombre: Mercurio - distanciMediaSol: 0.466 - excentricidad: 0.205 - periodoOrbital: 115.88 - velocidad: 478.725 - inclinaci�n: 7.004. - La ruta donde est� la imagen <br>
     * planetas[1] - nombre: Venus - distanciMediaSol: 0.728 - excentricidad: 0.006 - periodoOrbital: 583.92 - velocidad: 35.021 - inclinaci�n: 339.471.-La ruta donde est� la imagen <br>
     * planetas[2] - nombre: Tierra - distanciMediaSol: 1.016 - excentricidad: 0.0167 - periodoOrbital: 365.25 - velocidad: 30.28 - inclinaci�n: 23.45. - La ruta donde est� la imagen<br>
     * planetas[3] - nombre: Marte - distanciMediaSol: 1.665 - excentricidad: 0.09341233 - periodoOrbital: 779.95 - velocidad: 24.13 - inclinaci�n: 1.850. - La ruta donde est� la imagen<br>
     * planetas[4] - nombre: J�piter - distanciMediaSol: 5.458 - excentricidad: 0.09341233 - periodoOrbital: 398.9 - velocidad: 13.069 - inclinaci�n: 1.305. - La ruta donde est� la imagen<br>
     * planetas[5] - nombre: Saturno - distanciMediaSol: 10.115 - excentricidad: 0.0541506 - periodoOrbital: 378.1 - velocidad: 9.67 - inclinaci�n: 2.484. - La ruta donde est� la imagen<br>
     * planetas[6] - nombre: Urano - distanciMediaSol: 20.096 - excentricidad: 0.04716771 - periodoOrbital: 369.7 - velocidad: 6.835 - inclinaci�n: 0.769. - La ruta donde est� la imagen<br>
     * planetas[7] - nombre: Neptuno - distanciMediaSol: 30.327 - excentricidad: 0.00858587 - periodoOrbital: 367.5 - velocidad: 5.47 - inclinaci�n: 1.769. - La ruta donde est� la imagen
     */
    public Planetario( )
    {
    	 planetas = new Planeta[CANTIDAD_PLANETAS];
         planetas[ 0 ] = new Planeta( NOMBRE_MERCURIO, 0.466, 0.205, 115.88, 478.725, 7.004, "data/"+NOMBRE_MERCURIO+".jpg" );
         planetas[ 1 ] = new Planeta( NOMBRE_VENUS, 0.728, 0.006, 583.92, 35.021, 339.471, "data/"+NOMBRE_VENUS+".jpg");
         planetas[ 2 ] = new Planeta( NOMBRE_TIERRA, 1.016, 0.0167, 365.25, 30.28, 23.45,"data/"+NOMBRE_TIERRA+".jpg" );
         planetas[ 3 ] = new Planeta( NOMBRE_MARTE, 1.665, 0.09341233, 779.95, 24.13, 1.850,"data/"+NOMBRE_MARTE+".jpg" );
         planetas[ 4 ] = new Planeta( NOMBRE_JUPITER, 5.458, 0.09341233, 398.9, 13.069, 1.305,"data/"+NOMBRE_JUPITER+".jpg" );
         planetas[ 5 ] = new Planeta( NOMBRE_SATURNO, 10.115, 0.0541506, 378.1, 9.67, 2.484,"data/"+NOMBRE_SATURNO+".jpg" );
         planetas[ 6 ] = new Planeta( NOMBRE_URANO, 20.096, 0.04716771, 369.7, 6.835, 0.769,"data/"+NOMBRE_URANO+".jpg");
         planetas[ 7 ] = new Planeta( NOMBRE_NEPTUNO, 30.327, 0.00858587, 367.5, 5.47, 1.769,"data/"+NOMBRE_NEPTUNO+".jpg");
    }
    /**
     * Este metodo se encarga de mover adelante o atras en el contador de Planeta
     * @param con parametro del indice del contador donde estara ubicado
     * @return pl el planeta donde esta ubicado
     */
	public Planeta AtrasAdelante(int con) {
		Planeta pl = null;
		for (int i = 0; i < planetas.length; i++) {
			if (con < 0) {
				pl = planetas[planetas.length - 1];
			} else if (con == planetas.length) {
				pl = planetas[0];
			} else if (con == i) {
				pl = planetas[con];
			}
		}
		return pl;
	}
    
/**
 * busca el planeta que cumpla el nombre en el contador Planeta
 * @param nombre el parametro que se le asigna
 * @return pl retorna el Planeta que se busco
 * @throws Exception pl==null el planeta no existe
 */
	public Planeta Buscar(String nombre)throws Exception {

		Planeta pl = null;
		String plan = "";
		for (int i = 0; i < planetas.length; i++) {
			if (planetas[i] != null) {
				plan = planetas[i].getNombre();
				if (plan.equalsIgnoreCase(nombre)) {
					
					pl = planetas[i];
				}
				
			}
		}if(pl==null){
			throw new Exception("Este planeta no existe");
		}
		return pl;

	}
/**
 * Este metodo se encarga de encontrar el planeta que tiene mas grados de inclinacion
 * @return mensaje es el mensaje
 */
	public String Opcion1() {
		double coso = 0.0;
		String mensaje = "";
		String nombre = "";
		for (int i = 0; i < planetas.length; i++) {
			if (planetas[i] != null) {

				if (coso < planetas[i].getInclinacion()) {
					coso = planetas[i].getInclinacion();
					nombre = planetas[i].getNombre();

				}
			}
		}
		mensaje = "El planeta de mayor inclinacion es " + nombre + " con inclinacion de: " + coso + " grados";
		return mensaje;

	}
	/**
	 * Este metodo se encarga de hallar la distancia de los planetas con respecto a la tierra
	 * @param nom es la posicion del planeta
	 * @return distancia es la distancia entre los planetas
	 */
	public double Opcion2(int nom) {
		double distancia = 0;
		double tierra = 1.016;
		for (int i = 0; i < planetas.length; i++) {
		
				if (i==nom) {
				
					if (planetas[i].getDistanciaMediaSol() > tierra) {
						distancia =planetas[i].getDistanciaMediaSol()- tierra;
					} else {
						distancia = tierra -planetas[i].getDistanciaMediaSol();

					}

				}

			}

		
		return distancia;
	}
}