package mundo;

import java.util.ArrayList;

public class Stand {
private String nombre;
private ArrayList<Venta> ventas;


public Stand(String nombre) {
	this.nombre = nombre;
	this.ventas = new ArrayList <Venta>();
}

public void AgregarBebidaUnica(int costo, String tipo){
	
	Venta coso= new Venta(1,costo,tipo);	
	ventas.add(coso);
}

public void AgregarBebidas(int vasos, int costo, String tipo){
	Venta coso= new Venta(vasos,costo,tipo);	
	ventas.add(coso);
}

public int VentasNaranja(){
	int ventasNaranja=0;
	for(int i=0;i<ventas.size();i++){
		if(ventas.get(i).getTipoVenta()==Venta.NARANJA){
		ventasNaranja+= ventas.get(i).getPrecioUnitario()*ventas.get(i).getVasosVendidos();
	}}
	return ventasNaranja;
	
	
}
public int VentasMenta(){
	int ventasNaranja=0;
	for(int i=0;i<ventas.size();i++){
		if(ventas.get(i).getTipoVenta()==Venta.MENTA){
		ventasNaranja+= ventas.get(i).getPrecioUnitario()*ventas.get(i).getVasosVendidos();
	}}
	return ventasNaranja;
}
public String MasVentas(){
	
	String mensaje="SON IGUALES";
if(VentasNaranja()<this.VentasMenta()){
	mensaje="MENTA_LIMON";
}else if(VentasNaranja()>this.VentasMenta()){
	mensaje="NARANJA_LIMON";
	}
return mensaje;
	
}

	public String MasVasosEnVenta() {
		String mensaje = "";
		int coso = 0;
		for (int i = 0; i < ventas.size(); i++) {
			coso = ventas.get(0).getVasosVendidos();
			if (coso > ventas.get(i).getVasosVendidos()) {
				if (ventas.get(0).getTipoVenta() == Venta.MENTA) {

					mensaje = coso + " DE MENTA";
				} else if (ventas.get(0).getTipoVenta() == Venta.NARANJA) {
					mensaje = coso + "DE NARANJA";
				} else {
					coso = ventas.get(i).getVasosVendidos();

				}

				if (ventas.get(i).getTipoVenta() == Venta.MENTA) {

					mensaje = coso + " DE MENTA";
				} else if (ventas.get(i).getTipoVenta() == Venta.NARANJA) {
					mensaje = coso + "DE NARANJA";

				}
			}

		}
		return mensaje;

	}
	
	public String Transacciones(){
		String mensaje="";
		int vaso=0;
		for(int i=0;i <ventas.size();i++){
			vaso= ventas.get(ventas.size()-1).getVasosVendidos();
			
			if(ventas.get(ventas.size()-1).getTipoVenta()==Venta.MENTA){
				mensaje= vaso+" de Menta";
			}else{ mensaje= vaso+" de Naranja";
			}
			}
			return mensaje;
	}
}
