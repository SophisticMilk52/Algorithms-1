package mundo;

public class Venta {
	//CONSTATNES
	public static final String MENTA="m";
	public static final String NARANJA="n";
	//ATRIBUTOS
private int vasosVendidos;
private int precioUnitario;
private String tipoVenta;
//GET SET
public int getVasosVendidos() {
	return vasosVendidos;
}
public void setVasosVendidos(int vasosVendidos) {
	this.vasosVendidos = vasosVendidos;
}
public int getPrecioUnitario() {
	return precioUnitario;
}
public void setPrecioUnitario(int precioUnitario) {
	this.precioUnitario = precioUnitario;
}
public String getTipoVenta() {
	return tipoVenta;
}
public void setTipoVenta(String tipoVenta) {
	this.tipoVenta = tipoVenta;
}
//METODO CONSTRUCTOR
public Venta(int vasosVendidos, int costo, String tipoVenta) {
	this.vasosVendidos = vasosVendidos;
	this.precioUnitario = costo;
	this.tipoVenta = tipoVenta;
}

}
