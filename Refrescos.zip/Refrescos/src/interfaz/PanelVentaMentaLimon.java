package interfaz;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
public class PanelVentaMentaLimon extends JPanel implements ActionListener {
	
	private JButton btnMasVasos;
	private JTextField txtMaVasos;
	private JTextField txtMaVasos1;
	private JLabel costo;
	private PanelImagen imagen;
	private JButton UnVaso;
	private InterfazVentaRefrescos principal;
	public final static String MASVASOS="MasVasos";
	public final static String UNVASO="UnVaso";
	
	
	public PanelVentaMentaLimon(InterfazVentaRefrescos o){
		

	setLayout(new BorderLayout());
	principal=o;
	TitledBorder border = new TitledBorder("Venta de Menta-Limon");
	
	setBorder(border);
	
	imagen = new PanelImagen("./data/bebidaDos.jpg");
	
	add(imagen, BorderLayout.NORTH);
	
	JPanel aux2 = new JPanel();
	
	aux2.setLayout(new BorderLayout());
	
	 UnVaso = new JButton("1 Vaso");
	 
	UnVaso.addActionListener(this);

	UnVaso.setActionCommand(UNVASO);
	aux2.add(UnVaso, BorderLayout.NORTH);
	
	add(aux2, BorderLayout.CENTER);


JPanel aux = new JPanel();

aux.setLayout(new GridLayout(2,2));

btnMasVasos= new JButton("+ Vasos");
btnMasVasos.addActionListener(this);

btnMasVasos.setActionCommand(MASVASOS);
aux.add(btnMasVasos);

txtMaVasos= new JTextField();
aux.add(txtMaVasos);
costo= new JLabel("Costos:");
aux.add(costo);
txtMaVasos1= new JTextField();
aux.add(txtMaVasos1);



add(aux, BorderLayout.SOUTH);

aux2.add(aux,BorderLayout.CENTER);

	}
	
	
	
	
	public void actionPerformed(ActionEvent e) {

		if(e.getActionCommand().equals(MASVASOS)|| e.getActionCommand().equals(UNVASO)){
			if(UnVaso.equals("")|| btnMasVasos.equals("")){
				JOptionPane.showMessageDialog(principal, "Llenar todos los campos");
			}else{
				principal.jugos(btnMasVasos.getText().trim());
				principal.jugos(UnVaso.getText().trim());
	}
}}}
	
	
	
	
	

	
	

