package interfaz;

import java.awt.*;
import javax.swing.*;

import mundo.Stand;


public class InterfazVentaRefrescos extends JFrame{

	private PanelVentaNaranjaLimon panelVentaNaranjaLimon;
	private PanelVentaMentaLimon panelVentaMentaLimon;
	private PanelImagen panelImagen;
	private panelBoton PanelBoton;
	
	private Stand mundo;
	
	public InterfazVentaRefrescos(){
		
		mundo=new Stand(getName());
	setLayout(new BorderLayout());
	setSize(600,400);
	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	panelImagen = new PanelImagen("./data/banner.png");

	
	add(panelImagen, BorderLayout.NORTH);
	panelVentaNaranjaLimon = new PanelVentaNaranjaLimon(this);
	add(panelVentaNaranjaLimon, BorderLayout.WEST);
	
	panelVentaMentaLimon = new PanelVentaMentaLimon(this);
	add(panelVentaMentaLimon, BorderLayout.EAST);
	
	PanelBoton = new panelBoton(panelVentaNaranjaLimon);
	add(PanelBoton, BorderLayout.CENTER);
	
	
	}
	
	public static void main(String args[]){
	InterfazVentaRefrescos ventana = new InterfazVentaRefrescos();	
	ventana.setVisible(true);
		
	}

	
	
	
	
	public void jugos(String no) {
		int referencia = 0;
	
		try {
		
			referencia = Integer.parseInt(no);
			String tipo;
			int costo;
		//	mundo.AgregarBebidaUnica(costo, tipo);
			 int vasos;
	//		varios= mundo.AgregarBebidas(vasos, costo, tipo);
	
		
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "no se pudo convetir");
		}
		
		
		
	}
	
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

