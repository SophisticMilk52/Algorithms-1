package interfaz;

import java.awt.GridLayout;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class PanelImagen extends JPanel{

	private JLabel imagen;
	
	public PanelImagen(String ruta){
		
		setLayout(new GridLayout(1,1));
		
		imagen = new JLabel();
		
		ImageIcon icono = new ImageIcon(ruta);
		
		imagen.setIcon(icono);
		
		add(imagen);
	}
	
	
}
