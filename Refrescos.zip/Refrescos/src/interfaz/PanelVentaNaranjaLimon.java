package interfaz;

import java.awt.*;

import javax.swing.*;
import javax.swing.border.TitledBorder;

public class PanelVentaNaranjaLimon extends JPanel{
	private JButton btnMasVasos;
	private JTextField txtMaVasos;
	private JTextField txtMaVasos1;
	private JLabel costo;
	private PanelImagen imagen;
	private JButton UnVaso;
    private panelBoton importante;
	private InterfazVentaRefrescos principal;
	public PanelVentaNaranjaLimon(InterfazVentaRefrescos o){
		principal=o;
	
	setLayout(new BorderLayout());
	
	TitledBorder border = new TitledBorder("Venta de Naranja-Limon");
	
	setBorder(border);
	
	imagen = new PanelImagen("./data/bebidaUno.jpg");
	
	add(imagen, BorderLayout.NORTH);
	
	JPanel aux2 = new JPanel();
	
	aux2.setLayout(new BorderLayout());
	
	JButton unVaso = new JButton("1 Vaso");
	
	aux2.add(unVaso, BorderLayout.NORTH);
	
	add(aux2, BorderLayout.CENTER);
importante= new panelBoton(this);

JPanel aux = new JPanel();

aux.setLayout(new GridLayout(2,2));

btnMasVasos= new JButton("+ Vasos");
aux.add(btnMasVasos);

txtMaVasos= new JTextField();
aux.add(txtMaVasos);
costo= new JLabel("Costos:");
aux.add(costo);
txtMaVasos1= new JTextField();
aux.add(txtMaVasos1);



add(aux, BorderLayout.SOUTH);

aux2.add(aux,BorderLayout.CENTER);

	}
	
}