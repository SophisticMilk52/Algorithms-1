package interfaz;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.TitledBorder;

public class panelBoton extends JPanel{

	private JLabel  label1;
	private JLabel  label2;
	private JLabel  label3;
	private JLabel  label4;
	private JLabel  label5;
	private JTextField text1;
	private JTextField text2;
	private JTextField text3;
	private JTextField text4;
	private JTextField text5;
private PanelVentaNaranjaLimon principal;
	public panelBoton(PanelVentaNaranjaLimon o){

principal=o;
		TitledBorder br= new TitledBorder("Reportes");
		br.setTitleColor(Color.BLACK);
		setBorder(br);
		
setLayout(new GridLayout(5,2));
		label1= new JLabel ("Naranja-Limon:");
		add(label1);
		text1= new JTextField("$ 5000.0");
		text1.setEditable(false);
		add(text1);
		label2= new JLabel ("Menta-Limon:");
		add(label2);
		text2= new JTextField("$ 7500.0");
		text2.setEditable(false);
		add(text2);
		label3= new JLabel ("Mayores Ventas:");
		add(label3);
		text3= new JTextField("Menta-Limon");
		text3.setEditable(false);
		add(text3);
		label4= new JLabel ("+ Vasos en una venta:");
		add(label4);
		text4= new JTextField("3 de Naranja-Limon");
		text4.setEditable(false);
		add(text4);
		label5= new JLabel ("Transacciones:");
		add(label5);
		text5= new JTextField("4 de menta limon");
		text5.setEditable(false);
		add(text5);
	
		
		
	}
	








public void Modificar(int naranja, int menta){
text1.setText(naranja+"");
text2.setText(menta+"");
	
}	
}
