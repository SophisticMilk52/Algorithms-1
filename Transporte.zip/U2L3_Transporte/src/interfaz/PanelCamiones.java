package interfaz;

import java.awt.*;
import java.awt.image.*;

import mundo.*;

import javax.swing.*;
import javax.swing.border.TitledBorder;

public class PanelCamiones extends JPanel {

	private JLabel camion1;
	private JLabel camion2;
	private JLabel camion3;
	private JLabel camion4;
	private JLabel capacidad1;
	private JLabel capacidad2;
	private JLabel capacidad3;
	private JLabel capacidad4;
	private JLabel consumo1;
	private JLabel consumo2;
	private JLabel consumo3;
	private JLabel consumo4;
	private JLabel tipo1;
	private JLabel tipo2;
	private JLabel tipo3;
	private JLabel tipo4;
	private JLabel kilometraje1;
	private JLabel kilometraje2;
	private JLabel kilometraje3;
	private JLabel kilometraje4;
	private JLabel fechaSeguro1;
	private JLabel fechaSeguro2;
	private JLabel fechaSeguro3;
	private JLabel fechaSeguro4;
	private JLabel caballosFuerza1;
	private JLabel caballosFuerza2;
	private JLabel caballosFuerza3;
	private JLabel caballosFuerza4;

	public PanelCamiones(Principal principal) {
		TitledBorder border = BorderFactory
				.createTitledBorder("Camiones de la empresa");
		border.setTitleColor(Color.BLUE);
		setBorder(border);

		JLabel imagen1 = new JLabel();
		imagen1.setPreferredSize(new Dimension(155, 155));
		imagen1.setIcon(resize("./data/img/"
				+ principal.darEmpresa().darSitioParqueoUno().darCamionUno()
						.darFoto()));
		imagen1.revalidate();

		JLabel imagen2 = new JLabel();
		imagen2.setPreferredSize(new Dimension(155, 155));
		imagen2.setIcon(resize("./data/img/"
				+ principal.darEmpresa().darSitioParqueoUno().darCamionDos()
						.darFoto()));
		imagen2.revalidate();
		JLabel imagen3 = new JLabel();
		imagen3.setPreferredSize(new Dimension(155, 155));
		imagen3.setIcon(resize("./data/img/"
				+ principal.darEmpresa().darSitioParqueoUno().darCamionTres()
						.darFoto()));
		imagen3.revalidate();
		JLabel imagen4 = new JLabel();
		imagen4.setPreferredSize(new Dimension(155, 155));
		imagen4.setIcon(resize("./data/img/"
				+ principal.darEmpresa().darSitioParqueoUno().darCamionCuatro()
						.darFoto()));
		imagen4.revalidate();

		camion1 = new JLabel("Placa: "+principal.darEmpresa().darSitioParqueoUno()
				.darCamionUno().darPlaca());
		camion2 = new JLabel("Placa: "+principal.darEmpresa().darSitioParqueoUno()
				.darCamionDos().darPlaca());
		camion3 = new JLabel("Placa: "+principal.darEmpresa().darSitioParqueoUno()
				.darCamionTres().darPlaca());
		camion4 = new JLabel("Placa: "+principal.darEmpresa().darSitioParqueoUno()
				.darCamionCuatro().darPlaca());
		capacidad1 = new JLabel("Capacidad: "
				+ principal.darEmpresa().darSitioParqueoUno().darCamionUno()
						.darCapacidad() + " Ton");
		capacidad2 = new JLabel("Capacidad: "
				+ principal.darEmpresa().darSitioParqueoUno().darCamionDos()
						.darCapacidad() + " Ton");
		capacidad3 = new JLabel("Capacidad: "
				+ principal.darEmpresa().darSitioParqueoUno().darCamionTres()
						.darCapacidad() + " Ton");
		capacidad4 = new JLabel("Capacidad: "
				+ principal.darEmpresa().darSitioParqueoUno().darCamionCuatro()
						.darCapacidad() + " Ton");
		consumo1 = new JLabel("Consumo: "
				+ principal.darEmpresa().darSitioParqueoUno().darCamionUno()
						.darConsumo() + " gal/Km");
		consumo2 = new JLabel("Consumo: "
				+ principal.darEmpresa().darSitioParqueoUno().darCamionDos()
						.darConsumo() + " gal/Km");
		consumo3 = new JLabel("Consumo: "
				+ principal.darEmpresa().darSitioParqueoUno().darCamionTres()
						.darConsumo() + " gal/Km");
		consumo4 = new JLabel("Consumo: "
				+ principal.darEmpresa().darSitioParqueoUno().darCamionCuatro()
						.darConsumo() + " gal/Km");
		tipo1 = new JLabel("Tipo: "+(principal.darEmpresa().darSitioParqueoUno().darCamionUno().darTipo()));
		tipo2 = new JLabel("Tipo: "+(principal.darEmpresa().darSitioParqueoUno()
				.darCamionDos().darTipo()));
		tipo3 = new JLabel("Tipo: "+(principal.darEmpresa().darSitioParqueoUno()
				.darCamionTres().darTipo()));
		tipo4 = new JLabel("Tipo: "+(principal.darEmpresa().darSitioParqueoUno()
				.darCamionCuatro().darTipo()));
		kilometraje1 = new JLabel("Kilometros: "+principal.darEmpresa().darSitioParqueoUno()
				.darCamionUno().darKilometraje());
		kilometraje2 = new JLabel("Kilometros: "+principal.darEmpresa().darSitioParqueoUno()
				.darCamionDos().darKilometraje());
		kilometraje3 = new JLabel("Kilometros: "+principal.darEmpresa().darSitioParqueoUno()
				.darCamionTres().darKilometraje());
		kilometraje4 = new JLabel("Kilometros: "+principal.darEmpresa().darSitioParqueoUno()
				.darCamionCuatro().darKilometraje());
		fechaSeguro1 = new JLabel(principal.darEmpresa().darSitioParqueoUno()
				.darCamionUno().darFechaSeguro().toString());
		fechaSeguro2 = new JLabel(principal.darEmpresa().darSitioParqueoUno()
				.darCamionDos().darFechaSeguro().toString());
		fechaSeguro3 = new JLabel(principal.darEmpresa().darSitioParqueoUno()
				.darCamionTres().darFechaSeguro().toString());
		fechaSeguro4 = new JLabel(principal.darEmpresa().darSitioParqueoUno()
				.darCamionCuatro().darFechaSeguro().toString());
		
		caballosFuerza1 = new JLabel("C.Fuerza: " + principal.darEmpresa().darSitioParqueoUno()
				.darCamionUno().darCaballosFuerza());
		caballosFuerza2 = new JLabel("C.Fuerza: " + principal.darEmpresa().darSitioParqueoUno()
				.darCamionDos().darCaballosFuerza());
		caballosFuerza3 = new JLabel("C.Fuerza: " + principal.darEmpresa().darSitioParqueoUno()
				.darCamionTres().darCaballosFuerza());
		caballosFuerza4 = new JLabel("C.Fuerza: " + principal.darEmpresa().darSitioParqueoUno()
				.darCamionCuatro().darCaballosFuerza());
	

		setLayout(null);

		add(imagen1);
		add(imagen2);
		add(imagen3);
		add(imagen4);
		add(camion1);
		add(camion2);
		add(camion3);
		add(camion4);
		add(capacidad1);
		add(capacidad2);
		add(capacidad3);
		add(capacidad4);
		add(consumo1);
		add(consumo2);
		add(consumo3);
		add(consumo4);
		add(tipo1);
		add(tipo2);
		add(tipo3);
		add(tipo4);
		add(kilometraje1);
		add(kilometraje2);
		add(kilometraje3);
		add(kilometraje4);
		add(fechaSeguro1);
		add(fechaSeguro2);
		add(fechaSeguro3);
		add(fechaSeguro4);
		add(caballosFuerza1);
		add(caballosFuerza2);
		add(caballosFuerza3);
		add(caballosFuerza4);

		Insets insets = getInsets();

		Dimension size;

		/*
		 * = veterinario.getPreferredSize(); veterinario.setBounds(15 +
		 * insets.left, 15 + insets.top, size.width, size.height);
		 */

		size = imagen1.getPreferredSize();
		imagen1.setBounds(10 + insets.left, 30 + insets.top, size.width,
				size.height);
		size = imagen2.getPreferredSize();
		imagen2.setBounds(170 + insets.left, 30 + insets.top, size.width,
				size.height);
		size = imagen3.getPreferredSize();
		imagen3.setBounds(330 + insets.left, 30 + insets.top, size.width,
				size.height);
		size = imagen4.getPreferredSize();
		imagen4.setBounds(490 + insets.left, 30 + insets.top, size.width,
				size.height);

		size = camion1.getPreferredSize();
		camion1.setBounds(10 + insets.left, 190 + insets.top, size.width,
				size.height);
		size = camion2.getPreferredSize();
		camion2.setBounds(170 + insets.left, 190 + insets.top, size.width,
				size.height);
		size = camion3.getPreferredSize();
		camion3.setBounds(330 + insets.left, 190 + insets.top, size.width,
				size.height);
		size = camion4.getPreferredSize();
		camion4.setBounds(490 + insets.left, 190 + insets.top, size.width,
				size.height);

		size = capacidad1.getPreferredSize();
		capacidad1.setBounds(10 + insets.left, 205 + insets.top, size.width,
				size.height);
		size = capacidad2.getPreferredSize();
		capacidad2.setBounds(170 + insets.left, 205 + insets.top, size.width,
				size.height);
		size = capacidad3.getPreferredSize();
		capacidad3.setBounds(330 + insets.left, 205 + insets.top, size.width,
				size.height);
		size = capacidad4.getPreferredSize();
		capacidad4.setBounds(490 + insets.left, 205 + insets.top, size.width,
				size.height);

		size = consumo1.getPreferredSize();
		consumo1.setBounds(10 + insets.left, 220 + insets.top, size.width,
				size.height);
		size = consumo2.getPreferredSize();
		consumo2.setBounds(170 + insets.left, 220 + insets.top, size.width,
				size.height);
		size = consumo3.getPreferredSize();
		consumo3.setBounds(330 + insets.left, 220 + insets.top, size.width,
				size.height);
		size = consumo4.getPreferredSize();
		consumo4.setBounds(490 + insets.left, 220 + insets.top, size.width,
				size.height);

		size = tipo1.getPreferredSize();
		tipo1.setBounds(10 + insets.left, 235 + insets.top, size.width,
				size.height);
		size = tipo2.getPreferredSize();
		tipo2.setBounds(170 + insets.left, 235 + insets.top, size.width,
				size.height);
		size = tipo3.getPreferredSize();
		tipo3.setBounds(330 + insets.left, 235 + insets.top, size.width,
				size.height);
		size = tipo4.getPreferredSize();
		tipo4.setBounds(490 + insets.left, 235 + insets.top, size.width,
				size.height);

		size = kilometraje1.getPreferredSize();
		kilometraje1.setBounds(10 + insets.left, 250 + insets.top, size.width,
				size.height);
		size = kilometraje2.getPreferredSize();
		kilometraje2.setBounds(170 + insets.left, 250 + insets.top, size.width,
				size.height);
		size = kilometraje3.getPreferredSize();
		kilometraje3.setBounds(330 + insets.left, 250 + insets.top, size.width,
				size.height);
		size = kilometraje4.getPreferredSize();
		kilometraje4.setBounds(490 + insets.left, 250 + insets.top, size.width,
				size.height);

		size = fechaSeguro1.getPreferredSize();
		fechaSeguro1.setBounds(10 + insets.left, 265 + insets.top,
				size.width, size.height);
		size = fechaSeguro2.getPreferredSize();
		fechaSeguro2.setBounds(170 + insets.left, 265 + insets.top,
				size.width, size.height);
		size = fechaSeguro3.getPreferredSize();
		fechaSeguro3.setBounds(330 + insets.left, 265 + insets.top,
				size.width, size.height);
		size = fechaSeguro4.getPreferredSize();
		fechaSeguro4.setBounds(490 + insets.left, 265 + insets.top,
				size.width, size.height);
		

		size = caballosFuerza1.getPreferredSize();
		caballosFuerza1.setBounds(10 + insets.left, 280 + insets.top,
				size.width, size.height);
		size = caballosFuerza2.getPreferredSize();
		caballosFuerza2.setBounds(170 + insets.left, 280 + insets.top,
				size.width, size.height);
		size = caballosFuerza3.getPreferredSize();
		caballosFuerza3.setBounds(330 + insets.left, 280 + insets.top,
				size.width, size.height);
		size = caballosFuerza4.getPreferredSize();
		caballosFuerza4.setBounds(490 + insets.left, 280 + insets.top,
				size.width, size.height);

		setPreferredSize(new Dimension(660, 320));

	}

	public ImageIcon resize(String ruta) {
		ImageIcon icon = new ImageIcon(ruta);
		Image img = icon.getImage();
		BufferedImage bi = new BufferedImage(img.getWidth(null),
				img.getHeight(null), BufferedImage.TYPE_INT_ARGB);
		Graphics g = bi.createGraphics();
		g.drawImage(img, 0, 0, null);
		ImageIcon newIcon = new ImageIcon(bi);
		return newIcon;
	}

}
