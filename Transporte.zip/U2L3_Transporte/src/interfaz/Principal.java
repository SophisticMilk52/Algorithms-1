package interfaz;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import mundo.*;

public class Principal extends JFrame {

	private Empresa empresa;
	private PanelBanner banner;
	private PanelCamiones panelCamiones;
	private PanelBotones panelBotones;

	public Principal() {
		empresa = new Empresa();

		banner = new PanelBanner();
		panelCamiones = new PanelCamiones(this);
		panelBotones = new PanelBotones(this);

		setLayout(null);

		add(banner);
		add(panelCamiones);
		add(panelBotones);

		int antY = 0;

		Insets insets = getInsets();
		Dimension size = banner.getPreferredSize();
		banner.setBounds(insets.left, insets.top, size.width, size.height);
		antY = insets.top + size.height;

		size = panelCamiones.getPreferredSize();
		panelCamiones.setBounds(insets.left, antY, size.width, size.height);

		antY = antY + size.height;
		size = panelBotones.getPreferredSize();
		panelBotones.setBounds(insets.left, antY, size.width, size.height);

		pack();

		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent we) {
				System.exit(0);
			}
		});

	}

	public String opcionUno() {
		
		String respuesta = "Reporte Camion con menor consumo \n";
		respuesta += "Placa del camion:\n";
		respuesta += empresa.darSitioParqueoUno().seleccionarCamion();
		return respuesta;
	}

	public String opcionDos() {
		String respuesta = "Reporte Cantidad Aceite \n";
		
		respuesta += empresa.darSitioParqueoUno().reporteLitrosAceiteCamiones();

		return respuesta;
	}
	
	public String opcionTres(){
		
		String respuesta = "Reporte Fecha del Seguro \n";

		respuesta += "Camion 1: "
				+ empresa.darSitioParqueoUno().darCamionUno().darPlaca()
				+ " - "
				+ empresa.darSitioParqueoUno().darCamionUno().calcularSemanasYDiasParaSeguro(
						Fecha.restaFechas(Fecha.darFechaActual(), empresa
								.darSitioParqueoUno().darCamionUno().darFechaSeguro())) + "\n";
		respuesta += "Camion 2: "
				+ empresa.darSitioParqueoUno().darCamionDos().darPlaca()
				+ " - "
				+ empresa.darSitioParqueoUno().darCamionDos().calcularSemanasYDiasParaSeguro(
						Fecha.restaFechas(Fecha.darFechaActual(), empresa
								.darSitioParqueoUno().darCamionDos().darFechaSeguro())) + "\n";
		respuesta += "Camion 3: "
				+ empresa.darSitioParqueoUno().darCamionTres().darPlaca()
				+ " - "
				+ empresa.darSitioParqueoUno().darCamionTres().calcularSemanasYDiasParaSeguro(
						Fecha.restaFechas(Fecha.darFechaActual(), empresa
								.darSitioParqueoUno().darCamionTres().darFechaSeguro())) + "\n";
		respuesta += "Camion 4: "
				+ empresa.darSitioParqueoUno().darCamionCuatro().darPlaca()
				+ " - "
				+ empresa.darSitioParqueoUno().darCamionCuatro().calcularSemanasYDiasParaSeguro(
						Fecha.restaFechas(Fecha.darFechaActual(), empresa
								.darSitioParqueoUno().darCamionCuatro().darFechaSeguro()))
				+ "\n";

		return respuesta;
	}
	
	

	public static void main(String[] args) {
		Principal ventana = new Principal();
		ventana.setSize(660, 600);
		ventana.setLocation(300, 30);
		ventana.setResizable(false);
		ventana.setVisible(true);
		ventana.setTitle("Transportes Alfa");

	}

	public Empresa darEmpresa() {
		return empresa;
	}

}
