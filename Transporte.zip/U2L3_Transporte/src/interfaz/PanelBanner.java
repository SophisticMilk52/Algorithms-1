package interfaz;

import java.awt.*;
import java.awt.image.BufferedImage;

import javax.swing.*;

public class PanelBanner extends JPanel {

	private JLabel banner;

	public PanelBanner() {

		setPreferredSize(new Dimension(660,150));
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		g.setColor(Color.LIGHT_GRAY);
		g.fillRect(0, 0, 1000, 150);
		g.setColor(Color.BLACK);
		g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 45));
		g.drawString("Transportes Alfa", 233, 100);

		Toolkit ambiente = Toolkit.getDefaultToolkit();
		Image imagen = ambiente.getImage("./data/img/banner.jpg");
		g.drawImage(imagen, 0, 0, this);
	}

}
