package interfaz;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.border.TitledBorder;

public class PanelBotones extends JPanel implements ActionListener {

	private Principal principal;
	private JButton botonUno;
	private JButton botonDos;
	private JButton botonTres;
	private static final String OPCION_UNO = "Opci�n uno";
	private static final String OPCION_DOS = "Opci�n dos";
	private static final String OPCION_TRES = "Opci�n tres";

	public PanelBotones(Principal principal) {
		this.principal = principal;

		TitledBorder border = BorderFactory.createTitledBorder("Opciones");
		border.setTitleColor(Color.BLUE);
		setBorder(border);

		botonUno = new JButton(OPCION_UNO);
		botonUno.setActionCommand(OPCION_UNO);
		botonUno.addActionListener(this);

		botonDos = new JButton(OPCION_DOS);
		botonDos.setActionCommand(OPCION_DOS);
		botonDos.addActionListener(this);
		
		botonTres = new JButton(OPCION_TRES);
		botonTres.setActionCommand(OPCION_TRES);
		botonTres.addActionListener(this);

		setLayout(null);

		add(botonUno);
		add(botonDos);
		add(botonTres);

		Insets insets = getInsets();

		Dimension size;

		size = botonUno.getPreferredSize();
		botonUno.setBounds((220+ insets.left-size.width)/2, insets.top, size.width,
				size.height);
		size = botonDos.getPreferredSize();
		botonDos.setBounds(220+ (220+ insets.left-size.width)/2, insets.top,
				size.width, size.height);
		size = botonTres.getPreferredSize();
		botonTres.setBounds(440+ (220+ insets.left-size.width)/2, insets.top,
				size.width, size.height);

		setPreferredSize(new Dimension(660, size.height + 30));
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

		if (e.getActionCommand().equals(OPCION_UNO)) {
			JOptionPane.showMessageDialog(null, principal.opcionUno());
		} else if (e.getActionCommand().equals(OPCION_DOS)) {
			JOptionPane.showMessageDialog(null, principal.opcionDos());
		}
		else if (e.getActionCommand().equals(OPCION_TRES)) {
			JOptionPane.showMessageDialog(null, principal.opcionTres());
		}


	}

}
