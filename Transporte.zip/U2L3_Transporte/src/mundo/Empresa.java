package mundo;

public class Empresa {

	//Atributos
	private SitioParqueo SitioParqueoUno;
	
	//Constructor
	public Empresa() {
		
		Camion CamionUno = new Camion("CPB 258", 6, 290, 35000, 8,
				new Fecha(10, 10, 2016), "Camion1.jpg", Camion.CARGA_GRANEL);
		Camion CamionDos = new Camion("MHI 150", 9, 320, 60000, 11,
				new Fecha(21, 8, 2016), "Camion2.jpg", Camion.CARGA_QUIMICO);
		Camion CamionTres = new Camion("MKJ 556", 10, 390, 65000, 14,
				new Fecha(25, 9, 2016), "Camion3.jpg", Camion.CARGA_SECO);
		Camion CamionCuatro = new Camion("CPI 925", 15, 330, 75000, 12,
				new Fecha(10, 01, 2015), "Camion4.jpg", Camion.CARGA_SECO);

		SitioParqueoUno = new SitioParqueo(CamionUno, CamionDos, CamionTres, CamionCuatro);
	}	

	public SitioParqueo darSitioParqueoUno() {
		return SitioParqueoUno;
	}

	public void cambiarSitioParqueoUno(SitioParqueo SitioParqueoUno) {
		this.SitioParqueoUno = SitioParqueoUno;
	}

}
