package mundo;

public class SitioParqueo {

	// RELACIONES
	private Camion CamionUno;
	private Camion CamionDos;
	private Camion CamionTres;
	private Camion CamionCuatro;

	//Constructor
	public SitioParqueo(Camion CamionUno, Camion CamionDos, Camion CamionTres, Camion CamionCuatro) {

		this.CamionUno = CamionUno;
		this.CamionDos = CamionDos;
		this.CamionTres = CamionTres;
		this.CamionCuatro = CamionCuatro;
	}

	/**
	 * @Descripci�n: Este m�todo permite determinar el cami�n de menor consumo de combustible.
	 * 				 
	 * @return Retorna un String con la placa del camion que tenga el menor consumo de combustible
	 */

	// TODO

	public String seleccionarCamion(){
		String placa ="";

		double consu= 999999999.0;
		if (CamionUno != null){
			if(CamionUno.darConsumo()<consu){
				consu = CamionUno.darConsumo();
				placa= CamionUno.darPlaca();
			}

			if (CamionDos != null){
				if(CamionDos.darConsumo()<consu){
					consu = CamionDos.darConsumo();
					placa= CamionDos.darPlaca();
				}

				if (CamionTres != null){
					if(CamionTres.darConsumo()<consu){

						consu = CamionTres.darConsumo();
						placa= CamionTres.darPlaca();
					}
					if(CamionCuatro != null){
						if(CamionCuatro.darConsumo()<consu){

							consu = CamionCuatro.darConsumo();
							placa= CamionCuatro.darPlaca();
						}}}}}
						return placa;

					}



					/**
					 * @Descripci�n: Realiza el reporte de la cantidad de aceite que require cada cami�n. 
					 * @return Mensaje que indica la cantidad de aceite que requiere cada cami�n. 
					 * 		   Ejemplo: El Camion con placas PLACA_CAMION requiere XLITROS_ACEITE.
					 * 		   Aqui se entiende que en el mensaje PLACA_CAMION se debe reemplazar por la verdadera placa del camion, y XLITROS_ACEITE
					 * 		   se reemplaza por la cantidad de litros requerida por el cami�n. 
					 */

					// TODO

					public String reporteLitrosAceiteCamiones() {
						String Camion1="";
						String Camion2="";
						String Camion3="";
						String Camion4="";
						if(Camion1!=null){
						Camion1= "Camion1: " + CamionUno.darPlaca() + " - " + CamionUno.calcularCantidadAceite() + " Lt";
						}
						if(Camion2!=null){
						 Camion2= "Camion2: " + CamionDos.darPlaca() + " - " + CamionDos.calcularCantidadAceite() + " Lt";
						 }
						if(Camion3!=null){
						Camion3 = "Camion3: " + CamionTres.darPlaca() + " - " + CamionTres.calcularCantidadAceite()+ " Lt";
						}
						if(Camion4!=null){
						Camion4= "Camion4: " + CamionCuatro.darPlaca() + " - " + CamionCuatro.calcularCantidadAceite() + " Lt";
						}
					 	
						return Camion1+"\n"+Camion2+
							"\n"+Camion3+"\n"+Camion4;}
						


					/**
					 * @Descripci�n: Retorna el Camion del SitioParqueo
					 * @return
					 */
					public Camion darCamionUno() {
						return CamionUno;
					}

					/**
					 * @Descripci�n: Modifica el Camion del SitioParqueo
					 * @return
					 */
					public void cambiarCamionUno(Camion CamionUno) {
						this.CamionUno = CamionUno;
					}

					/**
					 * @Descripci�n: Retorna el camionUno del SitioParqueo
					 * @return
					 */
					public Camion darCamionDos() {
						return CamionDos;
					}

					/**
					 * @Descripci�n: Modifica el camionDos de la SitioParqueo
					 * @return
					 */
					public void cambiarCamionDos(Camion CamionDos) {
						this.CamionDos = CamionDos;
					}

					/**
					 * @Descripci�n: Retorna el camionTres de la SitioParqueo
					 * @return
					 */
					public Camion darCamionTres() {
						return CamionTres;
					}

					/**
					 * @Descripci�n: Retorna el camionTres de la SitioParqueo
					 * @return
					 */
					public Camion darCamionCuatro() {
						return CamionCuatro;
					}

					/**
					 * @Descripci�n: Modifica el camionCuatro de la SitioParqueo
					 * @return
					 */
					public void cambiarCamionTres(Camion CamionTres) {
						this.CamionTres = CamionTres;
					}

				}
