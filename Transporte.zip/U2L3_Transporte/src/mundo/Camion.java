package mundo;

public class Camion {

	// Constantes
	/**
	 * Es una valor constante tipo String que contine un tipo especifico de carga
	 */
public static final String CARGA_SECO="Seco";
/**
 * Es una valor constante tipo String que contine un tipo especifico de carga
 */
public static final String CARGA_GRANEL="Granol";
/**
 * Es una valor constante tipo String que contine un tipo especifico de carga
 */
public static final String CARGA_QUIMICO="Quimico";
	//Atributos
/**
 * determina la placa del camion de tipo string
 */
private String placa;
/**
 * capacidad de carga que tiene el camion
 */
private int capacidad;
/**
 * cantidad de caballos de fuerza que tiene el camion.
 */
private int caballosFuerza;
/**
 * cantidad de kilometros recorridos de cada camion
 */
private int kilometraje;
/**
 * el consumo de gasolino que tiene cada camion.
 */
private double consumo;
/**
 * Tipo de carga que posee el camion.
 */
private String tipo;
/**
 * la imagen del camion que esta en servicio.
 */
private String foto;
	


	//Relaciones
/**
* La fecha de seguro.
 */
	private Fecha fechaSeguro;

	public Camion(String placa, int  capacidad, int caballosFuerza, int kilometraje,
			double consumo, Fecha fechaSeguro, String foto, String tipo) {

		this.placa = placa;
		this.capacidad = capacidad;
		this.caballosFuerza = caballosFuerza;
		this.kilometraje = kilometraje;
		this.consumo = consumo;
		this.foto = foto;
		this.fechaSeguro = fechaSeguro;
		this.tipo = tipo;
	}


	
	/**
	 * @Descripci�n: Determina la cantidad de aceite que requiere el Camion.
	 *               El total de aceite que requiere un cami�n se determina 
	 *               como un porcentaje de los caballos de fuerza. Si la los caballos de fuerza
	 *               es menor a 300 y el tipo de carga es Seca o Quimicos, entonces se calcula con 
	 *               el 15% de los caballos de fuerza. Si es a Granel, con el 15.8%.
	 *               Si los caballos de fuerza estan entre 300 y 380 y el tipo de carga es Seca o a Granel, entonces se calcula con el 
	 *               18%. Si es Quimicos, con el 18.6%
	 *               Si los caballos de fuerza es mayor a 380, entonces se calcula con el 20% para cualquier tipo de carga (Seca, Granel o Quimicos).
	 *               Nota: El retorno debe ser un valor redondeado.
	 * 				 
	 * 				 RECUERDE USAR LAS CONSTANTES DE LA CLASE
	 * @return la cantidad de aceite en Lt
	 */
	
	// TODO
	
	public int calcularCantidadAceite(){
	
		double cantidad=0;
		if(caballosFuerza<300);{
		if(tipo.equals(CARGA_SECO)||tipo.equals(CARGA_QUIMICO)){
		cantidad= caballosFuerza*0.15;
		
		}
		else if(tipo.equals(CARGA_GRANEL))
		{
		cantidad= caballosFuerza*0.158;
		}
		
		if((caballosFuerza>=300) &&(caballosFuerza<=380)){
		if(tipo.equals(CARGA_SECO)||tipo.equals(CARGA_GRANEL));
		cantidad= caballosFuerza*0.18;}
		
		else if(tipo.equals(CARGA_QUIMICO))
		{
		cantidad= caballosFuerza*0.186;
		}
		if(caballosFuerza>380){ 
		if(tipo.equals(CARGA_SECO)||tipo.equals(CARGA_GRANEL)||(tipo.equals(CARGA_QUIMICO)))
		cantidad= caballosFuerza*0.2;}}
			
return (int)cantidad;

		
		
		
		
	}


	/**
	 * @Descripci�n: Determina las semanas y d�as que faltan para adquirir el seguro contra todo riesgo. 
	 * 				 Este seguro se debe pagar cada a�o. En caso de que el seguro
	 *               tenga m�s de un a�o se debe retornar un mensaje indicando
	 *               que el seguro del camion esta vencido. 
	 *               Nota: Esta informaci�n se debe mostrar en semanas y d�as.
	 * @param: int dias:  son los d�as que han transcurrido desde la fecha de
	 *         compra del seguro hasta la fecha actual
	 * @return Cadena con las semanas y d�as para la fecha
	 */
	public String calcularSemanasYDiasParaSeguro(int dias) {

		String mensaje="";
		if(Fecha.restaFechas(Fecha.darFechaActual(), fechaSeguro)>0){
			int Semanasfaltantes = (Fecha.restaFechas(Fecha.darFechaActual(), fechaSeguro)/7);
			int Diasfaltantes = Semanasfaltantes%7;
			mensaje= "Faltan " + Semanasfaltantes + " semanas y " + Diasfaltantes + " dias para adquirir el seguro";
			}else{
			if(Fecha.restaFechas(Fecha.darFechaActual(), fechaSeguro)<=0){
				mensaje="El seguro esta vencido.";
			}}
		
		return mensaje;
	}	

	public void modificarFoto(String foto) {
		this.foto = foto;
	}

	public String darPlaca() {
		return placa;
	}

	public void cambiarPlaca(String placa) {
		this.placa = placa;
	}

	public int darCapacidad() {
		return capacidad;
	}

	public void cambiarCapacidad(int capacidad) {
		this.capacidad = capacidad;
	}

	public int darCaballosFuerza() {
		return caballosFuerza;
	}

	public void cambiarCaballosFuerza(int caballosFuerza) {
		this.caballosFuerza = caballosFuerza;
	}

	public int darKilometraje() {
		return kilometraje;
	}

	public void cambiarKilometraje(int kilometraje) {
		this.kilometraje = kilometraje;
	}

	public double darConsumo() {
		return consumo;
	}

	public void cambiarConsumo(int consumo) {
		this.consumo = consumo;
	}

	public String darTipo() {
		return tipo;
	}

	public void cambiarTipo(String tipo) {
		this.tipo = tipo;
	}

	public String darFoto() {
		return foto;
	}

	public void cambiarFoto(String foto) {
		this.foto = foto;
	}

	public Fecha darFechaSeguro() {
		return fechaSeguro;
	}

	public void cambiarFechaSeguro(Fecha fechaCambioAceite) {
		this.fechaSeguro = fechaCambioAceite;
	}

}
