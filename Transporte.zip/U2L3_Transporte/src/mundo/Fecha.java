package mundo;

import java.util.*;

public class Fecha {

	private int dia;
	private int mes;
	private int anio;

	public Fecha(int dia, int mes, int anio) {

		this.dia = dia;
		this.mes = mes;
		this.anio = anio;
	}

	public static Fecha darFechaActual() {

		GregorianCalendar date = new GregorianCalendar();
		Fecha fechita = new Fecha(date.get(Calendar.DATE),
				date.get(Calendar.MONTH) + 1, date.get(Calendar.YEAR));

		return fechita;

	}

	public static int restaFechas(Fecha fecha1, Fecha fecha2) {

		int dias = 0;
		GregorianCalendar date1 = new GregorianCalendar(fecha1.daranio(),
				fecha1.darMes(), fecha1.darDia());
		GregorianCalendar date2 = new GregorianCalendar(fecha2.daranio(),
				fecha2.darMes(), fecha2.darDia());

		dias = (int) ((date1.getTime().getTime() - date2.getTime().getTime()) / (1000 * 60 * 60 * 24));

		return dias;

	}

	public int darDia() {
		return dia;
	}

	public void cambiarDia(int dia) {
		this.dia = dia;
	}

	public int darMes() {
		return mes;
	}

	public void cambiarMes(int mes) {
		this.mes = mes;
	}

	public int daranio() {
		return anio;
	}

	public void cambiaranio(int anio) {
		this.anio = anio;
	}

	public String toString() {
		String mesCadena = "";

		switch (mes) {
		case 1:
			mesCadena = "Enero";
			break;

		case 2:
			mesCadena = "Febrero";
			break;

		case 3:
			mesCadena = "Marzo";
			break;

		case 4:
			mesCadena = "Abril";
			break;

		case 5:
			mesCadena = "Mayo";
			break;
		case 6:
			mesCadena = "Junio";
			break;

		case 7:
			mesCadena = "Julio";
			break;

		case 8:
			mesCadena = "Agosto";
			break;

		case 9:
			mesCadena = "Septiembre";
			break;

		case 10:
			mesCadena = "Octubre";
			break;

		case 11:
			mesCadena = "Noviembre";
			break;

		case 12:
			mesCadena = "Diciembre";
			break;
		}

		return mesCadena + " " + dia + " del " + anio;

	}

}
